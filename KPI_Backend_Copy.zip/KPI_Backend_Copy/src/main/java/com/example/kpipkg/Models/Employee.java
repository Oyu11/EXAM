package com.example.kpipkg.Models;

import java.util.List;

public class Employee {

    String domainId;
    String name;
    String jobTitle;
    String company;
    String department;

    public Employee() {
        super();
        // TODO Auto-generated constructor stub
    }

    public Employee(String domainId, String name, String jobTitle, String company, String department,
                    List<aRole> roleList) {
        super();
        this.domainId = domainId;
        this.name = name;
        this.jobTitle = jobTitle;
        this.company = company;
        this.department = department;
        this.roleList = roleList;
    }

    public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    @Override
    public String toString() {
        return "Employee [domainId=" + domainId + ", name=" + name + ", jobTitle=" + jobTitle + ", company=" + company
                + ", department=" + department + ", roleList=" + roleList + "]";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public List<aRole> getRoleList() {
        return roleList;
    }

    public void setRoleList(List<aRole> roleList) {
        this.roleList = roleList;
    }

    List<aRole> roleList;


}
