package com.example.kpipkg.Models;

import jakarta.persistence.*;

@Entity
@Table(name = "tbYearMonth")
public class YearMonth {

    @Override
    public String toString() {
        return "YearMonth [id=" + id + ", year=" + year + ", month=" + month + ", count=" + count + ", position="
                + position + "]";
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    long id;

    @Column(name = "year")
    int year;

    @Column(name = "month")
    int month;

    @Column(name = "count")
    int count;

    @Column(name = "position")
    String position;

    @Column(name = "fieldid")
    int fieldid;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getFieldid() {
        return fieldid;
    }

    public void setFieldid(int fieldid) {
        this.fieldid = fieldid;
    }

    public YearMonth() {
        super();
        // TODO Auto-generated constructor stub
    }

    public YearMonth(int year, int month, int count, String position, int fieldid) {
        super();
        this.year = year;
        this.month = month;
        this.count = count;
        this.position = position;
        this.fieldid = fieldid;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }


}
