package com.example.kpipkg.Repositories;

import com.example.kpipkg.Models.KpiFields;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface KpiRepositoryFields extends JpaRepository<KpiFields, Long> {
    List<KpiFields> findByEffectiveyearAndEffectivemonthAndPositionname(int effectiveyear, int effectivemonth, String positionname);

    List<KpiFields> findByEffectiveyearAndEffectivemonth(int effectiveYear, int effectiveMonth);
}
