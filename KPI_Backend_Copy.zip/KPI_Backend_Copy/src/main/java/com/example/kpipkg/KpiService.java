package com.example.kpipkg;

import Response.ResponseCode;
import Response.ResponseLogin;
import com.example.kpipkg.Models.*;
import com.example.kpipkg.Repositories.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.testng.IReporter;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.*;


@Service
public class KpiService {
    @Autowired
    RoleRepository roleRepository;



    @Autowired
    UserSessionDataRepository userSessDataRepo;

    @Autowired
    KpiRepository kpiRepo;

    @Autowired
    KpiTempTable kpiTemRepo;

    @Autowired
    RoleRepository roleRepo;

    @Autowired
    KpiRepositoryFields kpiRepoFields;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    YearMonthRepository yearmonthRepo;

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.build();
    }


    @Value("${LDAP_Prefix}")
    private String ldapPrefix;

    @Value("${LDAP_URL}")
    private String ldapUrl;

    @Value("${BranchManagementTeam}")
    private String BranchManagementTeam;

    @Value("${DirectorScoreMax}")
    private int DirectorScoreMax;

    /*
     * Employee           => E
     * Director		      => D
     * HubDirector        => H
     * Salbarii udirdlaga => B
     *
     * */


    ResponseLogin Login(String userName, String pwd) {
		
	 
		/*

		if (userName.equalsIgnoreCase("tugsbileg")) {

			userSessionData.setEmplid(userName);
			userSessionData.setRoleid("kpi_director");
			userSessionData.setPositionname("tugsuugoosavah");
			String tmpStr = GenerateTokey(userName, "kpi_director" );
			
			 
			
			userSessionData.setSessionid(tmpStr);
			userSessionData.setScoremin(-10);			
			userSessionData.setScoremax(10);
		 
			
			userSessDataRepo.save(userSessionData);
		 
			
			responseLogin.setResponsecode( ResponseCodes.Success.getResponseCode());
			responseLogin.setUserSessionData(userSessionData);
			responseLogin.setLstmodelyearmonth(getDataSize(userSessionData));
		} else 
		if (userName.equalsIgnoreCase("5100")) {

			userSessionData.setEmplid(userName);
			userSessionData.setRoleid("kpi_employee");
			userSessionData.setPositionname("tugsuugoosavah");
			String tmpStr = GenerateTokey(userName, "kpi_employee" );
			
			 
			
			userSessionData.setSessionid(tmpStr);
			userSessionData.setScoremin(0);			-
			userSessionData.setScoremax(0);
		 
		 
			
			userSessDataRepo.save(userSessionData);
		 
			
			responseLogin.setResponsecode( ResponseCodes.Success.getResponseCode());
			responseLogin.setUserSessionData(userSessionData);
			responseLogin.setLstmodelyearmonth(getDataSize(userSessionData));
		} else   	if (userName.equalsIgnoreCase("2020")) {

			userSessionData.setEmplid(userName);
			userSessionData.setRoleid("kpi_hubdirector");
			userSessionData.setPositionname("tugsuugoosavah");
			String tmpStr = GenerateTokey(userName, "kpi_hubdirector" );
			
			 
			
			userSessionData.setSessionid(tmpStr);
			userSessionData.setScoremin(-10);			
			userSessionData.setScoremax(10);
		 
			
			userSessDataRepo.save(userSessionData);
		 
			
			responseLogin.setResponsecode( ResponseCodes.Success.getResponseCode());
			responseLogin.setUserSessionData(userSessionData);
			responseLogin.setLstmodelyearmonth(getDataSize(userSessionData));
		}
		
		*/


        HttpHeaders header = new HttpHeaders();
        //You can use more methods of HttpHeaders to set additional information
        header.setContentType(MediaType.APPLICATION_JSON);
        Map bodyParamMap = new HashMap();
        //Set your request body params
        bodyParamMap.put("UserId", userName);
        bodyParamMap.put("password", pwd);
        bodyParamMap.put("prefix", ldapPrefix);


        ResponseCode rCode = ResponseCodes.Error_Login.getResponseCode();

        UserSessionData userSessionData = new UserSessionData(true);

        List<YearMonth> lstModelYearMonth = new ArrayList<YearMonth>();

        ResponseLogin responseLogin = new ResponseLogin(rCode, userSessionData, lstModelYearMonth);


        String reqBodyData = "NO Data Found.";

        /*  aRole  зөвхөн ROle - н мэдээллийн жагсаалтаар хөрвүүлж авахад ашиглагдана. */
        // ResponseEntity<aRole[]> result = null;

        ResponseEntity<Employee> result = null;

        String role_name = "";
        try {
            System.out.println(userName);
            System.out.println("userName");
            role_name = kpiRepo.findRoleName(userName).get();

            System.out.println(role_name);

            userSessionData.setEmplid(userName);
            userSessionData.setRoleid(role_name);


            String tmpStr = GenerateTokey(userName, role_name);

            userSessionData.setSessionid(tmpStr);
            /*userSessionData.setScoremin(roleTemp.getScoremin());
            userSessionData.setScoremax(roleTemp.getScoremax());
            userSessionData.setIschecked(roleTemp.getChecked());*/
            System.out.print("::::::::::::::::::");
            System.out.print("SAVE USER SESSION DATA");
            System.out.print(userSessionData.getIschecked());
            System.out.print(userSessionData);
            userSessDataRepo.save(userSessionData);

            System.out.print("END SAVE USER SESSION DATA");
            responseLogin.setResponsecode(ResponseCodes.Success.getResponseCode());
            responseLogin.setUserSessionData(userSessionData);
            responseLogin.setLstmodelyearmonth(getDataSize(userSessionData));


            System.out.println("Solution.");


            /*
            reqBodyData = new ObjectMapper().writeValueAsString(bodyParamMap);
            HttpEntity requestEnty = new HttpEntity<>(reqBodyData, header);

            System.out.println("Debug 0..");

            result = restTemplate.postForEntity(ldapUrl, requestEnty, Employee.class);


            System.out.println("Result:::: " + result.getBody());

            Employee employee = result.getBody();

            System.out.println(employee);


            if (employee.getRoleList().size() > 0 && employee.getRoleList().get(0).getRoleId() != "") {


                Role roleTemp = roleRepository.findByRoleidIgnoreCase(employee.getRoleList().get(0).getRoleId());

                if (roleTemp != null) {
                    System.out.println(roleTemp.toString());


                    userSessionData.setEmplid(userName);
                    userSessionData.setEmplName(employee.getName());
                    userSessionData.setRoleid(roleTemp.getRoleid());
                    userSessionData.setEmpljobtitle(employee.getJobTitle());
                    userSessionData.setEmpldepartment(employee.getDepartment());
                    userSessionData.setEmplcompany(employee.getCompany());

                    String tmpStr = GenerateTokey(userName, employee.getRoleList().get(0).getRoleId());

                    userSessionData.setSessionid(tmpStr);
                    userSessionData.setScoremin(roleTemp.getScoremin());
                    userSessionData.setScoremax(roleTemp.getScoremax());


                    // userSessionData.setCreatedt(Timestamp.valueOf(LocalDateTime.now().minusDays(1)));
                    // userSessionData.setModifiedt(Timestamp.valueOf(LocalDateTime.now().minusDays(1)));


                    userSessDataRepo.save(userSessionData);


                    responseLogin.setResponsecode(ResponseCodes.Success.getResponseCode());
                    responseLogin.setUserSessionData(userSessionData);
                    responseLogin.setLstmodelyearmonth(getDataSize(userSessionData));


                    System.out.println("debug 6.");
                } else {
                    rCode = ResponseCodes.NoFound_Role.getResponseCode();
                    responseLogin.setResponsecode(rCode);

                }

            }*/


        } catch (Exception e) { //JsonProcessingException
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        return responseLogin;

    }

    private String GenerateTokey(String username, String Rolename) {
        // TODO Auto-generated method stub
        String strTmp = username + LocalDateTime.now().toString() + Rolename + "SALTAAGEJ";
        MessageDigest digest;
        String sha3Hex = null;
        try {
            digest = MessageDigest.getInstance("SHA3-256");
            final byte[] hashbytes = digest.digest(strTmp.getBytes(StandardCharsets.UTF_8));
            sha3Hex = ByteToHex(hashbytes);
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return sha3Hex;
    }


    private String ByteToHex(byte[] byteArray) {
        String hex = "";
        // Iterating through each byte in the array
        for (byte i : byteArray) {
            hex += String.format("%02X", i);
        }
        return hex;
    }


    ResponseCode SaveKpiDetails(List<KpiModel> lstKpiData, UserSessionData userSessionData) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        try {
            List<KpiModel> lstKpiTempData = new ArrayList<KpiModel>();
            if (userSessionData.getRoleid().toLowerCase().equals(Roles.Employee.getRoleName().toLowerCase())) {
                KpiModel KpiModel = kpiRepo.findByEmplidAndId(userSessionData.getEmplid(), lstKpiData.get(0).getId());
                if (KpiModel != null) {
                    /* json r orj irsen data n ug huniii oooriinh n ezemshliii data mon esehiiig davhar shalgaj bn BYPASS?  */
                    /*  Bypass hiilguin tuld orj irsen obj iig shuud save hiilguigeer, ID r n haij olood, olson medeelel deeree Only comment -g n set hiij ogno  */
                    KpiModel.setCommentbyemployee(lstKpiData.get(0).getCommentbyemployee());
                    kpiRepo.save(KpiModel);
                    rCode = ResponseCodes.Success.getResponseCode();
                }
            } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.DIRECTOR.getRoleName().toLowerCase())) {
                lstKpiTempData.clear();
                lstKpiData.forEach(e -> {
                    try {
                        KpiModel KpiModel = kpiRepo.findByDirectoridAndId(userSessionData.getEmplid(), e.getId());

                        KpiModel.setCommentbydirector(e.getCommentbydirector());
                        KpiModel.setScoredir(e.getScoredir());
                        KpiModel.setIskpi(e.getIskpi());
                        KpiModel.setIsconfirmed(e.getIsconfirmed());
                        lstKpiTempData.add(KpiModel);
                    } catch (Exception ex) {
                    }
                });

                kpiRepo.saveAll(lstKpiTempData);
                rCode = ResponseCodes.Success.getResponseCode();
            } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.HUBDIRECTOR.getRoleName().toLowerCase())) {
                lstKpiTempData.clear();
                lstKpiData.forEach(e -> {
                    try {
                        KpiModel KpiModel = kpiRepo.findByHubdirectoridAndId(userSessionData.getEmplid(), e.getId());
                        KpiModel.setCommentbydirectorhub(e.getCommentbydirectorhub());
                        KpiModel.setScorehubdir(e.getScorehubdir());
                        KpiModel.setIskpi(e.getIskpi()); //Busiin zahiral batlah
                        KpiModel.setIsconfirmedhub(e.getIsconfirmedhub());
                        lstKpiTempData.add(KpiModel);
                    } catch (Exception ex) {
                    }
                });
                kpiRepo.saveAll(lstKpiTempData);
                rCode = ResponseCodes.Success.getResponseCode();
            } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())) {
                kpiRepo.saveAll(lstKpiData);
                rCode = ResponseCodes.Success.getResponseCode();
            } else {
                rCode = ResponseCodes.NoFound_Permission.getResponseCode();
            }
        } catch (Exception e) {
            rCode = ResponseCodes.Error_Save.getResponseCode();
            System.out.println("ERROR::" + e.toString());
        }
        return rCode;
    }
    //** Ulziibuyan Save service details
    ResponseCode SaveKpiDetail(KpiModel KpiData,  UserSessionData userSessionData) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        try {
            if (userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())) {
                KpiModel tmpdata =kpiRepo.findByEmplidAndId(KpiData.getEmplid(), KpiData.getId());
                tmpdata.setCol1(KpiData.getCol1());
                tmpdata.setCol2(KpiData.getCol2());
                tmpdata.setCol3(KpiData.getCol3());
                tmpdata.setCol4(KpiData.getCol4());
                tmpdata.setCol5(KpiData.getCol5());
                tmpdata.setCol6(KpiData.getCol6());
                tmpdata.setCol7(KpiData.getCol7());
                tmpdata.setCol8(KpiData.getCol8());
                tmpdata.setCol9(KpiData.getCol9());
                tmpdata.setCol10(KpiData.getCol10());
                tmpdata.setDirectorid(KpiData.getDirectorid());
                tmpdata.setEmplid(KpiData.getEmplid());
                tmpdata.setEmplname(KpiData.getEmplname());
                tmpdata.setEmplbrncode(KpiData.getEmplbrncode());
                tmpdata.setEmplstatus(KpiData.getEmplstatus());
                tmpdata.setEmplpossition(KpiData.getEmplpossition());
                tmpdata.setIsconfirmed(KpiData.getIsconfirmed());
                tmpdata.setIsconfirmedhub(KpiData.getIsconfirmedhub());
                tmpdata.setIskpi(KpiData.getIskpi());
                tmpdata.setCreateuser(KpiData.getCreateuser());
                kpiRepo.save(tmpdata);
                rCode = ResponseCodes.Success.getResponseCode();
            } else {
                rCode = ResponseCodes.NoFound_Permission.getResponseCode();
            }
        } catch (Exception e) {
            rCode = ResponseCodes.Error_Save.getResponseCode();
            System.out.println("ERROR::" + e.toString());
        }
        return rCode;
    }

    //** Ulziibuyan Add Delete service
    @Transactional
    ResponseCode DeleteInformation(KpiModel dlt_info, UserSessionData userSessionData, int year, int month){
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        try{
          if(userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())){

              kpiRepo.deleteByEmplidAndEffectiveyearAndEffectivemonthAndEmplpossition(dlt_info.getEmplid(), year, month, dlt_info.getEmplpossition());
              rCode = ResponseCodes.Success.getResponseCode();
          }
          else {
              rCode = ResponseCodes.NoFound_Permission.getResponseCode();
          }
        }
        catch(Exception e){
          rCode = ResponseCodes.Error_Delete.getResponseCode();
          System.out.println("ERROR::" + e.toString());
        }
    return rCode;
    }

    //** Ulziibuyan Undo section admin
    ResponseCode GetUndo(int year, int month, UserSessionData userSessionData, String emplid, String emposition){
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        try{
            if(userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())){
                KpiModelTemp tmpdata = kpiTemRepo.findByEmplidAndEffectiveyearAndEffectivemonthAndEmplpossition(emplid, year, month, emposition);
                if(tmpdata != null){
                    //KpiModel existingEntity = kpiRepo.findByEmplidAndId(emplid, tmpdata.getId());
                    System.out.println("tmpdata");
                    int id = kpiRepo.findId(year, month, emposition, emplid).get();
                    KpiModel existingEntity = kpiRepo.findByEmplidAndId(emplid, id);
                    existingEntity.setIsconfirmedhub(tmpdata.getIsconfirmedhub());
                    existingEntity.setIsconfirmed(tmpdata.getIsconfirmed());
                    existingEntity.setIskpi(tmpdata.getIskpi());
                    existingEntity.setCommentbydirector(tmpdata.getCommentbydirector());
                    existingEntity.setCommentbydirectorhub(tmpdata.getCommentbydirectorhub());
                    existingEntity.setCommentbyemployee(tmpdata.getCommentbyemployee());
                    existingEntity.setScoredir(tmpdata.getScoredir());
                    existingEntity.setScorehubdir(tmpdata.getScorehubdir());
                    existingEntity.setEmplpossition(tmpdata.getEmplpossition());
                    existingEntity.setEmplname(tmpdata.getEmplname());
                    existingEntity.setCol1(tmpdata.getCol1());
                    existingEntity.setCol2(tmpdata.getCol2());
                    existingEntity.setCol3(tmpdata.getCol3());
                    existingEntity.setCol4(tmpdata.getCol4());
                    existingEntity.setCol5(tmpdata.getCol5());
                    existingEntity.setCol6(tmpdata.getCol6());
                    existingEntity.setCol7(tmpdata.getCol7());
                    existingEntity.setCol8(tmpdata.getCol8());
                    existingEntity.setCol9(tmpdata.getCol9());
                    existingEntity.setCol10(tmpdata.getCol10());
                    existingEntity.setCol11(tmpdata.getCol11());
                    existingEntity.setCol12(tmpdata.getCol12());
                    existingEntity.setCol13(tmpdata.getCol13());
                    existingEntity.setCol14(tmpdata.getCol14());
                    existingEntity.setCol15(tmpdata.getCol15());
                    existingEntity.setCol16(tmpdata.getCol16());
                    existingEntity.setCol17(tmpdata.getCol17());
                    existingEntity.setCol18(tmpdata.getCol18());
                    existingEntity.setCol19(tmpdata.getCol19());
                    existingEntity.setCol20(tmpdata.getCol20());
                    existingEntity.setEmplstatus(tmpdata.getEmplstatus());

                    try {
                        existingEntity.setEmplbrncode(tmpdata.getEmplbrncode());
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    kpiRepo.save(existingEntity);
                    rCode = ResponseCodes.Success.getResponseCode();
                }
                else {
                    rCode = ResponseCodes.NoFound_Data.getResponseCode();
                }
            }
            else {
                rCode = ResponseCodes.NoFound_Permission.getResponseCode();
            }

        }
        catch(Exception e){
            rCode = ResponseCodes.Error_Save.getResponseCode();
            System.out.println("ERROR::" + e.toString());
        }
        return rCode;
    }

    //Ulziibuyan Excel report object


    ResponseCode UpdateKpiDataByDirector(List<KpiModel> lstKpiData, UserSessionData userSessionData) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        try {
            List<KpiModel> lstKpiTempData = new ArrayList<KpiModel>();
            if (userSessionData.getRoleid().toLowerCase().equals(Roles.DIRECTOR.getRoleName().toLowerCase())) {
                System.out.println("11...");
                lstKpiData.forEach(e -> {
                    /* Ирүүлсэн дата дотор тухайн захиралын харъяаны бус дата орж ирвэл процесслохгүй байх ёстой  */
                    KpiModel tmpData = kpiRepo.findByIdAndDirectoridAndEffectiveyearAndEffectivemonth(e.getId(), userSessionData.getEmplid(), e.getEffectiveyear(), e.getEffectivemonth());
                    if (tmpData != null) {
                        /* Захиралын өгөх онооны хязгаарыг барьж баайгаа эсэхийг давхар шалгаж байна. */
                        if (e.getScoredir() >= userSessionData.getScoremin() && e.getScoredir() <= userSessionData.getScoremax()) {
                            /* захирал зөвхөн score dir хэсэгийг мэдээллийг өөрчлөх боломжтой байх ёстой  */
                            tmpData.setScoredir(e.getScoredir());
                            tmpData.setModifieddt(LocalDateTime.now());
                            tmpData.setModifieduser(userSessionData.getEmplid());
                            tmpData.setIsconfirmed(e.getIsconfirmed());

                            lstKpiTempData.add(tmpData);
                        }
                    }
                });

                if (lstKpiTempData.size() > 0) {
                    kpiRepo.saveAll(lstKpiTempData);
                    rCode = ResponseCodes.Success.getResponseCode();
                } else {
                    rCode = ResponseCodes.NoFound_Data.getResponseCode();
                }
            } else {
                rCode = ResponseCodes.NoFound_Permission.getResponseCode();
            }
        } catch (Exception e) {
            rCode = ResponseCodes.Error_Save.getResponseCode();
            System.out.println("ERROR::" + e.toString());
        }
        return rCode;
    }

    ResponseCode UpdateKpiDataByALLBranchManager(List<KpiModel> lstKpiData, UserSessionData userSessionData) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        try {
            lstKpiData.forEach(e -> {
                e.setModifieduser(userSessionData.getEmplid());
                e.setModifieddt(LocalDateTime.now());
            });
            kpiRepo.saveAll(lstKpiData);
        } catch (Exception e) {
            rCode = ResponseCodes.Error_Save.getResponseCode();
            System.out.println("ERROR::" + e.toString());
        }
        return rCode;
    }


    List<KpiFields> GetFieldsData(int year, int month, UserSessionData userSessionData) {
        List<KpiFields> lstKpiFields = new ArrayList<KpiFields>();
        System.out.println(userSessionData.getRoleid());
        System.out.println(Roles.ALLBranchManager.getRoleName());
        /*tur add hiiw ulziik*/
        System.out.println("debug1.");
        lstKpiFields = kpiRepoFields.findByEffectiveyearAndEffectivemonth(year, month);
        System.out.println(lstKpiFields.size());
        /*if (userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())) {
            System.out.println("debug1.");
            lstKpiFields = kpiRepoFields.findByEffectiveyearAndEffectivemonth(year, month);
            System.out.println(lstKpiFields.size());
        } else {
            System.out.println("Not equals.");
        }*/
        return lstKpiFields;
    }


    private List<YearMonth> getDataSize(
            UserSessionData userSessionData) {
		/*
		Map< Integer, List<KpiModel>> groupbyEffectiveYear =  lstKpiData.stream().collect(Collectors.groupingBy( KpiModel::getEffectiveyear ));
		groupbyEffectiveYear.forEach( (k,v) ->{
			System.out.print("Key:"+k);
			List<KpiModel> dfds= v;

			dfds.forEach(ee-> {
					System.out.println(ee.toString());
				});
		});
		*/

        List<YearMonth> lstModelYearMonth = new ArrayList<YearMonth>();
        if (userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())) {
            lstModelYearMonth = yearmonthRepo.Get_YM_All();
            System.out.println(lstModelYearMonth);
        } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.Employee.getRoleName().toLowerCase())) {
            System.out.println("userSessionData::::::::::::::::::::::::" + userSessionData.toString());
            lstModelYearMonth = yearmonthRepo.Get_YM_Employee(userSessionData.getEmplid());
        } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.DIRECTOR.getRoleName().toLowerCase())) {
            lstModelYearMonth = yearmonthRepo.Get_YM_Director(userSessionData.getEmplid());
        } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.HUBDIRECTOR.getRoleName().toLowerCase())) {
            lstModelYearMonth = yearmonthRepo.Get_YM_HubDirector(userSessionData.getEmplid());
        }
        return lstModelYearMonth;
    }

    ResponseCode SaveCommentEmlpyee(UserSessionData userSessionData, long kpiid, String comment) {
        ResponseCode rCode = ResponseCodes.Error_Save.getResponseCode();
        return rCode;
    }

    List<KpiModel> GetData(int yearValue, int monthValue, String positionName, UserSessionData userSessionData) {
        System.out.println(userSessionData.toString());
        List<KpiModel> lstKpiData = Collections.emptyList();
        if (userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())) {
            System.out.println("2");
            if(positionName.equals("ALL")){
                lstKpiData = kpiRepo.findByEffectiveyearAndEffectivemonth(yearValue, monthValue);
            }
            else {
                lstKpiData = kpiRepo.findByEffectiveyearAndEffectivemonthAndEmplpossition(yearValue, monthValue, positionName);
            }
        } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.Employee.getRoleName().toLowerCase())) {
            System.out.println("3");
            lstKpiData = kpiRepo.findByEmplidAndEffectiveyearAndEffectivemonthAndEmplpossition(userSessionData.getEmplid(), yearValue, monthValue, positionName);
            System.out.println("Data printed here. Employee ");
            System.out.println(lstKpiData);
            // lstKpiData = kpiRepo.findByEmplid(userSessionData.getEmplid());
        } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.DIRECTOR.getRoleName().toLowerCase())) {
            System.out.println("Data printed here. 11 ");
            lstKpiData = kpiRepo.findByDirectoridAndEffectiveyearAndEffectivemonthAndEmplpossition(userSessionData.getEmplid(), yearValue, monthValue, positionName);
        } else if (userSessionData.getRoleid().toLowerCase().equals(Roles.HUBDIRECTOR.getRoleName().toLowerCase())) {
            System.out.println("4");
            // lstKpiData = kpiRepo.findByHubdirectoridAndEffectiveyearAndEffectivemonth(userSessionData.getEmplid(), yearValue, monthValue);
            lstKpiData = kpiRepo.findByHubdirectoridAndEffectiveyearAndEffectivemonthAndEmplpossition(userSessionData.getEmplid(), yearValue, monthValue, positionName);
        } else {
            System.out.println("555:" + userSessionData.getRoleid());
        }
        return lstKpiData;

    }

    List<KpiFields> GetAllFieldsTitle(int yearValue, int monthValue, String positionName) {
        List<KpiFields> lstKpiFields = Collections.emptyList();
        try {

            System.out.println("yearValue:" + yearValue + " monthValue:" + monthValue + " positionName:" + positionName);
            lstKpiFields = kpiRepoFields.findByEffectiveyearAndEffectivemonthAndPositionname(yearValue, monthValue, positionName);
            System.out.println("lstKpiFields ------------------>");
            System.out.println(lstKpiFields);
        } catch (Exception e) {
        System.out.println("Something went wrong." + e.toString());
        }
        // lstKpiFields = kpiRepoFields.findAll();
        return lstKpiFields;

    }

    UserSessionData getUserSessionData(String sessionid) {
        System.out.println(":::" + sessionid);
        return userSessDataRepo.findBySessionid(sessionid);
    }


    @Transactional
    public ResponseCode SaveKpiField(UserSessionData userSessionData, KpiFields kpiField) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        System.out.println("THis is Field save action.");
        if (userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())) {
            try {
                System.out.println(kpiField);
                KpiFields tmpKpiField = null;
                try {
                    tmpKpiField = kpiRepoFields.findById(kpiField.getId()).get();
                } catch (Exception ex) {
                }
                List<KpiModel> tmpKpiModel = new ArrayList<KpiModel>();
                if (tmpKpiField != null) {
                    tmpKpiField.setCol1(kpiField.getCol1());
                    tmpKpiField.setCol2(kpiField.getCol2());
                    tmpKpiField.setCol3(kpiField.getCol3());
                    tmpKpiField.setCol4(kpiField.getCol4());
                    tmpKpiField.setCol5(kpiField.getCol5());
                    tmpKpiField.setCol6(kpiField.getCol6());
                    tmpKpiField.setCol7(kpiField.getCol7());
                    tmpKpiField.setCol8(kpiField.getCol8());
                    tmpKpiField.setCol9(kpiField.getCol9());
                    tmpKpiField.setCol10(kpiField.getCol10());

                    tmpKpiField.setScorenumber1(kpiField.getScorenumber1());
                    tmpKpiField.setScorenumber2(kpiField.getScorenumber2());
                    tmpKpiField.setScorenumber3(kpiField.getScorenumber3());
                    tmpKpiField.setScorenumber4(kpiField.getScorenumber4());
                    tmpKpiField.setScorenumber5(kpiField.getScorenumber5());
                    tmpKpiField.setScorenumber6(kpiField.getScorenumber6());
                    tmpKpiField.setScorenumber7(kpiField.getScorenumber7());
                    tmpKpiField.setScorenumber8(kpiField.getScorenumber8());
                    tmpKpiField.setScorenumber9(kpiField.getScorenumber9());
                    tmpKpiField.setScorenumber10(kpiField.getScorenumber10());

                    tmpKpiField.setEffectiveyear(kpiField.getEffectiveyear());
                    tmpKpiField.setEffectivemonth(kpiField.getEffectivemonth());
                    tmpKpiModel = kpiRepo.findByEffectiveyearAndEffectivemonthAndEmplpossition(tmpKpiField.getEffectiveyear(), tmpKpiField.getEffectivemonth(), tmpKpiField.getPositionname());
                    tmpKpiModel.forEach(e -> {
                        e.setEmplpossition(kpiField.getPositionname());
                    });

                    tmpKpiField.setPositionname(kpiField.getPositionname());
                    kpiRepoFields.save(tmpKpiField);
                    if (tmpKpiModel.size() > 0) kpiRepo.saveAll(tmpKpiModel);
                    rCode = ResponseCodes.Success.getResponseCode();
                } else {
                    kpiRepoFields.save(kpiField);
                    rCode = ResponseCodes.Success.getResponseCode();
                }
            } catch (Exception ex) {
                System.out.println("JG Error:" + ex.toString());
                rCode = ResponseCodes.Error_Save.getResponseCode();
            }
        }
        // TODO Auto-generated method stub
        return rCode;
    }

    List<Role> GetScore(UserSessionData userSessionData, String role_name) {
        List<Role> lstRoleTemp = new ArrayList<Role>();
        System.out.println("Start here ----------->");
        if (userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase()) || userSessionData.getRoleid().toLowerCase().equals(Roles.DIRECTOR.getRoleName().toLowerCase()) || userSessionData.getRoleid().toLowerCase().equals(Roles.HUBDIRECTOR.getRoleName().toLowerCase())) {
            if (userSessionData.getRoleid().toLowerCase().equals(Roles.HUBDIRECTOR.getRoleName().toLowerCase()) || userSessionData.getRoleid().toLowerCase().equals(Roles.DIRECTOR.getRoleName().toLowerCase())) {
                try {
                    roleRepo.findAll().forEach(e -> {
                        if (!e.getRoleid().equalsIgnoreCase(Roles.Employee.getRoleName())) {

                            if (e.getRolename().contains(role_name) && e.getRoleid().equals(userSessionData.getRoleid())) {
                                lstRoleTemp.add(e);
                            }
                        }
                    });
                } catch(Exception ex) {
                    System.out.println(ex);
                }
            }
            else {
                try {
                    roleRepo.findAll().forEach(e -> {
                        if (!e.getRoleid().equalsIgnoreCase(Roles.Employee.getRoleName())) {

                            if (e.getRolename().contains(role_name)) {
                                lstRoleTemp.add(e);
                            }
                        }
                    });
                } catch (Exception ex) {
                    System.out.println(ex);
                }
            }
        }

        // TODO Auto-generated method stub
        return lstRoleTemp;
    }

    ResponseCode SaveScore(UserSessionData userSessionData, List<Role> lstRole) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        if (userSessionData.getRoleid().toLowerCase().equals(Roles.ALLBranchManager.getRoleName().toLowerCase())) {
            List<Role> lstRoleTemp = new ArrayList<Role>();

            System.out.println("Save score just start here");
            System.out.println(lstRole.size());
            try {
                lstRole.forEach(e -> {
                    try {

                        System.out.println("Save HOOSON getRoleid()::  "  + e.getRoleid());
                        System.out.println("Save HOOSON getRolename()::  " + e.getRolename());
                        Role rTmp = new Role();
                        rTmp = roleRepo.findByRoleidAndRolename(e.getRoleid(), e.getRolename());


                        if (rTmp != null)
                        {
                            System.out.println("Save rTmp.getRolename()::  " + rTmp.getRolename());
                            rTmp.setRoleid(e.getRoleid());
                            rTmp.setScoremax(e.getScoremax());
                            rTmp.setScoremin(-1 * e.getScoremax());
                            rTmp.setRolename(e.getRolename());
                            rTmp.setChecked(e.isChecked());
                            lstRoleTemp.add(rTmp);
                        }
                        else {

                            System.out.println("Save HOOSON BAINA()::  ");
                            Role tmp = new Role();
                            tmp.setRoleid(e.getRoleid());
                            tmp.setScoremax(e.getScoremax());
                            tmp.setScoremin(-1 * e.getScoremax());
                            tmp.setRolename(e.getRolename());
                            tmp.setChecked(e.isChecked());
                            lstRoleTemp.add(tmp);
                            System.out.println("add  lstRoleTemp()::  " + lstRoleTemp);

                        }
                    } catch (Exception ex2) {
                        System.out.println("D3:" + ex2.toString());
                    }
                });


                if (!lstRoleTemp.isEmpty()) {
                    System.out.println("last list lstRoleTemp()::  " + lstRoleTemp);
                    roleRepo.saveAllAndFlush(lstRoleTemp);
                    rCode = ResponseCodes.Success.getResponseCode();
                } else {
                    rCode = ResponseCodes.NoFound_Data.getResponseCode();
                }

            } catch (Exception ex) {
                System.out.println("D7");
            }
        }
        // TODO Auto-generated method stub
        return rCode;
    }

}
