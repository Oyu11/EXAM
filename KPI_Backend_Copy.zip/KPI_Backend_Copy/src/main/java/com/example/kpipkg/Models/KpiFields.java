package com.example.kpipkg.Models;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import io.micrometer.common.lang.Nullable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;


@Entity

@Table(name = "tbkpifields", uniqueConstraints =
        {
                @UniqueConstraint(columnNames = {"positionname", "effectiveyear", "effectivemonth"})
        }
)
public class KpiFields {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    long id;

    @Column(name = "scorenumber1")
    Integer scorenumber1;

    @Column(name = "scorenumber2")
    Integer scorenumber2;

    @Column(name = "scorenumber3")
    Integer scorenumber3;

    @Column(name = "scorenumber4")
    Integer scorenumber4;

    @Column(name = "scorenumber5")
    Integer scorenumber5;

    @Column(name = "scorenumber6")
    Integer scorenumber6;

    @Column(name = "scorenumber7")
    Integer scorenumber7;

    @Column(name = "scorenumber8")
    Integer scorenumber8;

    @Column(name = "scorenumber9")
    Integer scorenumber9;

    @Column(name = "scorenumber10")
    Integer scorenumber10;

    @Column(name = "positionname")
    String positionname;

    @Column(name = "effectivemonth")
    int effectivemonth;


    @Column(name = "effectiveyear")
    int effectiveyear;


    @CreatedDate
    @Column(name = "createddt")   // nullable = false , updatable = false
    private LocalDateTime createddt;

    @Column(name = "createuser")    // nullable = false, updatable = false
    private String createuser;

    @LastModifiedDate
    @Column(name = "modifieddt")
    private LocalDateTime modifieddt;

    @Column(name = "modifieduser")  // , nullable = false
    private String modifieduser;


    @Column(name = "col1")
    String col1;
    @Column(name = "col2")
    String col2;
    @Column(name = "col3")
    String col3;
    @Column(name = "col4")
    String col4;
    @Column(name = "col5")
    String col5;
    @Column(name = "col6")
    String col6;
    @Column(name = "col7")
    String col7;
    @Column(name = "col8")
    String col8;
    @Column(name = "col9")
    String col9;
    @Column(name = "col10")
    String col10;
    @Column(name = "col11")
    String col11;
    @Column(name = "col12")
    String col12;
    @Column(name = "col13")
    String col13;
    @Column(name = "col14")
    String col14;
    @Column(name = "col15")
    String col15;
    @Column(name = "col16")
    String col16;
    @Column(name = "col17")
    String col17;
    @Column(name = "col18")
    String col18;
    @Column(name = "col19")
    String col19;
    @Column(name = "col20")
    String col20;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getEffectivemonth() {
        return effectivemonth;
    }

    public void setEffectivemonth(int effectivemonth) {
        this.effectivemonth = effectivemonth;
    }

    public int getEffectiveyear() {
        return effectiveyear;
    }

    public void setEffectiveyear(int effectiveyear) {
        this.effectiveyear = effectiveyear;
    }

    public LocalDateTime getCreateddt() {
        return createddt;
    }

    public void setCreateddt(LocalDateTime createddt) {
        this.createddt = createddt;
    }

    public String getCreateuser() {
        return createuser;
    }

    public void setCreateuser(String createuser) {
        this.createuser = createuser;
    }

    public LocalDateTime getModifieddt() {
        return modifieddt;
    }

    public void setModifieddt(LocalDateTime modifieddt) {
        this.modifieddt = modifieddt;
    }

    public String getModifieduser() {
        return modifieduser;
    }

    public void setModifieduser(String modifieduser) {
        this.modifieduser = modifieduser;
    }

    public String getCol1() {
        return col1;
    }

    public void setCol1(String col1) {
        this.col1 = col1;
    }

    public String getCol2() {
        return col2;
    }

    public void setCol2(String col2) {
        this.col2 = col2;
    }

    public String getCol3() {
        return col3;
    }

    public void setCol3(String col3) {
        this.col3 = col3;
    }

    public String getCol4() {
        return col4;
    }

    public void setCol4(String col4) {
        this.col4 = col4;
    }

    public String getCol5() {
        return col5;
    }

    public void setCol5(String col5) {
        this.col5 = col5;
    }

    public String getCol6() {
        return col6;
    }

    public void setCol6(String col6) {
        this.col6 = col6;
    }

    public String getCol7() {
        return col7;
    }

    public void setCol7(String col7) {
        this.col7 = col7;
    }

    public String getCol8() {
        return col8;
    }

    public void setCol8(String col8) {
        this.col8 = col8;
    }

    public String getCol9() {
        return col9;
    }

    public void setCol9(String col9) {
        this.col9 = col9;
    }

    public String getCol10() {
        return col10;
    }

    public void setCol10(String col10) {
        this.col10 = col10;
    }

    public KpiFields() {
        super();
        // TODO Auto-generated constructor stub
    }

    public String getPositionname() {
        return positionname;
    }

    public void setPositionname(String positionname) {
        this.positionname = positionname;
    }


    public Integer getScorenumber1() {
        return scorenumber1;
    }

    public void setScorenumber1(Integer scorenumber1) {
        this.scorenumber1 = scorenumber1;
    }

    public Integer getScorenumber2() {
        return scorenumber2;
    }

    public void setScorenumber2(Integer scorenumber2) {
        this.scorenumber2 = scorenumber2;
    }

    public Integer getScorenumber3() {
        return scorenumber3;
    }

    public void setScorenumber3(Integer scorenumber3) {
        this.scorenumber3 = scorenumber3;
    }

    public Integer getScorenumber4() {
        return scorenumber4;
    }

    public void setScorenumber4(Integer scorenumber4) {
        this.scorenumber4 = scorenumber4;
    }

    public Integer getScorenumber5() {
        return scorenumber5;
    }

    public void setScorenumber5(Integer scorenumber5) {
        this.scorenumber5 = scorenumber5;
    }

    public Integer getScorenumber6() {
        return scorenumber6;
    }

    public void setScorenumber6(Integer scorenumber6) {
        this.scorenumber6 = scorenumber6;
    }

    public Integer getScorenumber7() {
        return scorenumber7;
    }

    public void setScorenumber7(Integer scorenumber7) {
        this.scorenumber7 = scorenumber7;
    }

    public Integer getScorenumber8() {
        return scorenumber8;
    }

    public void setScorenumber8(Integer scorenumber8) {
        this.scorenumber8 = scorenumber8;
    }

    public Integer getScorenumber9() {
        return scorenumber9;
    }

    public void setScorenumber9(Integer scorenumber9) {
        this.scorenumber9 = scorenumber9;
    }

    public Integer getScorenumber10() {
        return scorenumber10;
    }

    public void setScorenumber10(Integer scorenumber10) {
        this.scorenumber10 = scorenumber10;
    }

    public KpiFields(String col2, long id, Integer scorenumber1, Integer scorenumber2, Integer scorenumber3, Integer scorenumber4, Integer scorenumber5, Integer scorenumber6, Integer scorenumber7, Integer scorenumber8, Integer scorenumber9, Integer scorenumber10, String positionname, int effectivemonth, int effectiveyear, LocalDateTime createddt, String createuser, LocalDateTime modifieddt, String modifieduser, String col1, String col3, String col4, String col5, String col6, String col7, String col8, String col9, String col10, String col11, String col12, String col13, String col14, String col15, String col16, String col17, String col18, String col19, String col20) {
        this.col2 = col2;
        this.id = id;
        this.scorenumber1 = scorenumber1;
        this.scorenumber2 = scorenumber2;
        this.scorenumber3 = scorenumber3;
        this.scorenumber4 = scorenumber4;
        this.scorenumber5 = scorenumber5;
        this.scorenumber6 = scorenumber6;
        this.scorenumber7 = scorenumber7;
        this.scorenumber8 = scorenumber8;
        this.scorenumber9 = scorenumber9;
        this.scorenumber10 = scorenumber10;
        this.positionname = positionname;
        this.effectivemonth = effectivemonth;
        this.effectiveyear = effectiveyear;
        this.createddt = createddt;
        this.createuser = createuser;
        this.modifieddt = modifieddt;
        this.modifieduser = modifieduser;
        this.col1 = col1;
        this.col3 = col3;
        this.col4 = col4;
        this.col5 = col5;
        this.col6 = col6;
        this.col7 = col7;
        this.col8 = col8;
        this.col9 = col9;
        this.col10 = col10;
        this.col11 = col11;
        this.col12 = col12;
        this.col13 = col13;
        this.col14 = col14;
        this.col15 = col15;
        this.col16 = col16;
        this.col17 = col17;
        this.col18 = col18;
        this.col19 = col19;
        this.col20 = col20;
    }
}

	
	