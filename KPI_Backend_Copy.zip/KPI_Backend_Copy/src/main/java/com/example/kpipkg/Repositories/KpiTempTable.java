package com.example.kpipkg.Repositories;
import com.example.kpipkg.Models.KpiModelTemp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KpiTempTable extends JpaRepository<KpiModelTemp, Long> {


    KpiModelTemp findByEmplidAndEffectiveyearAndEffectivemonthAndEmplpossition(String emplid, int effectiveYear, int effectiveMonth, String positionName);

   
}
