package com.example.kpipkg.Models;

public class aRole {

    String roleId;
    String name;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public aRole(String roleId) {
        super();
        this.roleId = roleId;
    }

    public aRole() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public String toString() {
        return "aRole [roleId=" + roleId + "]";
    }


}
