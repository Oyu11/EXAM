package com.example.kpipkg;

import org.springframework.beans.factory.annotation.Autowired;

public class UserSessionValidation22 {

    @Autowired
    boolean isActiveSession(String userSession) {

        /*  UserSession repo r damjuulj useSession.getEmplid tie data baigaa eseh baival token generate hih ba ug uussen tokey n usersession.getToken tei ijil bol return true
         *  ROLE Name g shalgan -> E,D,H, A uud iig userssion deer avch shalgana.
         * */
// 		userSessionData.findby(session);
        return true;
    }
}
