package com.example.kpipkg;

import Response.ResponseCode;

enum Roles {
    None("None"), Employee("kpi_employee"), DIRECTOR("kpi_director"), HUBDIRECTOR("kpi_hubdirector"), ALLBranchManager("kpi_allbrnmanager");
    String rolename;
    Roles(String rolename) {
        this.rolename = rolename;
        // TODO Auto-generated constructor stub
    }
    public String getRoleName() {
        return rolename;
    }
    public void setRoleName(String rolename) {
        this.rolename = rolename;
    }
}

enum ResponseCodes {
    Success(new ResponseCode("200", "Success", "01", "")), Success_GetList(new ResponseCode("200", "Success", "02", "GetList")),
    NoFound(new ResponseCode("400", "No found", "01", "")), NoFound_Session(new ResponseCode("400", "No found", "02", "Not found user session")), NoFound_Data(new ResponseCode("400", "No found", "03", "Not found data")), NoFound_Permission(new ResponseCode("400", "No found", "04", "No permission found")), NoFound_Role(new ResponseCode("400", "No found", "05", "Not found user role")),
    Error(new ResponseCode("300", "Error", "01", "")), Error_Save(new ResponseCode("300", "Error", "02", "Save error")), Error_Update(new ResponseCode("300", "Error", "03", "Update error")), Error_Login(new ResponseCode("300", "Failed", "04", "Login failed")),
    Error_Delete(new ResponseCode("300", "Error", "05", "Delete error"));
    ResponseCode responseCode;
    ResponseCodes(ResponseCode responseCode) {
        this.responseCode = responseCode;
        // TODO Auto-generated constructor stub
    }
    public ResponseCode getResponseCode() {
        return responseCode;
    }
    public void setResponseCode(ResponseCode responseCode) {
        this.responseCode = responseCode;
    }
    public class Constantino {
    }
}
