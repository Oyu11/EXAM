package com.example.kpipkg.Repositories;

import com.example.kpipkg.Models.YearMonth;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface YearMonthRepository extends JpaRepository<YearMonth, Long> {

    @Query(value = "Select  ROW_NUMBER()  over( order by l.effectiveyear, l.effectivemonth) as id, l.effectiveyear year, l.effectivemonth month, count(1) as count, l.positionname position, l.id  fieldid from tbkpifields l inner join tbkpi p\r\n" + "       on l.positionname = p.emplpossition\r\n" + "       and l.effectiveyear = p.effectiveyear \r\n" + "       and l.effectivemonth = p.effectivemonth\r\n" + "Where p.emplid = ?1 \r\n" + "Group by l.effectiveyear, l.effectivemonth, l.positionname, l.id \r\n" + "Order by l.effectiveyear, l.effectivemonth, l.positionname desc", nativeQuery = true)
    List<YearMonth> Get_YM_Employee(String emplid);


    @Query(value = "Select  ROW_NUMBER()  over( order by l.effectiveyear, l.effectivemonth) as id, l.effectiveyear year, l.effectivemonth month, count(1) as count, l.positionname position, l.id fieldid from tbkpifields l inner join tbkpi p\r\n" + "       on l.positionname = p.emplpossition\r\n" + "       and l.effectiveyear = p.effectiveyear \r\n" + "       and l.effectivemonth = p.effectivemonth\r\n" + "Where p.directorid = ?1 \r\n" + "Group by l.effectiveyear, l.effectivemonth, l.positionname, l.id \r\n" + "Order by l.effectiveyear, l.effectivemonth, l.positionname desc", nativeQuery = true)
    List<YearMonth> Get_YM_Director(String directorid);

    @Query(value = "Select  ROW_NUMBER()  over( order by l.effectiveyear, l.effectivemonth) as id, l.effectiveyear year, l.effectivemonth month, count(1) as count, l.positionname position, l.id fieldid from tbkpifields l inner join tbkpi p\r\n" + "       on l.positionname = p.emplpossition\r\n" + "       and l.effectiveyear = p.effectiveyear \r\n" + "       and l.effectivemonth = p.effectivemonth\r\n" + "Where p.hubdirectorid = ?1 \r\n" + "Group by l.effectiveyear, l.effectivemonth, l.positionname, l.id \r\n" + "Order by l.effectiveyear, l.effectivemonth, l.positionname desc", nativeQuery = true)
    List<YearMonth> Get_YM_HubDirector(String hubdirectorid);


    @Query(value = "Select  ROW_NUMBER()  over( order by l.effectiveyear, l.effectivemonth) as id, l.effectiveyear year, l.effectivemonth month, count(1) as count, l.positionname position, l.id fieldid from tbkpifields l inner join tbkpi p\r\n" + "       on l.positionname = p.emplpossition\r\n" + "       and l.effectiveyear = p.effectiveyear \r\n" + "       and l.effectivemonth = p.effectivemonth\r\n" + "Group by l.effectiveyear, l.effectivemonth, l.positionname, l.id \r\n" + "Order by l.effectiveyear, l.effectivemonth, l.positionname desc", nativeQuery = true)
    List<YearMonth> Get_YM_All();

}
