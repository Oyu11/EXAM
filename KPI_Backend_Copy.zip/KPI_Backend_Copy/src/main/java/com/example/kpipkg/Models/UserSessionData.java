package com.example.kpipkg.Models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;

@Entity
@Table(name = "tbusersessiondata")
public class UserSessionData {

    @Id
    @Column(name = "emplid")
    String emplid;

    @Column(name = "sessionid")
    String sessionid;

    @Column(name = "roleid")
    String roleid;

    @Column(name = "scoremin")
    double scoremin;

    @Column(name = "scoremax")
    double scoremax;


    @Column(name = "ischecked", nullable = false)
    boolean ischecked;

    @Column(name = "emplname")
    String emplName;

    @Column(name = "empljobtitle")
    String empljobtitle;

    @Column(name = "emplcompany")
    String emplcompany;

    @Column(name = "empldepartment")
    String empldepartment;

    @CreationTimestamp
    @Column(name = "createdt")
    private java.sql.Timestamp createdt;

    @UpdateTimestamp
    @Column(name = "modifiedt")
    private java.sql.Timestamp modifiedt;

    public String getEmplid() {
        return emplid;
    }

    public void setEmplid(String emplid) {
        this.emplid = emplid;
    }

    public String getSessionid() {
        return sessionid;
    }

    public void setSessionid(String sessionid) {
        this.sessionid = sessionid;
    }

    public String getRoleid() {
        return roleid;
    }

    public void setRoleid(String roleid) {
        this.roleid = roleid;
    }


    public double getScoremin() {
        return scoremin;
    }

    public void setScoremin(double scoremin) {
        this.scoremin = scoremin;
    }

    public double getScoremax() {
        return scoremax;
    }

    public void setScoremax(double scoremax) {
        this.scoremax = scoremax;
    }

    public boolean getIschecked() {
        return this.ischecked;
    }

    public void setIschecked(boolean ischecked) {
        this.ischecked = ischecked;
    }

    public String getEmplName() {
        return emplName;
    }

    public void setEmplName(String emplName) {
        this.emplName = emplName;
    }

    public String getEmpljobtitle() {
        return empljobtitle;
    }

    public void setEmpljobtitle(String empljobtitle) {
        this.empljobtitle = empljobtitle;
    }

    public String getEmplcompany() {
        return emplcompany;
    }

    public void setEmplcompany(String emplcompany) {
        this.emplcompany = emplcompany;
    }

    public String getEmpldepartment() {
        return empldepartment;
    }

    public void setEmpldepartment(String empldepartment) {
        this.empldepartment = empldepartment;
    }

    public java.sql.Timestamp getCreatedt() {
        return createdt;
    }

    public void setCreatedt(java.sql.Timestamp createdt) {
        this.createdt = createdt;
    }

    public java.sql.Timestamp getModifiedt() {
        return modifiedt;
    }

    public void setModifiedt(java.sql.Timestamp modifiedt) {
        this.modifiedt = modifiedt;
    }

    public UserSessionData(String emplid, String sessionid, String roleid, double scoremin, double scoremax, boolean ischecked, String emplName, String empljobtitle, String emplcompany, String empldepartment, Timestamp createdt, Timestamp modifiedt) {
        this.emplid = emplid;
        this.sessionid = sessionid;
        this.roleid = roleid;
        this.scoremin = scoremin;
        this.scoremax = scoremax;
        this.ischecked = ischecked;
        this.emplName = emplName;
        this.empljobtitle = empljobtitle;
        this.emplcompany = emplcompany;
        this.empldepartment = empldepartment;
        this.createdt = createdt;
        this.modifiedt = modifiedt;
    }

    @Override
    public String toString() {
        return "UserSessionData{" +
                "emplid='" + emplid + '\'' +
                ", sessionid='" + sessionid + '\'' +
                ", roleid='" + roleid + '\'' +
                ", scoremin=" + scoremin +
                ", scoremax=" + scoremax +
                ", ischecked=" + ischecked +
                ", emplName='" + emplName + '\'' +
                ", empljobtitle='" + empljobtitle + '\'' +
                ", emplcompany='" + emplcompany + '\'' +
                ", empldepartment='" + empldepartment + '\'' +
                ", createdt=" + createdt +
                ", modifiedt=" + modifiedt +
                '}';
    }

    public UserSessionData(boolean isEmpty) {
        super();

        if (isEmpty) {
            this.emplid = "";
            this.sessionid = "";
            this.roleid = "";
            this.ischecked = false;
            this.scoremin = 0;
            this.scoremax = 0;
            this.emplName = "";
            this.empljobtitle = "";
            this.emplcompany = "";
            this.empldepartment = "";

        }
    }


    public UserSessionData() {
        super();
        // TODO Auto-generated constructor stub
    }


}
