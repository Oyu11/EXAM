package com.example.kpipkg.Repositories;


import com.example.kpipkg.Models.UserSessionData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserSessionDataRepository extends JpaRepository<UserSessionData, Long> {
    UserSessionData findBySessionid(String sessionid);
}
