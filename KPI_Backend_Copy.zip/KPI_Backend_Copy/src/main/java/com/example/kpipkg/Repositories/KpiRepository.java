package com.example.kpipkg.Repositories;
import com.example.kpipkg.Models.KpiModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;


public interface KpiRepository extends JpaRepository<KpiModel, Long> {
    KpiModel findByIdAndDirectoridAndEffectiveyearAndEffectivemonth(long id, String directorid, int effectiveYear, int effectiveMonth);

    List<KpiModel> findByEffectiveyearAndEffectivemonthAndEmplpossition(int effectiveYear, int effectiveMonth, String positionName);
    List<KpiModel> findByEffectiveyearAndEffectivemonth(int effectiveYear, int effectiveMonth);
    List<KpiModel> findByDirectoridAndEffectiveyearAndEffectivemonthAndEmplpossition(String directorid, int effectiveYear, int effectiveMonth, String positionName);

    List<KpiModel> findByEmplidAndEffectiveyearAndEffectivemonthAndEmplpossition(String emplid, int effectiveYear, int effectiveMonth, String positionName);

    List<KpiModel> findByHubdirectoridAndEffectiveyearAndEffectivemonthAndEmplpossition(String hubdirectorid, int effectiveYear, int effectiveMonth, String positionName);


    KpiModel findByHubdirectoridAndId(String directorid, long id);

    KpiModel findByEmplidAndId(String emplid, long id);
    @Query(value = "select p.role_name from tbkmap p where p.emp_id = :id ", nativeQuery = true)
    public Optional<String> findRoleName(@Param("id") String id);

    @Query(value="SELECT k.emplbrncode\n" +
            "  FROM tbkpi k\n" +
            " WHERE k.effectivemonth = (select max(kk.effectivemonth)\n" +
            "                             from tbkpi kk\n" +
            "                            where kk.effectiveyear =\n" +
            "                                  (select max(d.effectiveyear)\n" +
            "                                     from tbkpi d\n" +
            "                                    where d.emplid = kk.emplid)\n" +
            "                              and kk.emplid = k.emplid)\n" +
            "   and k.effectiveyear =\n" +
            "       (select max(d.effectiveyear) from tbkpi d where d.emplid = k.emplid)\n" +
            "   and k.emplId = :id\n", nativeQuery = true)
    public Optional<String> findTopEmplBrnCodeByEmplId(@Param("id") String id);

    @Query(value="SELECT t.id FROM tbkpi t WHERE t.effectiveyear = :year AND t.effectivemonth = :month AND t.emplpossition = :position AND t.emplid = :id", nativeQuery = true)
    Optional<Integer> findId(@Param("year") int year, @Param("month") int month, @Param("position") String position, @Param("id") String id);

    KpiModel findByDirectoridAndId(String directorid, long id);

    KpiModel findById(long id);

    List<KpiModel> findByEmplid(String emplid);

    List<KpiModel> findByDirectorid(String directorid);

    List<KpiModel> findByHubdirectorid(String hubdirectorid);

    // Ulziibuyan Add 2024/06/10
    void deleteByEmplidAndEffectiveyearAndEffectivemonthAndEmplpossition(String emplid, int effectiveYear, int effectiveMonth, String positionName);

}
