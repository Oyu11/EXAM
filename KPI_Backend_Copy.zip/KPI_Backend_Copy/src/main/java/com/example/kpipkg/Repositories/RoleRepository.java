package com.example.kpipkg.Repositories;

import com.example.kpipkg.Models.Role;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RoleRepository extends JpaRepository<Role, String> {
    Role findByRoleidIgnoreCase(String roleid);
    Role findByRoleidAndRolename(String roleid, String rolename);
}
