package com.example.kpipkg.Models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDateTime;

@Entity
@Table(name = "tbkpi",
        uniqueConstraints = {@UniqueConstraint(columnNames = {"effectiveyear", "effectivemonth", "emplid", "emplpossition"})}
)
public class KpiModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    long id;

    @Column(name = "emplbrncode")
    String emplbrncode;

    @Column(name = "directorid")     //  Ene talbaraar hailt hiine if role name equal to D
    String directorid;

    @Column(name = "directorname")
    String directorname;

    @Column(name = "hubcode")
    String hubcode;

    @Column(name = "hubdirectorid")   //  Ene talbaraar hailt hiine if role name equal to H
    String hubdirectorid;

    @Column(name = "hubdirectorname")
    String hubdirectorname;

    @Column(name = "emplid")          //  Ene talbaraar hailt hiine if role name equal to E
    String emplid;

    @Column(name = "emplname")
    String emplname;

    @Column(name = "emplpossition")
    String emplpossition;

    @Column(name = "emplstatus")
    String emplstatus;

    @Column(name = "scoreempl", columnDefinition = "integer default 0")
    double scoreempl;

    @Column(name = "scoredir", columnDefinition = "integer default 0")
    double scoredir;

    @Column(name = "scorehubdir", columnDefinition = "integer default 0")
    double scorehubdir;

    @Column(name = "scoretotal", columnDefinition = "integer default 0")
    double scoretotal;

    @Column(name = "effectivemonth")
    int effectivemonth;

    @Column(name = "effectiveyear")
    int effectiveyear;
    @Column(name = "col1", columnDefinition = "integer default 0")
    double col1;
    @Column(name = "col2", columnDefinition = "integer default 0")
    double col2;
    @Column(name = "col3", columnDefinition = "integer default 0")
    double col3;
    @Column(name = "col4", columnDefinition = "integer default 0")
    double col4;
    @Column(name = "col5", columnDefinition = "integer default 0")
    double col5;
    @Column(name = "col6", columnDefinition = "integer default 0")
    double col6;
    @Column(name = "col7", columnDefinition = "integer default 0")
    double col7;
    @Column(name = "col8", columnDefinition = "integer default 0")
    double col8;
    @Column(name = "col9", columnDefinition = "integer default 0")
    double col9;
    @Column(name = "col10", columnDefinition = "integer default 0")
    double col10;
    @Column(name = "col11", columnDefinition = "integer default 0")
    double col11;
    @Column(name = "col12", columnDefinition = "integer default 0")
    double col12;
    @Column(name = "col13", columnDefinition = "integer default 0")
    double col13;
    @Column(name = "col14", columnDefinition = "integer default 0")
    double col14;
    @Column(name = "col15", columnDefinition = "integer default 0")
    double col15;
    @Column(name = "col16", columnDefinition = "integer default 0")
    double col16;
    @Column(name = "col17", columnDefinition = "integer default 0")
    double col17;
    @Column(name = "col18", columnDefinition = "integer default 0")
    double col18;
    @Column(name = "col19", columnDefinition = "integer default 0")
    double col19;
    @Column(name = "col20", columnDefinition = "integer default 0")
    double col20;

    @Column(name = "col1_amount", columnDefinition = "integer default 0")
    double col1_amount;
    @Column(name = "col2_amount", columnDefinition = "integer default 0")
    double col2_amount;
    @Column(name = "col3_amount", columnDefinition = "integer default 0")
    double col3_amount;
    @Column(name = "col4_amount", columnDefinition = "integer default 0")
    double col4_amount;
    @Column(name = "col5_amount", columnDefinition = "integer default 0")
    double col5_amount;
    @Column(name = "col6_amount", columnDefinition = "integer default 0")
    double col6_amount;
    @Column(name = "col7_amount", columnDefinition = "integer default 0")
    double col7_amount;
    @Column(name = "col8_amount", columnDefinition = "integer default 0")
    double col8_amount;
    @Column(name = "col9_amount", columnDefinition = "integer default 0")
    double col9_amount;
    @Column(name = "col10_amount", columnDefinition = "integer default 0")
    double col10_amount;
    @Column(name = "col11_amount", columnDefinition = "integer default 0")
    double col11_amount;
    @Column(name = "col12_amount", columnDefinition = "integer default 0")
    double col12_amount;
    @Column(name = "col13_amount", columnDefinition = "integer default 0")
    double col13_amount;
    @Column(name = "col14_amount", columnDefinition = "integer default 0")
    double col14_amount;
    @Column(name = "col15_amount", columnDefinition = "integer default 0")
    double col15_amount;
    @Column(name = "col16_amount", columnDefinition = "integer default 0")
    double col16_amount;
    @Column(name = "col17_amount", columnDefinition = "integer default 0")
    double col17_amount;
    @Column(name = "col18_amount", columnDefinition = "integer default 0")
    double col18_amount;
    @Column(name = "col19_amount", columnDefinition = "integer default 0")
    double col19_amount;
    @Column(name = "col20_amount", columnDefinition = "integer default 0")
    double col20_amount;

    @Column(name = "scorenumber1_amount", columnDefinition = "integer default 0")
    double scorenumber1_amount;
    @Column(name = "scorenumber2_amount", columnDefinition = "integer default 0")
    double scorenumber2_amount;
    @Column(name = "scorenumber3_amount", columnDefinition = "integer default 0")
    double scorenumber3_amount;
    @Column(name = "scorenumber4_amount", columnDefinition = "integer default 0")
    double scorenumber4_amount;
    @Column(name = "scorenumber5_amount", columnDefinition = "integer default 0")
    double scorenumber5_amount;
    @Column(name = "scorenumber6_amount", columnDefinition = "integer default 0")
    double scorenumber6_amount;
    @Column(name = "scorenumber7_amount", columnDefinition = "integer default 0")
    double scorenumber7_amount;
    @Column(name = "scorenumber8_amount", columnDefinition = "integer default 0")
    double scorenumber8_amount;
    @Column(name = "scorenumber9_amount", columnDefinition = "integer default 0")
    double scorenumber9_amount;
    @Column(name = "scorenumber10_amount", columnDefinition = "integer default 0")
    double scorenumber10_amount;
    @Column(name = "scorenumber11_amount", columnDefinition = "integer default 0")
    double scorenumber11_amount;
    @Column(name = "scorenumber12_amount", columnDefinition = "integer default 0")
    double scorenumber12_amount;
    @Column(name = "scorenumber13_amount", columnDefinition = "integer default 0")
    double scorenumber13_amount;
    @Column(name = "scorenumber14_amount", columnDefinition = "integer default 0")
    double scorenumber14_amount;
    @Column(name = "scorenumber15_amount", columnDefinition = "integer default 0")
    double scorenumber15_amount;
    @Column(name = "scorenumber16_amount", columnDefinition = "integer default 0")
    double scorenumber16_amount;
    @Column(name = "scorenumber17_amount", columnDefinition = "integer default 0")
    double scorenumber17_amount;
    @Column(name = "scorenumber18_amount", columnDefinition = "integer default 0")
    double scorenumber18_amount;
    @Column(name = "scorenumber19_amount", columnDefinition = "integer default 0")
    double scorenumber19_amount;
    @Column(name = "scorenumber20_amount", columnDefinition = "integer default 0")
    double scorenumber20_amount;


    @Column(name = "isconfirmed")
    char isconfirmed;
    @Column(name = "isconfirmedhub")
    char isconfirmedhub;
    @Column(name = "iskpi")
    String iskpi;
    @Column(name = "commentbyemployee")
    String commentbyemployee;
    @Column(name = "commentbydirector")
    String commentbydirector;
    @Column(name = "commentbydirectorhub")
    String commentbydirectorhub;
    @Column(name = "commentbyallbrnmanager")
    String commentbyallbrnmanager;
    @CreatedDate
    @Column(name = "createddt", updatable = false)   // nullable = false,
    private LocalDateTime createddt;
    @Column(name = "createuser")    // nullable = false,
    private String createuser;
    @LastModifiedDate
    @Column(name = "modifieddt")
    private LocalDateTime modifieddt;
    @Column(name = "modifieduser")  // , nullable = false
    private String modifieduser;


    public KpiModel() {
        super();
        // TODO Auto-generated constructor stub
    }

    public double getScorehubdir() {
        return scorehubdir;
    }

    public void setScorehubdir(double scorehubdir) {
        this.scorehubdir = scorehubdir;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getEmplbrncode() {
        return emplbrncode;
    }

    public void setEmplbrncode(String emplbrncode) {
        this.emplbrncode = emplbrncode;
    }

    public String getDirectorid() {
        return directorid;
    }

    public void setDirectorid(String directorid) {
        this.directorid = directorid;
    }

    public String getHubcode() {
        return hubcode;
    }

    public void setHubcode(String hubcode) {
        this.hubcode = hubcode;
    }

    public String getHubdirectorid() {
        return hubdirectorid;
    }

    public void setHubdirectorid(String hubdirectorid) {
        this.hubdirectorid = hubdirectorid;
    }

    public String getEmplid() {
        return emplid;
    }

    public void setEmplid(String emplid) {
        this.emplid = emplid;
    }

    public String getEmplname() {
        return emplname;
    }

    public void setEmplname(String emplname) {
        this.emplname = emplname;
    }

    public String getEmplpossition() {
        return emplpossition;
    }

    public void setEmplpossition(String emplpossition) {
        this.emplpossition = emplpossition;
    }

    public String getEmplstatus() {
        return emplstatus;
    }

    public void setEmplstatus(String emplstatus) {
        this.emplstatus = emplstatus;
    }

    public double getScoreempl() {
        return scoreempl;
    }

    public void setScoreempl(double scoreempl) {
        this.scoreempl = scoreempl;
    }

    public double getScoredir() {
        return scoredir;
    }

    public void setScoredir(double scoredir) {
        this.scoredir = scoredir;
    }

    public double getScoretotal() {
        return scoretotal;
    }

    public void setScoretotal(double scoretotal) {
        this.scoretotal = scoretotal;
    }

    public int getEffectivemonth() {
        return effectivemonth;
    }

    public void setEffectivemonth(int effectivemonth) {
        this.effectivemonth = effectivemonth;
    }

    public int getEffectiveyear() {
        return effectiveyear;
    }

    public void setEffectiveyear(int effectiveyear) {
        this.effectiveyear = effectiveyear;
    }

    public double getCol1() {
        return col1;
    }

    public void setCol1(double col1) {
        this.col1 = col1;
    }

    public double getCol2() {
        return col2;
    }

    public void setCol2(double col2) {
        this.col2 = col2;
    }

    public double getCol3() {
        return col3;
    }

    public void setCol3(double col3) {
        this.col3 = col3;
    }

    public double getCol4() {
        return col4;
    }

    public void setCol4(double col4) {
        this.col4 = col4;
    }

    public double getCol5() {
        return col5;
    }

    public void setCol5(double col5) {
        this.col5 = col5;
    }

    public double getCol6() {
        return col6;
    }

    public void setCol6(double col6) {
        this.col6 = col6;
    }

    public double getCol7() {
        return col7;
    }

    public void setCol7(double col7) {
        this.col7 = col7;
    }

    public double getCol8() {
        return col8;
    }

    public void setCol8(double col8) {
        this.col8 = col8;
    }

    public double getCol9() {
        return col9;
    }

    public void setCol9(double col9) {
        this.col9 = col9;
    }

    public double getCol10() {
        return col10;
    }

    public void setCol10(double col10) {
        this.col10 = col10;
    }

    public double getCol11() {
        return col11;
    }

    public void setCol11(double col11) {
        this.col11 = col11;
    }

    public double getCol12() {
        return col12;
    }

    public void setCol12(double col12) {
        this.col12 = col12;
    }

    public double getCol13() {
        return col13;
    }

    public void setCol13(double col13) {
        this.col13 = col13;
    }

    public double getCol14() {
        return col14;
    }

    public void setCol14(double col14) {
        this.col14 = col14;
    }

    public double getCol15() {
        return col15;
    }

    public void setCol15(double col15) {
        this.col15 = col15;
    }

    public double getCol16() {
        return col16;
    }

    public void setCol16(double col16) {
        this.col16 = col16;
    }

    public double getCol17() {
        return col17;
    }

    public void setCol17(double col17) {
        this.col17 = col17;
    }

    public double getCol18() {
        return col18;
    }

    public void setCol18(double col18) {
        this.col18 = col18;
    }

    public double getCol19() {
        return col19;
    }

    public void setCol19(double col19) {
        this.col19 = col19;
    }

    public double getCol20() {
        return col20;
    }

    public void setCol20(double col20) {
        this.col20 = col20;
    }

    public double getCol1_amount() {
        return col1_amount;
    }

    public void setCol1_amount(double col1_amount) {
        this.col1_amount = col1_amount;
    }

    public double getCol2_amount() {
        return col2_amount;
    }

    public void setCol2_amount(double col2_amount) {
        this.col2_amount = col2_amount;
    }

    public double getCol3_amount() {
        return col3_amount;
    }

    public void setCol3_amount(double col3_amount) {
        this.col3_amount = col3_amount;
    }

    public double getCol4_amount() {
        return col4_amount;
    }

    public void setCol4_amount(double col4_amount) {
        this.col4_amount = col4_amount;
    }

    public double getCol5_amount() {
        return col5_amount;
    }

    public void setCol5_amount(double col5_amount) {
        this.col5_amount = col5_amount;
    }

    public double getCol6_amount() {
        return col6_amount;
    }

    public void setCol6_amount(double col6_amount) {
        this.col6_amount = col6_amount;
    }

    public double getCol7_amount() {
        return col7_amount;
    }

    public void setCol7_amount(double col7_amount) {
        this.col7_amount = col7_amount;
    }

    public double getCol8_amount() {
        return col8_amount;
    }

    public void setCol8_amount(double col8_amount) {
        this.col8_amount = col8_amount;
    }

    public double getCol9_amount() {
        return col9_amount;
    }

    public void setCol9_amount(double col9_amount) {
        this.col9_amount = col9_amount;
    }

    public double getCol10_amount() {
        return col10_amount;
    }

    public void setCol10_amount(double col10_amount) {
        this.col10_amount = col10_amount;
    }

    public double getCol11_amount() {
        return col11_amount;
    }

    public void setCol11_amount(double col11_amount) {
        this.col11_amount = col11_amount;
    }

    public double getCol12_amount() {
        return col12_amount;
    }

    public void setCol12_amount(double col12_amount) {
        this.col12_amount = col12_amount;
    }

    public double getCol13_amount() {
        return col13_amount;
    }

    public void setCol13_amount(double col13_amount) {
        this.col13_amount = col13_amount;
    }

    public double getCol14_amount() {
        return col14_amount;
    }

    public void setCol14_amount(double col14_amount) {
        this.col14_amount = col14_amount;
    }

    public double getCol15_amount() {
        return col15_amount;
    }

    public void setCol15_amount(double col15_amount) {
        this.col15_amount = col15_amount;
    }

    public double getCol16_amount() {
        return col16_amount;
    }

    public void setCol16_amount(double col16_amount) {
        this.col16_amount = col16_amount;
    }

    public double getCol17_amount() {
        return col17_amount;
    }

    public void setCol17_amount(double col17_amount) {
        this.col17_amount = col17_amount;
    }

    public double getCol18_amount() {
        return col18_amount;
    }

    public void setCol18_amount(double col18_amount) {
        this.col18_amount = col18_amount;
    }

    public double getCol19_amount() {
        return col19_amount;
    }

    public void setCol19_amount(double col19_amount) {
        this.col19_amount = col19_amount;
    }

    public double getCol20_amount() {
        return col20_amount;
    }

    public void setCol20_amount(double col20_amount) {
        this.col20_amount = col20_amount;
    }

    public char getIsconfirmed() {
        return isconfirmed;
    }

    public void setIsconfirmed(char isconfirmed) {
        this.isconfirmed = isconfirmed;
    }

    public char getIsconfirmedhub() {
        return isconfirmedhub;
    }

    public void setIsconfirmedhub(char isconfirmedhub) {
        this.isconfirmedhub = isconfirmedhub;
    }

    public String getIskpi() {
        return iskpi;
    }

    public void setIskpi(String iskpi) {
        this.iskpi = iskpi;
    }

    public String getCommentbyemployee() {
        return commentbyemployee;
    }

    public void setCommentbyemployee(String commentbyemployee) {
        this.commentbyemployee = commentbyemployee;
    }

    public String getCommentbydirector() {
        return commentbydirector;
    }

    public void setCommentbydirector(String commentbydirector) {
        this.commentbydirector = commentbydirector;
    }

    public String getCommentbydirectorhub() {
        return commentbydirectorhub;
    }

    public void setCommentbydirectorhub(String commentbydirectorhub) {
        this.commentbydirectorhub = commentbydirectorhub;
    }

    public String getCommentbyallbrnmanager() {
        return commentbyallbrnmanager;
    }

    public void setCommentbyallbrnmanager(String commentbyallbrnmanager) {
        this.commentbyallbrnmanager = commentbyallbrnmanager;
    }

    public LocalDateTime getCreateddt() {
        return createddt;
    }

    public void setCreateddt(LocalDateTime createddt) {
        this.createddt = createddt;
    }

    public String getCreateuser() {
        return createuser;
    }

    public void setCreateuser(String createuser) {
        this.createuser = createuser;
    }

    public LocalDateTime getModifieddt() {
        return modifieddt;
    }

    public void setModifieddt(LocalDateTime modifieddt) {
        this.modifieddt = modifieddt;
    }

    public String getModifieduser() {
        return modifieduser;
    }

    public void setModifieduser(String modifieduser) {
        this.modifieduser = modifieduser;
    }

    public double getScorenumber1_amount() {
        return scorenumber1_amount;
    }

    public void setScorenumber1_amount(double scorenumber1_amount) {
        this.scorenumber1_amount = scorenumber1_amount;
    }

    public double getScorenumber2_amount() {
        return scorenumber2_amount;
    }

    public void setScorenumber2_amount(double scorenumber2_amount) {
        this.scorenumber2_amount = scorenumber2_amount;
    }

    public double getScorenumber3_amount() {
        return scorenumber3_amount;
    }

    public void setScorenumber3_amount(double scorenumber3_amount) {
        this.scorenumber3_amount = scorenumber3_amount;
    }

    public double getScorenumber4_amount() {
        return scorenumber4_amount;
    }

    public void setScorenumber4_amount(double scorenumber4_amount) {
        this.scorenumber4_amount = scorenumber4_amount;
    }

    public double getScorenumber5_amount() {
        return scorenumber5_amount;
    }

    public void setScorenumber5_amount(double scorenumber5_amount) {
        this.scorenumber5_amount = scorenumber5_amount;
    }

    public double getScorenumber6_amount() {
        return scorenumber6_amount;
    }

    public void setScorenumber6_amount(double scorenumber6_amount) {
        this.scorenumber6_amount = scorenumber6_amount;
    }

    public double getScorenumber7_amount() {
        return scorenumber7_amount;
    }

    public void setScorenumber7_amount(double scorenumber7_amount) {
        this.scorenumber7_amount = scorenumber7_amount;
    }

    public double getScorenumber8_amount() {
        return scorenumber8_amount;
    }

    public void setScorenumber8_amount(double scorenumber8_amount) {
        this.scorenumber8_amount = scorenumber8_amount;
    }

    public double getScorenumber9_amount() {
        return scorenumber9_amount;
    }

    public void setScorenumber9_amount(double scorenumber9_amount) {
        this.scorenumber9_amount = scorenumber9_amount;
    }

    public double getScorenumber10_amount() {
        return scorenumber10_amount;
    }

    public void setScorenumber10_amount(double scorenumber10_amount) {
        this.scorenumber10_amount = scorenumber10_amount;
    }

    public double getScorenumber11_amount() {
        return scorenumber11_amount;
    }

    public void setScorenumber11_amount(double scorenumber11_amount) {
        this.scorenumber11_amount = scorenumber11_amount;
    }

    public double getScorenumber12_amount() {
        return scorenumber12_amount;
    }

    public void setScorenumber12_amount(double scorenumber12_amount) {
        this.scorenumber12_amount = scorenumber12_amount;
    }

    public double getScorenumber13_amount() {
        return scorenumber13_amount;
    }

    public void setScorenumber13_amount(double scorenumber13_amount) {
        this.scorenumber13_amount = scorenumber13_amount;
    }

    public double getScorenumber14_amount() {
        return scorenumber14_amount;
    }

    public void setScorenumber14_amount(double scorenumber14_amount) {
        this.scorenumber14_amount = scorenumber14_amount;
    }

    public double getScorenumber15_amount() {
        return scorenumber15_amount;
    }

    public void setScorenumber15_amount(double scorenumber15_amount) {
        this.scorenumber15_amount = scorenumber15_amount;
    }

    public double getScorenumber16_amount() {
        return scorenumber16_amount;
    }

    public void setScorenumber16_amount(double scorenumber16_amount) {
        this.scorenumber16_amount = scorenumber16_amount;
    }

    public double getScorenumber17_amount() {
        return scorenumber17_amount;
    }

    public void setScorenumber17_amount(double scorenumber17_amount) {
        this.scorenumber17_amount = scorenumber17_amount;
    }

    public double getScorenumber18_amount() {
        return scorenumber18_amount;
    }

    public void setScorenumber18_amount(double scorenumber18_amount) {
        this.scorenumber18_amount = scorenumber18_amount;
    }

    public double getScorenumber19_amount() {
        return scorenumber19_amount;
    }

    public void setScorenumber19_amount(double scorenumber19_amount) {
        this.scorenumber19_amount = scorenumber19_amount;
    }

    public double getScorenumber20_amount() {
        return scorenumber20_amount;
    }

    public void setScorenumber20_amount(double scorenumber20_amount) {
        this.scorenumber20_amount = scorenumber20_amount;
    }

    public String getDirectorname() {
        return directorname;
    }

    public void setDirectorname(String directorname) {
        this.directorname = directorname;
    }

    public String getHubdirectorname() {
        return hubdirectorname;
    }

    public void setHubdirectorname(String hubdirectorname) {
        this.hubdirectorname = hubdirectorname;
    }

    @Override
    public String toString() {
        return "KpiModel{" +
                "id=" + id +
                ", emplbrncode='" + emplbrncode + '\'' +
                ", directorid='" + directorid + '\'' +
                ", directorname='" + directorname + '\'' +
                ", hubcode='" + hubcode + '\'' +
                ", hubdirectorid='" + hubdirectorid + '\'' +
                ", hubdirectorname='" + hubdirectorname + '\'' +
                ", emplid='" + emplid + '\'' +
                ", emplname='" + emplname + '\'' +
                ", emplpossition='" + emplpossition + '\'' +
                ", emplstatus='" + emplstatus + '\'' +
                ", scoreempl=" + scoreempl +
                ", scoredir=" + scoredir +
                ", scorehubdir=" + scorehubdir +
                ", scoretotal=" + scoretotal +
                ", effectivemonth=" + effectivemonth +
                ", effectiveyear=" + effectiveyear +
                ", col1=" + col1 +
                ", col2=" + col2 +
                ", col3=" + col3 +
                ", col4=" + col4 +
                ", col5=" + col5 +
                ", col6=" + col6 +
                ", col7=" + col7 +
                ", col8=" + col8 +
                ", col9=" + col9 +
                ", col10=" + col10 +
                ", col11=" + col11 +
                ", col12=" + col12 +
                ", col13=" + col13 +
                ", col14=" + col14 +
                ", col15=" + col15 +
                ", col16=" + col16 +
                ", col17=" + col17 +
                ", col18=" + col18 +
                ", col19=" + col19 +
                ", col20=" + col20 +
                ", col1_amount=" + col1_amount +
                ", col2_amount=" + col2_amount +
                ", col3_amount=" + col3_amount +
                ", col4_amount=" + col4_amount +
                ", col5_amount=" + col5_amount +
                ", col6_amount=" + col6_amount +
                ", col7_amount=" + col7_amount +
                ", col8_amount=" + col8_amount +
                ", col9_amount=" + col9_amount +
                ", col10_amount=" + col10_amount +
                ", col11_amount=" + col11_amount +
                ", col12_amount=" + col12_amount +
                ", col13_amount=" + col13_amount +
                ", col14_amount=" + col14_amount +
                ", col15_amount=" + col15_amount +
                ", col16_amount=" + col16_amount +
                ", col17_amount=" + col17_amount +
                ", col18_amount=" + col18_amount +
                ", col19_amount=" + col19_amount +
                ", col20_amount=" + col20_amount +
                ", scorenumber1_amount=" + scorenumber1_amount +
                ", scorenumber2_amount=" + scorenumber2_amount +
                ", scorenumber3_amount=" + scorenumber3_amount +
                ", scorenumber4_amount=" + scorenumber4_amount +
                ", scorenumber5_amount=" + scorenumber5_amount +
                ", scorenumber6_amount=" + scorenumber6_amount +
                ", scorenumber7_amount=" + scorenumber7_amount +
                ", scorenumber8_amount=" + scorenumber8_amount +
                ", scorenumber9_amount=" + scorenumber9_amount +
                ", scorenumber10_amount=" + scorenumber10_amount +
                ", scorenumber11_amount=" + scorenumber11_amount +
                ", scorenumber12_amount=" + scorenumber12_amount +
                ", scorenumber13_amount=" + scorenumber13_amount +
                ", scorenumber14_amount=" + scorenumber14_amount +
                ", scorenumber15_amount=" + scorenumber15_amount +
                ", scorenumber16_amount=" + scorenumber16_amount +
                ", scorenumber17_amount=" + scorenumber17_amount +
                ", scorenumber18_amount=" + scorenumber18_amount +
                ", scorenumber19_amount=" + scorenumber19_amount +
                ", scorenumber20_amount=" + scorenumber20_amount +
                ", isconfirmed=" + isconfirmed +
                ", isconfirmedhub=" + isconfirmedhub +
                ", iskpi='" + iskpi + '\'' +
                ", commentbyemployee='" + commentbyemployee + '\'' +
                ", commentbydirector='" + commentbydirector + '\'' +
                ", commentbydirectorhub='" + commentbydirectorhub + '\'' +
                ", commentbyallbrnmanager='" + commentbyallbrnmanager + '\'' +
                ", createddt=" + createddt +
                ", createuser='" + createuser + '\'' +
                ", modifieddt=" + modifieddt +
                ", modifieduser='" + modifieduser + '\'' +
                '}';
    }

    public KpiModel(long id, String emplbrncode, String directorid, String directorname, String hubcode, String hubdirectorid, String hubdirectorname, String emplid, String emplname, String emplpossition, String emplstatus, double scoreempl, double scoredir, double scorehubdir, double scoretotal, int effectivemonth, int effectiveyear, double col1, double col2, double col3, double col4, double col5, double col6, double col7, double col8, double col9, double col10, double col11, double col12, double col13, double col14, double col15, double col16, double col17, double col18, double col19, double col20, double col1_amount, double col2_amount, double col3_amount, double col4_amount, double col5_amount, double col6_amount, double col7_amount, double col8_amount, double col9_amount, double col10_amount, double col11_amount, double col12_amount, double col13_amount, double col14_amount, double col15_amount, double col16_amount, double col17_amount, double col18_amount, double col19_amount, double col20_amount, double scorenumber1_amount, double scorenumber2_amount, double scorenumber3_amount, double scorenumber4_amount, double scorenumber5_amount, double scorenumber6_amount, double scorenumber7_amount, double scorenumber8_amount, double scorenumber9_amount, double scorenumber10_amount, double scorenumber11_amount, double scorenumber12_amount, double scorenumber13_amount, double scorenumber14_amount, double scorenumber15_amount, double scorenumber16_amount, double scorenumber17_amount, double scorenumber18_amount, double scorenumber19_amount, double scorenumber20_amount, char isconfirmed, char isconfirmedhub, String iskpi, String commentbyemployee, String commentbydirector, String commentbydirectorhub, String commentbyallbrnmanager, LocalDateTime createddt, String createuser, LocalDateTime modifieddt, String modifieduser) {
        this.id = id;
        this.emplbrncode = emplbrncode;
        this.directorid = directorid;
        this.directorname = directorname;
        this.hubcode = hubcode;
        this.hubdirectorid = hubdirectorid;
        this.hubdirectorname = hubdirectorname;
        this.emplid = emplid;
        this.emplname = emplname;
        this.emplpossition = emplpossition;
        this.emplstatus = emplstatus;
        this.scoreempl = scoreempl;
        this.scoredir = scoredir;
        this.scorehubdir = scorehubdir;
        this.scoretotal = scoretotal;
        this.effectivemonth = effectivemonth;
        this.effectiveyear = effectiveyear;
        this.col1 = col1;
        this.col2 = col2;
        this.col3 = col3;
        this.col4 = col4;
        this.col5 = col5;
        this.col6 = col6;
        this.col7 = col7;
        this.col8 = col8;
        this.col9 = col9;
        this.col10 = col10;
        this.col11 = col11;
        this.col12 = col12;
        this.col13 = col13;
        this.col14 = col14;
        this.col15 = col15;
        this.col16 = col16;
        this.col17 = col17;
        this.col18 = col18;
        this.col19 = col19;
        this.col20 = col20;
        this.col1_amount = col1_amount;
        this.col2_amount = col2_amount;
        this.col3_amount = col3_amount;
        this.col4_amount = col4_amount;
        this.col5_amount = col5_amount;
        this.col6_amount = col6_amount;
        this.col7_amount = col7_amount;
        this.col8_amount = col8_amount;
        this.col9_amount = col9_amount;
        this.col10_amount = col10_amount;
        this.col11_amount = col11_amount;
        this.col12_amount = col12_amount;
        this.col13_amount = col13_amount;
        this.col14_amount = col14_amount;
        this.col15_amount = col15_amount;
        this.col16_amount = col16_amount;
        this.col17_amount = col17_amount;
        this.col18_amount = col18_amount;
        this.col19_amount = col19_amount;
        this.col20_amount = col20_amount;
        this.scorenumber1_amount = scorenumber1_amount;
        this.scorenumber2_amount = scorenumber2_amount;
        this.scorenumber3_amount = scorenumber3_amount;
        this.scorenumber4_amount = scorenumber4_amount;
        this.scorenumber5_amount = scorenumber5_amount;
        this.scorenumber6_amount = scorenumber6_amount;
        this.scorenumber7_amount = scorenumber7_amount;
        this.scorenumber8_amount = scorenumber8_amount;
        this.scorenumber9_amount = scorenumber9_amount;
        this.scorenumber10_amount = scorenumber10_amount;
        this.scorenumber11_amount = scorenumber11_amount;
        this.scorenumber12_amount = scorenumber12_amount;
        this.scorenumber13_amount = scorenumber13_amount;
        this.scorenumber14_amount = scorenumber14_amount;
        this.scorenumber15_amount = scorenumber15_amount;
        this.scorenumber16_amount = scorenumber16_amount;
        this.scorenumber17_amount = scorenumber17_amount;
        this.scorenumber18_amount = scorenumber18_amount;
        this.scorenumber19_amount = scorenumber19_amount;
        this.scorenumber20_amount = scorenumber20_amount;
        this.isconfirmed = isconfirmed;
        this.isconfirmedhub = isconfirmedhub;
        this.iskpi = iskpi;
        this.commentbyemployee = commentbyemployee;
        this.commentbydirector = commentbydirector;
        this.commentbydirectorhub = commentbydirectorhub;
        this.commentbyallbrnmanager = commentbyallbrnmanager;
        this.createddt = createddt;
        this.createuser = createuser;
        this.modifieddt = modifieddt;
        this.modifieduser = modifieduser;
    }
}



