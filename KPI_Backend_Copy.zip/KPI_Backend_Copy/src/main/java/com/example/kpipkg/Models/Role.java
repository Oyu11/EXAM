package com.example.kpipkg.Models;

import jakarta.persistence.*;

@Entity
@Table(name = "tbroles")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    long id;

    @Column(name = "roleid")
    private String roleid;

    @Column(name = "scoremin")
    private double scoremin;

    @Column(name = "scoremax")
    private double scoremax;

    @Column(name = "checked", nullable = false)
    private boolean checked;

    @Column(name = "rolename")
    private String rolename;

    // Getters and Setters
    public String getRoleid() {
        return roleid;
    }

    public void setRoleid(String roleid) {
        this.roleid = roleid;
    }

    public double getScoremin() {
        return scoremin;
    }

    public void setScoremin(double scoremin) {
        this.scoremin = scoremin;
    }

    public double getScoremax() {
        return scoremax;
    }

    public void setScoremax(double scoremax) {
        this.scoremax = scoremax;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public String getRolename() {
        return rolename;
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }

    // Constructors
    public Role(String roleid, double scoremin, double scoremax, boolean checked, String rolename) {
        this.roleid = roleid;
        this.scoremin = scoremin;
        this.scoremax = scoremax;
        this.checked = checked;
        this.rolename = rolename;
    }

    public Role() {
        super();
    }

    @Override
    public String toString() {
        return "Role{" +
                "roleid='" + roleid + '\'' +
                ", scoremin=" + scoremin +
                ", scoremax=" + scoremax +
                ", checked=" + checked +
                ", rolename='" + rolename + '\'' +
                '}';
    }
}
