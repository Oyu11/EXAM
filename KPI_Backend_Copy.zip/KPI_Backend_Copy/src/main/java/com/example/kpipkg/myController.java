package com.example.kpipkg;

import Response.*;
import com.example.kpipkg.Models.KpiFields;
import com.example.kpipkg.Models.KpiModel;
import com.example.kpipkg.Models.Role;
import com.example.kpipkg.Models.UserSessionData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Console;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@CrossOrigin(origins = {"*"})
@RestController
public class myController {
    @Autowired
    KpiService kpiService;

    @PostMapping(path = "/Login")
    ResponseLogin LoginLDAP(@RequestParam String empldid, @RequestParam String pwd) {
        System.out.println("test");
        return kpiService.Login(empldid, pwd);
    }


    @GetMapping(path = "/GetKpi_Fields")
    ResponseFields GetKpiFields(@RequestParam int year, @RequestParam int month, @RequestParam String sessionid) {
        ResponseCode rCode = ResponseCodes.NoFound_Session.getResponseCode();
        List<KpiFields> lstFields = new ArrayList<>();

        UserSessionData userSessionData = CheckValidation(sessionid);
        System.out.println("sessionID in");
        if (userSessionData.getEmplid() != "") {
            System.out.println(userSessionData.getEmplid());
            lstFields = kpiService.GetFieldsData(year, month, userSessionData);
            if (lstFields.size() > 0) {
                rCode = ResponseCodes.Success.getResponseCode();
            } else {
                rCode = ResponseCodes.NoFound_Data.getResponseCode();
            }
        }
        return new ResponseFields(rCode, lstFields);
    }



    @PostMapping(path = "/SaveKpiField")
    ResponseCode SaveKpiField(@RequestParam String sessionid, @RequestBody KpiFields kpiField) {
        ResponseCode rCode = ResponseCodes.NoFound_Session.getResponseCode();
        UserSessionData userSessionData = CheckValidation(sessionid);
        if (userSessionData.getEmplid() != "") {
            System.out.println("D3");
            rCode = kpiService.SaveKpiField(userSessionData, kpiField);
            System.out.println("D4");
        }
        return rCode;
    }


    private UserSessionData CheckValidation(String sessionid) {
        UserSessionData rslt = new UserSessionData(true);
        if (sessionid != null && sessionid != "") {
            rslt = kpiService.getUserSessionData(sessionid);
            if (rslt == null) rslt = new UserSessionData(true);
        }
        return rslt;
    }

    // @GetMapping(path = "/SaveComment")
    private ResponseCode SaveComment(@RequestParam String sessionid, @RequestParam long kpiid, @RequestParam String comment) {
        ResponseCode rCode = ResponseCodes.NoFound_Session.getResponseCode();
        UserSessionData userSessionData = CheckValidation(sessionid);
        if (userSessionData.getEmplid() != "") {
            rCode = kpiService.SaveCommentEmlpyee(userSessionData, kpiid, comment);
        }
        return rCode;
    }


    @PostMapping(path = "/GetKpiData")
    RespondGetData GetData(@RequestParam int year, @RequestParam int month, @RequestParam String position, @RequestParam String sessionid) {

        List<KpiModel> lstKpiData = Collections.emptyList();
        List<KpiFields> lstKpiFields = Collections.emptyList();

        ResponseCode rCode = ResponseCodes.NoFound.getResponseCode();
        RespondGetData respondGetData = new RespondGetData(rCode, lstKpiData, lstKpiFields);
        UserSessionData userSessionData = CheckValidation(sessionid);

        if (userSessionData.getEmplid() != "") {
            lstKpiData = kpiService.GetData(year, month, position, userSessionData);

            if (lstKpiData.size() == 0) rCode = ResponseCodes.NoFound_Data.getResponseCode();
            else {
                if(position.equals("ALL")){
                    rCode = ResponseCodes.Success_GetList.getResponseCode();
                }
                else{
                    lstKpiFields = kpiService.GetAllFieldsTitle(year, month, position);
                    // lstKpiFields = kpiService.GetAllFieldsTitle();
                    if (lstKpiFields.size() != 0) {
                        //	lstKpiComments = kpiService.getComments(userSessionData );
                        rCode = ResponseCodes.Success_GetList.getResponseCode();
                    }
                }
            }
            respondGetData.setResponsecode(rCode);
            respondGetData.setLstKpiModel(lstKpiData);
            respondGetData.setLstKpiFields(lstKpiFields);
        }
        return respondGetData;
    }

    @PostMapping(path = "/SaveKpiDetails")
    ResponseCode SaveKpiDetails(@RequestBody List<KpiModel> lstKpi, @RequestParam String sessionid) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        UserSessionData userSessionData = CheckValidation(sessionid);
        if (userSessionData.getEmplid() != "") {
            rCode = kpiService.SaveKpiDetails(lstKpi, userSessionData);
        } else {
            rCode = ResponseCodes.NoFound_Session.getResponseCode();
        }
        return rCode;
    }

    //Ulzii Add
    @PostMapping(path = "/SaveKpiDetail")
    ResponseCode SaveKpiDetail(@RequestBody KpiModel lstKpi, @RequestParam String sessionid) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        UserSessionData userSessionData = CheckValidation(sessionid);
        if (userSessionData.getEmplid() != "") {
            rCode = kpiService.SaveKpiDetail(lstKpi, userSessionData);
        } else {
            rCode = ResponseCodes.NoFound_Session.getResponseCode();
        }
        return rCode;
    }

    @GetMapping(path="/GetUndo")
    ResponseCode GetUndo(@RequestParam String sessionid, @RequestParam int year, @RequestParam int month, @RequestParam String emplid, @RequestParam String emposition){
        ResponseCode rCode = ResponseCodes.NoFound_Session.getResponseCode();
        List<KpiFields> lstFields = new ArrayList<>();
        UserSessionData userSessionData = CheckValidation(sessionid);
        if(userSessionData.getEmplid().isEmpty() == false) {
            System.out.println("Start here");
            System.out.println(emplid);
            rCode = kpiService.GetUndo(year, month, userSessionData, emplid, emposition);
        }
        else {
            rCode = ResponseCodes.NoFound_Session.getResponseCode();
        }
        return rCode;
    }


    //Ulzii end


    @GetMapping(path = "/GetScore")
    private ResponseRole GetScore(@RequestParam String sessionid, @RequestParam String role_name) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        List<Role> lstRoleTemp = new ArrayList<Role>();

        UserSessionData userSessionData = CheckValidation(sessionid);
        System.out.println(" debug 3. " + userSessionData.toString());
        if (userSessionData.getEmplid() != "") {
            lstRoleTemp = kpiService.GetScore(userSessionData, role_name);
            rCode = ResponseCodes.Success.getResponseCode();
            System.out.println(lstRoleTemp);
            System.out.println(" debug 3 end here. " );
        } else {
            rCode = ResponseCodes.NoFound_Session.getResponseCode();
        }
        return new ResponseRole(rCode, lstRoleTemp);

    }


    @PostMapping(path = "/SaveScore")
    private ResponseCode SetScore(@RequestBody List<Role> lstRole, @RequestParam String sessionid) {
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        UserSessionData userSessionData = CheckValidation(sessionid);
        System.out.println("____________ debug 3. " + lstRole);
        if (userSessionData.getEmplid() != "") {
            rCode = kpiService.SaveScore(userSessionData, lstRole);
        } else {
            rCode = ResponseCodes.NoFound_Session.getResponseCode();
        }
        return rCode;
    }


    //@PostMapping(path = "/UpdateListKPI")
    private ResponseCode UpdateListKPI(@RequestBody List<KpiModel> lstKpi, @RequestParam String sessionid) {
        List<KpiModel> lstKpiData = Collections.emptyList();
        List<KpiFields> lstKpiFields = Collections.emptyList();
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        RespondGetData respondGetData = new RespondGetData(rCode, lstKpiData, lstKpiFields);

        UserSessionData userSessionData = CheckValidation(sessionid);
        if (userSessionData.getEmplid() != "") {
            if (userSessionData.getRoleid().equals(Roles.ALLBranchManager.getRoleName())) {
                rCode = kpiService.UpdateKpiDataByALLBranchManager(lstKpi, userSessionData);
            } else rCode = ResponseCodes.NoFound_Data.getResponseCode();
        } else {
            rCode = ResponseCodes.NoFound_Session.getResponseCode();
        }
        return rCode;
    }

    @PostMapping(path = "/DeleteInformation")
    private  ResponseCode DeleteInformation(@RequestParam int year, @RequestParam int month, @RequestParam String sessionid, @RequestBody KpiModel lstKpi){
        ResponseCode rCode = ResponseCodes.Error.getResponseCode();
        UserSessionData userSessionData = CheckValidation(sessionid);
        if (userSessionData.getEmplid() != "") {
            rCode = kpiService.DeleteInformation(lstKpi, userSessionData, year, month);
        } else {
            rCode = ResponseCodes.NoFound_Session.getResponseCode();
        }
        return rCode;
    }

}
