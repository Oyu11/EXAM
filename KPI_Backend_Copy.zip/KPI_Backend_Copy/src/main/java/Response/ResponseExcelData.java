package Response;

import com.example.kpipkg.Models.KpiFields;
import com.example.kpipkg.Models.KpiModel;

import java.util.List;

public class ResponseExcelData {
    ResponseCode responsecode;
    List<KpiModel> lstKpiModel;

    public ResponseExcelData(ResponseCode responsecode, List<KpiModel> lstKpiModel) {
        this.responsecode = responsecode;
        this.lstKpiModel = lstKpiModel;
    }

    public ResponseExcelData() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ResponseCode getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(ResponseCode responsecode) {
        this.responsecode = responsecode;
    }

    public List<KpiModel> getLstKpiModel() {
        return lstKpiModel;
    }

    public void setLstKpiModel(List<KpiModel> lstKpiModel) {
        this.lstKpiModel = lstKpiModel;
    }
}
