package Response;

import com.example.kpipkg.Models.UserSessionData;
import com.example.kpipkg.Models.YearMonth;

import java.util.List;

public class ResponseLogin {

    ResponseCode responsecode;
    UserSessionData userSessionData;
    List<YearMonth> lstmodelyearmonth;

    public ResponseLogin(ResponseCode responsecode, UserSessionData userSessionData,
                         List<YearMonth> lstmodelyearmonth) {
        super();
        this.responsecode = responsecode;
        this.userSessionData = userSessionData;
        this.lstmodelyearmonth = lstmodelyearmonth;
    }

    public ResponseLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ResponseCode getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(ResponseCode responsecode) {
        this.responsecode = responsecode;
    }

    public UserSessionData getUserSessionData() {
        return userSessionData;
    }

    public void setUserSessionData(UserSessionData userSessionData) {
        this.userSessionData = userSessionData;
    }

    public List<YearMonth> getLstmodelyearmonth() {
        return lstmodelyearmonth;
    }

    public void setLstmodelyearmonth(List<YearMonth> lstmodelyearmonth) {
        this.lstmodelyearmonth = lstmodelyearmonth;
    }


}
