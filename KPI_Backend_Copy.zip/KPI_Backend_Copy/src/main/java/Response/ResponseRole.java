package Response;

import com.example.kpipkg.Models.Role;

import java.util.List;

public class ResponseRole {

    ResponseCode responsecode;
    List<Role> lstRole;

    public ResponseCode getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(ResponseCode responsecode) {
        this.responsecode = responsecode;
    }

    public List<Role> getLstRole() {
        return lstRole;
    }

    public void setLstRole(List<Role> lstRole) {
        this.lstRole = lstRole;
    }

    public ResponseRole() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ResponseRole(ResponseCode responsecode, List<Role> lstRole) {
        super();
        this.responsecode = responsecode;
        this.lstRole = lstRole;
    }

    @Override
    public String toString() {
        return "ResponseRole [responsecode=" + responsecode + ", lstRole=" + lstRole + "]";
    }


}
