package Response;

import com.example.kpipkg.Models.KpiFields;

import java.util.List;

public class ResponseFields {

    ResponseCode responsecode;
    List<KpiFields> lstKpiFields;

    @Override
    public String toString() {
        return "ResponseFields [responsecode=" + responsecode + ", lstKpiFields=" + lstKpiFields + "]";
    }

    public ResponseFields() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ResponseFields(ResponseCode responsecode, List<KpiFields> lstKpiFields) {
        super();
        this.responsecode = responsecode;
        this.lstKpiFields = lstKpiFields;
    }

    public ResponseCode getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(ResponseCode responsecode) {
        this.responsecode = responsecode;
    }

    public List<KpiFields> getLstKpiFields() {
        return lstKpiFields;
    }

    public void setLstKpiFields(List<KpiFields> lstKpiFields) {
        this.lstKpiFields = lstKpiFields;
    }


}
