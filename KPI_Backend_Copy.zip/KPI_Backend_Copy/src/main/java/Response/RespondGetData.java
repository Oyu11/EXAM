package Response;

import com.example.kpipkg.Models.KpiFields;
import com.example.kpipkg.Models.KpiModel;

import java.util.List;

public class RespondGetData {

    ResponseCode responsecode;
    List<KpiModel> lstKpiModel;
    List<KpiFields> lstKpiFields;

    public RespondGetData(ResponseCode responsecode, List<KpiModel> lstKpiModel, List<KpiFields> lstKpiFields
    ) {
        super();
        this.responsecode = responsecode;
        this.lstKpiModel = lstKpiModel;
        this.lstKpiFields = lstKpiFields;
    }

    public RespondGetData() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ResponseCode getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(ResponseCode responsecode) {
        this.responsecode = responsecode;
    }

    public List<KpiModel> getLstKpiModel() {
        return lstKpiModel;
    }

    public void setLstKpiModel(List<KpiModel> lstKpiModel) {
        this.lstKpiModel = lstKpiModel;
    }

    public List<KpiFields> getLstKpiFields() {
        return lstKpiFields;
    }

    public void setLstKpiFields(List<KpiFields> lstKpiFields) {
        this.lstKpiFields = lstKpiFields;
    }


}
