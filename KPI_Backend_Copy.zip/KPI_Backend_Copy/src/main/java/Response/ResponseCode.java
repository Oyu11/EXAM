package Response;

public class ResponseCode {

    String ResponseCode;
    String ResponseCodeDesc;

    String ActualCode;
    String ActualCodeDesc;

    public String getResponseCode() {
        return ResponseCode;
    }

    public void setResponseCode(String responseCode) {
        ResponseCode = responseCode;
    }

    public String getResponseCodeDesc() {
        return ResponseCodeDesc;
    }

    public void setResponseCodeDesc(String responseCodeDesc) {
        ResponseCodeDesc = responseCodeDesc;
    }

    public String getActualCode() {
        return ActualCode;
    }

    public void setActualCode(String actualCode) {
        ActualCode = actualCode;
    }

    public String getActualCodeDesc() {
        return ActualCodeDesc;
    }

    public void setActualCodeDesc(String actualCodeDesc) {
        ActualCodeDesc = actualCodeDesc;
    }

    public ResponseCode(String responseCode, String responseCodeDesc, String actualCode, String actualCodeDesc) {
        super();
        ResponseCode = responseCode;
        ResponseCodeDesc = responseCodeDesc;
        ActualCode = actualCode;
        ActualCodeDesc = actualCodeDesc;
    }

    public ResponseCode() {
        super();
        // TODO Auto-generated constructor stub
    }


}
