package com.example.kpipkg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KpiApplicationTests {

	@Test
	void contextLoads() {
	}

}
