class UserSessionData {
  String _sessionid;
  String _rolename;
  String _emplid;
  String _emplname;
  double _scoremin;
  double _scoremax;
  bool _ischecked;
  String _createdt;
  String _modifiedt;
  String _empljobtitle;
  String _emplcompany;
  String _empldepartment;

  String get empljobtitle => _empljobtitle;

  set empljobtitle(String value) {
    _empljobtitle = value;
  }

  @override
  String toString() {
    return 'UserSessionData{_sessionid: $_sessionid, _rolename: $_rolename, _emplid: $_emplid, _emplname: $_emplname, _scoremin: $_scoremin, _scoremax: $_scoremax, _createdt: $_createdt, _modifiedt: $_modifiedt}';
  }

  String get sessionid => _sessionid;

  set sessionid(String value) {
    _sessionid = value;
  }

  UserSessionData(
      this._sessionid,
      this._rolename,
      this._emplid,
      this._emplname,
      this._scoremin,
      this._scoremax,
      this._ischecked,
      this._createdt,
      this._modifiedt,
      this._empljobtitle,
      this._empldepartment,
      this._emplcompany);

  factory UserSessionData.fromJson(Map<String, dynamic> json) {
    return UserSessionData(
        json['sessionid'] == null ? "" : json['sessionid'] as String,
        json['roleid'] == null ? "" : json['roleid'] as String,
        json['emplid'] == null ? "" : json['emplid'] as String,
        json['emplname'] == null ? "" : json['emplname'] as String,
        json['scoremin'] == null ? 0 : json['scoremin'] as double,
        json['scoremax'] == null ? 0 : json['scoremax'] as double,
        json['ischecked'] == null ? false : json['ischecked'] as bool,
        json['createdt'] == null ? "" : json['createdt'] as String,
        json['modifiedt'] == null ? "" : json['modifiedt'] as String,
        json['empljobtitle'] == null ? "" : json['empljobtitle'] as String,
        json['empldepartment'] == null ? "" : json['empldepartment'] as String,
        json['emplcompany'] == null ? "" : json['emplcompany'] as String);
  }

  String get rolename => _rolename;

  set rolename(String value) {
    _rolename = value;
  }

  String get emplid => _emplid;

  set emplid(String value) {
    _emplid = value;
  }

  String get emplname => _emplname;

  set emplname(String value) {
    _emplname = value;
  }

  double get scoremin => _scoremin;

  set scoremin(double value) {
    _scoremin = value;
  }

  double get scoremax => _scoremax;

  set scoremax(double value) {
    _scoremax = value;
  }

  bool get ischecked => _ischecked;
  set ischecked(bool value) {
    _ischecked = value;
  }

  String get emplcompany => _emplcompany;

  set emplcompany(String value) {
    _emplcompany = value;
  }

  String get empldepartment => _empldepartment;

  set empldepartment(String value) {
    _empldepartment = value;
  }
}
