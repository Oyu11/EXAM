class KpiFieldsModel {
  int _id;
  String _col1;

  KpiFieldsModel(
      this._id,
      this._col1,
      this._col2,
      this._col3,
      this._col4,
      this._col5,
      this._col6,
      this._col7,
      this._col8,
      this._col9,
      this._col10,
      this._col11,
      this._col12,
      this._col13,
      this._col14,
      this._col15,
      this._col16,
      this._col17,
      this._col18,
      this._col19,
      this._col20,
      this._effectiveyear,
      this._effectivemonth,
      this._createdt,
      this._createuser,
      this._modifieddt,
      this._modifieduser,
      this._positionname,
      this._scorenumber1,
      this._scorenumber2,
      this._scorenumber3,
      this._scorenumber4,
      this._scorenumber5,
      this._scorenumber6,
      this._scorenumber7,
      this._scorenumber8,
      this._scorenumber9,
      this._scorenumber10);

  Map toJson() => {
        'id': _id,
        'col1': _col1,
        'col2': _col2,
        'col3': _col3,
        'col4': _col4,
        'col5': _col5,
        'col6': _col6,
        'col7': _col7,
        'col8': _col8,
        'col9': _col9,
        'col10': _col10,
        'col11': _col11,
        'col12': _col12,
        'col13': _col13,
        'col14': _col14,
        'col15': _col15,
        'col16': _col16,
        'col17': _col17,
        'col18': _col18,
        'col19': _col19,
        'col20': _col20,
        'effectiveyear': _effectiveyear,
        'effectivemonth': _effectivemonth,
        'createdt': _createdt,
        'createuser': _createuser,
        'modifieddt': _modifieddt,
        'modifieduser': _modifieduser,
        'positionname': _positionname,
        'scorenumber1': _scorenumber1,
        'scorenumber2': _scorenumber2,
        'scorenumber3': _scorenumber3,
        'scorenumber4': _scorenumber4,
        'scorenumber5': _scorenumber5,
        'scorenumber6': _scorenumber6,
        'scorenumber7': _scorenumber7,
        'scorenumber8': _scorenumber8,
        'scorenumber9': _scorenumber9,
        'scorenumber10': _scorenumber10
      };

  factory KpiFieldsModel.fromJson(Map<String, dynamic> json) {
    return KpiFieldsModel(
        json['id'] == null ? 0 : json['id'] as int,
        json['col1'] == null ? "" : json['col1'] as String,
        json['col2'] == null ? "" : json['col2'] as String,
        json['col3'] == null ? "" : json['col3'] as String,
        json['col4'] == null ? "" : json['col4'] as String,
        json['col5'] == null ? "" : json['col5'] as String,
        json['col6'] == null ? "" : json['col6'] as String,
        json['col7'] == null ? "" : json['col7'] as String,
        json['col8'] == null ? "" : json['col8'] as String,
        json['col9'] == null ? "" : json['col9'] as String,
        json['col10'] == null ? "" : json['col10'] as String,
        json['col11'] == null ? "" : json['col11'] as String,
        json['col12'] == null ? "" : json['col12'] as String,
        json['col13'] == null ? "" : json['col13'] as String,
        json['col14'] == null ? "" : json['col14'] as String,
        json['col15'] == null ? "" : json['col15'] as String,
        json['col16'] == null ? "" : json['col16'] as String,
        json['col17'] == null ? "" : json['col17'] as String,
        json['col18'] == null ? "" : json['col18'] as String,
        json['col19'] == null ? "" : json['col19'] as String,
        json['col20'] == null ? "" : json['col20'] as String,
        json['effectiveyear'] == null ? 0 : json['effectiveyear'] as int,
        json['effectivemonth'] == null ? 0 : json['effectivemonth'] as int,
        json['createdt'] == null ? "" : json['createddt'] as String,
        json['createuser'] == null ? "" : json['createuser'] as String,
        json['modifieddt'] == null ? "" : json['modifieddt'] as String,
        json['modifieduser'] == null ? "" : json['modifieduser'] as String,
        json['positionname'] == null ? "" : json['positionname'] as String,
        json['scorenumber1'] == null ? 0 : json['scorenumber1'] as int,
        json['scorenumber2'] == null ? 0 : json['scorenumber2'] as int,
        json['scorenumber3'] == null ? 0 : json['scorenumber3'] as int,
        json['scorenumber4'] == null ? 0 : json['scorenumber4'] as int,
        json['scorenumber5'] == null ? 0 : json['scorenumber5'] as int,
        json['scorenumber6'] == null ? 0 : json['scorenumber6'] as int,
        json['scorenumber7'] == null ? 0 : json['scorenumber7'] as int,
        json['scorenumber8'] == null ? 0 : json['scorenumber8'] as int,
        json['scorenumber9'] == null ? 0 : json['scorenumber9'] as int,
        json['scorenumber10'] == null ? 0 : json['scorenumber10'] as int);
  }

  int get id => _id;

  set id(int value) {
    _id = value;
  }

  String _col2;
  String _col3;
  String _col4;
  String _col5;
  String _col6;
  String _col7;
  String _col8;
  String _col9;
  String _col10;
  String _col11;
  int _scorenumber1;
  int _scorenumber2;
  int _scorenumber3;
  int _scorenumber4;
  int _scorenumber5;
  int _scorenumber6;
  int _scorenumber7;
  int _scorenumber8;
  int _scorenumber9;
  int _scorenumber10;

  @override
  String toString() {
    return 'KpiFieldsModel{_id: $_id, _col1: $_col1, _col2: $_col2, _col3: $_col3, _col4: $_col4, _col5: $_col5, _col6: $_col6, _col7: $_col7, _col8: $_col8, _col9: $_col9, _col10: $_col10, _col11: $_col11, _col12: $_col12, _col13: $_col13, _col14: $_col14, _col15: $_col15, _col16: $_col16, _col17: $_col17, _col18: $_col18, _col19: $_col19, _col20: $_col20, _effectiveyear: $_effectiveyear, _effectivemonth: $_effectivemonth, _createdt: $_createdt, _createuser: $_createuser, _modifieddt: $_modifieddt, _modifieduser: $_modifieduser, _positionname: $_positionname, _scorenumber1:$_scorenumber1, _scorenumber2:$_scorenumber2, _scorenumber3:$_scorenumber3, _scorenumber4:$_scorenumber4, _scorenumber5:$_scorenumber5, _scorenumber6:$_scorenumber6, _scorenumber7:$_scorenumber7, _scorenumber8:$_scorenumber8, _scorenumber9:$_scorenumber9, _scorenumber10:$_scorenumber10}';
  }

  String _col12;
  String _col13;
  String _col14;
  String _col15;
  String _col16;
  String _col17;
  String _col18;
  String _col19;
  String _col20;
  int _effectiveyear;
  int _effectivemonth;
  String _createdt;
  String _createuser;
  String _modifieddt;
  String _modifieduser;
  String _positionname;

  String get col1 => _col1;

  String get positionname => _positionname;

  set positionname(String value) {
    _positionname = value;
  }

  String get modifieduser => _modifieduser;

  set modifieduser(String value) {
    _modifieduser = value;
  }

  String get modifieddt => _modifieddt;

  set modifieddt(String value) {
    _modifieddt = value;
  }

  String get createuser => _createuser;

  set createuser(String value) {
    _createuser = value;
  }

  String get createdt => _createdt;

  set createdt(String value) {
    _createdt = value;
  }

  int get effectivemonth => _effectivemonth;

  set effectivemonth(int value) {
    _effectivemonth = value;
  }

  int get effectiveyear => _effectiveyear;

  set effectiveyear(int value) {
    _effectiveyear = value;
  }

  String get col20 => _col20;

  set col20(String value) {
    _col20 = value;
  }

  String get col19 => _col19;

  set col19(String value) {
    _col19 = value;
  }

  String get col18 => _col18;

  set col18(String value) {
    _col18 = value;
  }

  String get col17 => _col17;

  set col17(String value) {
    _col17 = value;
  }

  String get col16 => _col16;

  set col16(String value) {
    _col16 = value;
  }

  String get col15 => _col15;

  set col15(String value) {
    _col15 = value;
  }

  String get col14 => _col14;

  set col14(String value) {
    _col14 = value;
  }

  String get col13 => _col13;

  set col13(String value) {
    _col13 = value;
  }

  String get col12 => _col12;

  set col12(String value) {
    _col12 = value;
  }

  String get col11 => _col11;

  set col11(String value) {
    _col11 = value;
  }

  String get col10 => _col10;

  set col10(String value) {
    _col10 = value;
  }

  String get col9 => _col9;

  set col9(String value) {
    _col9 = value;
  }

  String get col8 => _col8;

  set col8(String value) {
    _col8 = value;
  }

  String get col7 => _col7;

  set col7(String value) {
    _col7 = value;
  }

  String get col6 => _col6;

  set col6(String value) {
    _col6 = value;
  }

  String get col5 => _col5;

  set col5(String value) {
    _col5 = value;
  }

  String get col4 => _col4;

  set col4(String value) {
    _col4 = value;
  }

  String get col3 => _col3;

  set col3(String value) {
    _col3 = value;
  }

  String get col2 => _col2;

  set col2(String value) {
    _col2 = value;
  }

  set col1(String value) {
    _col1 = value;
  }

  int get scorenumber1 => _scorenumber1;
  set scorenumber1(int value) {
    _scorenumber1 = value;
  }

  int get scorenumber2 => _scorenumber2;
  set scorenumber2(int value) {
    _scorenumber2 = value;
  }

  int get scorenumber3 => _scorenumber3;
  set scorenumber3(int value) {
    _scorenumber3 = value;
  }

  int get scorenumber4 => _scorenumber4;
  set scorenumber4(int value) {
    _scorenumber4 = value;
  }

  int get scorenumber5 => _scorenumber5;
  set scorenumber5(int value) {
    _scorenumber5 = value;
  }

  int get scorenumber6 => _scorenumber6;
  set scorenumber6(int value) {
    _scorenumber6 = value;
  }

  int get scorenumber7 => _scorenumber7;
  set scorenumber7(int value) {
    _scorenumber7 = value;
  }

  int get scorenumber8 => _scorenumber8;
  set scorenumber8(int value) {
    _scorenumber8 = value;
  }

  int get scorenumber9 => _scorenumber9;
  set scorenumber9(int value) {
    _scorenumber8 = value;
  }

  int get scorenumber10 => _scorenumber10;
  set scorenumber10(int value) {
    _scorenumber10 = value;
  }
}
