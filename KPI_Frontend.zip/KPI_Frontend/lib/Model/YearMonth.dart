class YearMonth {
  int _year;
  int _month;
  int _count;
  String _position;

  YearMonth(this._year, this._month, this._count, this._position);

  @override
  String toString() {
    return 'YearMonth{_year: $_year, _month: $_month, _count: $_count, _position: $_position}';
  }

  int get year => _year;

  set year(int value) {
    _year = value;
  }

  factory YearMonth.fromJson(Map<String, dynamic> json) {
    return YearMonth(
        json['year'] == null ? 0 : json['year'] as int,
        json['month'] == null ? 0 : json['month'] as int,
        json['count'] == null ? 0 : json['count'] as int,
        json['position'] == null ? "" : json['position'] as String);
  }

  int get month => _month;

  set month(int value) {
    _month = value;
  }

  int get count => _count;

  set count(int value) {
    _count = value;
  }

  String get position => _position;

  set position(String value) {
    _position = value;
  }
}
