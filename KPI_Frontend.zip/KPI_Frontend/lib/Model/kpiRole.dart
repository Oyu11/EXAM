class KpiRole {
  String _roleid;
  double _scoremax;
  double _scoremin;
  String _roleName;
  bool _isCheck;

  KpiRole(this._roleid, this._scoremax, this._scoremin, this._isCheck,
      this._roleName);

  double get scoremin => _scoremin;

  set scoremin(double value) {
    _scoremin = value;
  }

  double get scoremax => _scoremax;

  set scoremax(double value) {
    _scoremax = value;
  }

  String get roleid => _roleid;

  set roleid(String value) {
    _roleid = value;
  }

  bool get isCheck => _isCheck;
  set isCheck(bool value) {
    _isCheck = value;
  }

  String get roleName => _roleName;
  set roleName(String value) {
    _roleName = value;
  }

  @override
  String toString() {
    return 'KpiRole{_roleid: $_roleid, _scoremax: $_scoremax, _scoremin: $_scoremin, _roleName: $_roleName, _isCheck: $_isCheck}';
  }

  Map toJson() => {
        'roleid': _roleid,
        'scoremax': _scoremax,
        'scoremin': _scoremin,
        'checked': _isCheck,
        'rolename': _roleName,
      };

  factory KpiRole.fromJson(Map<String, dynamic> json) {
    return KpiRole(
      json['roleid'] == null ? "" : json['roleid'] as String,
      json['scoremax'] == null ? 0 : json['scoremax'] as double,
      json['scoremin'] == null ? 0 : json['scoremin'] as double,
      json['checked'] == null ? false : json['checked'] as bool,
      json['rolename'] == null ? "" : json['rolename'] as String,
    );
  }
}
