class KpiModelTemp {
  int _id;
  String _emplid;
  String _emplname;
  String _emplbrncode;
  String _emplposition;
  String _emplstatus;
  String _directorid;
  String _hubcode;
  String _hubdirectorid;

  double _scoreempl;
  double _scoredir;
  double _scorehubdir;
  double _scoretotal;
  int _effectiveyear;
  int _effectivemonth;
  double _col1;
  double _col2;
  double _col3;
  double _col4;
  double _col5;
  double _col6;
  double _col7;
  double _col8;
  double _col9;
  double _col10;
  double _col11;
  double _col12;
  double _col13;
  double _col14;
  double _col15;
  double _col16;
  double _col17;
  double _col18;
  double _col19;
  double _col20;
  double _col1_amount;
  double _col2_amount;
  double _col3_amount;
  double _col4_amount;
  double _col5_amount;
  double _col6_amount;
  double _col7_amount;
  double _col8_amount;
  double _col9_amount;
  double _col10_amount;
  double _col11_amount;
  double _col12_amount;
  double _col13_amount;
  double _col14_amount;
  double _col15_amount;
  double _col16_amount;
  double _col17_amount;
  double _col18_amount;
  double _col19_amount;
  double _col20_amount;
  double scorenumber1_amount;
  double scorenumber2_amount;
  double scorenumber3_amount;
  double scorenumber4_amount;
  double scorenumber5_amount;
  double scorenumber6_amount;
  double scorenumber7_amount;
  double scorenumber8_amount;
  double scorenumber9_amount;
  double scorenumber10_amount;
  double scorenumber11_amount;
  double scorenumber12_amount;
  double scorenumber13_amount;
  double scorenumber14_amount;
  double scorenumber15_amount;
  double scorenumber16_amount;
  double scorenumber17_amount;
  double scorenumber18_amount;
  double scorenumber19_amount;
  double scorenumber20_amount;
  String _createdt;
  String _createuser;
  String _modifieddt;
  String _modifieduser;

  String _isConfirmed;

  String _isConfirmedhub;
  String _iskpi;

  String _commentbyemployee;
  String _commentbydirector;
  String _commentbydirectorhub;
  String _commentbyallbrnmanager;

  KpiModelTemp(
      this._id,
      this._emplid,
      this._emplname,
      this._emplbrncode,
      this._emplposition,
      this._emplstatus,
      this._directorid,
      this._hubcode,
      this._hubdirectorid,
      this._scoreempl,
      this._scoredir,
      this._scorehubdir,
      this._scoretotal,
      this._effectiveyear,
      this._effectivemonth,
      this._col1,
      this._col2,
      this._col3,
      this._col4,
      this._col5,
      this._col6,
      this._col7,
      this._col8,
      this._col9,
      this._col10,
      this._col11,
      this._col12,
      this._col13,
      this._col14,
      this._col15,
      this._col16,
      this._col17,
      this._col18,
      this._col19,
      this._col20,
      this._col1_amount,
      this._col2_amount,
      this._col3_amount,
      this._col4_amount,
      this._col5_amount,
      this._col6_amount,
      this._col7_amount,
      this._col8_amount,
      this._col9_amount,
      this._col10_amount,
      this._col11_amount,
      this._col12_amount,
      this._col13_amount,
      this._col14_amount,
      this._col15_amount,
      this._col16_amount,
      this._col17_amount,
      this._col18_amount,
      this._col19_amount,
      this._col20_amount,
      this.scorenumber1_amount,
      this.scorenumber2_amount,
      this.scorenumber3_amount,
      this.scorenumber4_amount,
      this.scorenumber5_amount,
      this.scorenumber6_amount,
      this.scorenumber7_amount,
      this.scorenumber8_amount,
      this.scorenumber9_amount,
      this.scorenumber10_amount,
      this.scorenumber11_amount,
      this.scorenumber12_amount,
      this.scorenumber13_amount,
      this.scorenumber14_amount,
      this.scorenumber15_amount,
      this.scorenumber16_amount,
      this.scorenumber17_amount,
      this.scorenumber18_amount,
      this.scorenumber19_amount,
      this.scorenumber20_amount,
      this._createdt,
      this._createuser,
      this._modifieddt,
      this._modifieduser,
      this._isConfirmed,
      this._isConfirmedhub,
      this._iskpi,
      this._commentbyemployee,
      this._commentbydirector,
      this._commentbydirectorhub,
      this._commentbyallbrnmanager);

  @override
  String toString() {
    return 'KpiModelTemp{_id: $_id, _emplid: $_emplid, _emplname: $_emplname, _emplbrncode: $_emplbrncode, _emplposition: $_emplposition, _emplstatus: $_emplstatus, _directorid: $_directorid, _hubcode: $_hubcode, _hubdirectorid: $_hubdirectorid, _scoreempl: $_scoreempl, _scoredir: $_scoredir, _scorehubdir: $_scorehubdir, _scoretotal: $_scoretotal, _effectiveyear: $_effectiveyear, _effectivemonth: $_effectivemonth, _col1: $_col1, _col2: $_col2, _col3: $_col3, _col4: $_col4, _col5: $_col5, _col6: $_col6, _col7: $_col7, _col8: $_col8, _col9: $_col9, _col10: $_col10, _col11: $_col11, _col12: $_col12, _col13: $_col13, _col14: $_col14, _col15: $_col15, _col16: $_col16, _col17: $_col17, _col18: $_col18, _col19: $_col19, _col20: $_col20, _createdt: $_createdt, _createuser: $_createuser, _modifieddt: $_modifieddt, _modifieduser: $_modifieduser, _isConfirmed: $_isConfirmed, _isConfirmedhub: $_isConfirmedhub, _iskpi: $_iskpi, _commentbyemployee: $_commentbyemployee, _commentbydirector: $_commentbydirector, _commentbydirectorhub: $_commentbydirectorhub, _commentbyallbrnmanager: $_commentbyallbrnmanager}';
  }

  String get commentbyallbrnmanager => _commentbyallbrnmanager;

  set commentbyallbrnmanager(String value) {
    _commentbyallbrnmanager = value;
  }

  String get commentbydirectorhub => _commentbydirectorhub;

  set commentbydirectorhub(String value) {
    _commentbydirectorhub = value;
  }

  String get commentbydirector => _commentbydirector;

  set commentbydirector(String value) {
    _commentbydirector = value;
  }

  String get commentbyemployee => _commentbyemployee;

  set commentbyemployee(String value) {
    _commentbyemployee = value;
  }

  String get iskpi => _iskpi;

  set iskpi(String value) {
    _iskpi = value;
  }

  String get isConfirmedhub => _isConfirmedhub;

  set isConfirmedhub(String value) {
    _isConfirmedhub = value;
  }

  String get isConfirmed => _isConfirmed;

  set isConfirmed(String value) {
    _isConfirmed = value;
  }

  String get modifieduser => _modifieduser;

  set modifieduser(String value) {
    _modifieduser = value;
  }

  String get modifieddt => _modifieddt;

  set modifieddt(String value) {
    _modifieddt = value;
  }

  String get createuser => _createuser;

  set createuser(String value) {
    _createuser = value;
  }

  String get createdt => _createdt;

  set createdt(String value) {
    _createdt = value;
  }

  double get col20 => _col20;

  set col20(double value) {
    _col20 = value;
  }

  double get col19 => _col19;

  set col19(double value) {
    _col19 = value;
  }

  double get col18 => _col18;

  set col18(double value) {
    _col18 = value;
  }

  double get col17 => _col17;

  set col17(double value) {
    _col17 = value;
  }

  double get col16 => _col16;

  set col16(double value) {
    _col16 = value;
  }

  double get col15 => _col15;

  set col15(double value) {
    _col15 = value;
  }

  double get col14 => _col14;

  set col14(double value) {
    _col14 = value;
  }

  double get col13 => _col13;

  set col13(double value) {
    _col13 = value;
  }

  double get col12 => _col12;

  set col12(double value) {
    _col12 = value;
  }

  double get col11 => _col11;

  set col11(double value) {
    _col11 = value;
  }

  double get col10 => _col10;

  set col10(double value) {
    _col10 = value;
  }

  double get col9 => _col9;

  set col9(double value) {
    _col9 = value;
  }

  double get col8 => _col8;

  set col8(double value) {
    _col8 = value;
  }

  double get col7 => _col7;

  set col7(double value) {
    _col7 = value;
  }

  double get col6 => _col6;

  set col6(double value) {
    _col6 = value;
  }

  double get col5 => _col5;

  set col5(double value) {
    _col5 = value;
  }

  double get col4 => _col4;

  set col4(double value) {
    _col4 = value;
  }

  double get col3 => _col3;

  set col3(double value) {
    _col3 = value;
  }

  double get col2 => _col2;

  set col2(double value) {
    _col2 = value;
  }

  double get col1 => _col1;

  set col1(double value) {
    _col1 = value;
  }

  double get col20_amount => _col20_amount;

  set col20_amount(double value) {
    _col20_amount = value;
  }

  double get col19_amount => _col19;

  set col19_amount(double value) {
    _col19 = value;
  }

  double get col18_amount => _col18_amount;

  set col18_amount(double value) {
    _col18_amount = value;
  }

  double get col17_amount => _col17_amount;

  set col17_amount(double value) {
    _col17_amount = value;
  }

  double get col16_amount => _col16_amount;

  set col16_amount(double value) {
    _col16_amount = value;
  }

  double get col15_amount => _col15_amount;

  set col15_amount(double value) {
    _col15 = value;
  }

  double get col14_amount => _col14_amount;

  set col14_amount(double value) {
    _col14_amount = value;
  }

  double get col13_amount => _col13_amount;

  set col13_amount(double value) {
    _col13_amount = value;
  }

  double get col12_amount => _col12_amount;

  set col12_amount(double value) {
    _col12_amount = value;
  }

  double get col11_amount => _col11_amount;

  set col11_amount(double value) {
    _col11_amount = value;
  }

  double get col10_amount => _col10_amount;

  set col10_amount(double value) {
    _col10_amount = value;
  }

  double get col9_amount => _col9_amount;

  set col9_amount(double value) {
    _col9_amount = value;
  }

  double get col8_amount => _col8_amount;

  set col8_amount(double value) {
    _col8_amount = value;
  }

  double get col7_amount => _col7_amount;

  set col7_amount(double value) {
    _col7_amount = value;
  }

  double get col6_amount => _col6_amount;

  set col6_amount(double value) {
    _col6_amount = value;
  }

  double get col5_amount => _col5_amount;

  set col5_amount(double value) {
    _col5_amount = value;
  }

  double get col4_amount => _col4_amount;

  set col4_amount(double value) {
    _col4_amount = value;
  }

  double get col3_amount => _col3_amount;

  set col3_amount(double value) {
    _col3_amount = value;
  }

  double get col2_amount => _col2_amount;

  set col2_amount(double value) {
    _col2_amount = value;
  }

  double get col1_amount => _col1_amount;

  set col1_amount(double value) {
    _col1_amount = value;
  }

  int get effectivemonth => _effectivemonth;

  set effectivemonth(int value) {
    _effectivemonth = value;
  }

  int get effectiveyear => _effectiveyear;

  set effectiveyear(int value) {
    _effectiveyear = value;
  }

  double get scoretotal => _scoretotal;

  set scoretotal(double value) {
    _scoretotal = value;
  }

  double get scorehubdir => _scorehubdir;

  set scorehubdir(double value) {
    _scorehubdir = value;
  }

  double get scoredir => _scoredir;

  set scoredir(double value) {
    _scoredir = value;
  }

  double get scoreempl => _scoreempl;

  set scoreempl(double value) {
    _scoreempl = value;
  }

  String get hubdirectorid => _hubdirectorid;

  set hubdirectorid(String value) {
    _hubdirectorid = value;
  }

  String get hubcode => _hubcode;

  set hubcode(String value) {
    _hubcode = value;
  }

  String get directorid => _directorid;

  set directorid(String value) {
    _directorid = value;
  }

  String get emplstatus => _emplstatus;

  set emplstatus(String value) {
    _emplstatus = value;
  }

  String get emplposition => _emplposition;

  set emplposition(String value) {
    _emplposition = value;
  }

  String get emplbrncode => _emplbrncode;

  set emplbrncode(String value) {
    _emplbrncode = value;
  }

  String get emplname => _emplname;

  set emplname(String value) {
    _emplname = value;
  }

  String get emplid => _emplid;

  set emplid(String value) {
    _emplid = value;
  }

  int get id => _id;

  set id(int value) {
    _id = value;
  }

  double get Scorenumber1Amount => scorenumber1_amount;
  set Scorenumber1Amount(double value) {
    scorenumber1_amount = value;
  }

  double get Scorenumber2Amount => scorenumber2_amount;
  set Scorenumber2Amount(double value) {
    scorenumber2_amount = value;
  }

  double get Scorenumber3Amount => scorenumber3_amount;
  set Scorenumber3Amount(double value) {
    scorenumber3_amount = value;
  }

  double get Scorenumber4Amount => scorenumber4_amount;
  set Scorenumber4Amount(double value) {
    scorenumber4_amount = value;
  }

  double get Scorenumber5Amount => scorenumber5_amount;
  set Scorenumber5Amount(double value) {
    scorenumber5_amount = value;
  }

  double get Scorenumber6Amount => scorenumber6_amount;
  set Scorenumber6Amount(double value) {
    scorenumber6_amount = value;
  }

  double get Scorenumber7Amount => scorenumber7_amount;
  set Scorenumber7Amount(double value) {
    scorenumber7_amount = value;
  }

  double get Scorenumber8Amount => scorenumber8_amount;
  set Scorenumber8Amount(double value) {
    scorenumber8_amount = value;
  }

  double get Scorenumber9Amount => scorenumber9_amount;
  set Scorenumber9Amount(double value) {
    scorenumber9_amount = value;
  }

  double get Scorenumber10Amount => Scorenumber10Amount;
  set Scorenumber10Amount(double value) {
    scorenumber10_amount = value;
  }

  double get Scorenumber11Amount => scorenumber11_amount;
  set Scorenumber11Amount(double value) {
    scorenumber11_amount = value;
  }

  double get Scorenumber12Amount => scorenumber12_amount;
  set Scorenumber12Amount(double value) {
    scorenumber12_amount = value;
  }

  double get Scorenumber13Amount => scorenumber13_amount;
  set Scorenumber13Amount(double value) {
    scorenumber13_amount = value;
  }

  double get Scorenumber14Amount => scorenumber14_amount;
  set Scorenumber14Amount(double value) {
    scorenumber14_amount = value;
  }

  double get Scorenumber15Amount => scorenumber15_amount;
  set Scorenumber15Amount(double value) {
    scorenumber15_amount = value;
  }

  double get Scorenumber16Amount => scorenumber16_amount;
  set Scorenumber16Amount(double value) {
    scorenumber16_amount = value;
  }

  double get Scorenumber17Amount => scorenumber17_amount;
  set Scorenumber17Amount(double value) {
    scorenumber17_amount = value;
  }

  double get Scorenumber18Amount => scorenumber18_amount;
  set Scorenumber18Amount(double value) {
    scorenumber18_amount = value;
  }

  double get Scorenumber19Amount => scorenumber19_amount;
  set Scorenumber19Amount(double value) {
    scorenumber19_amount = value;
  }

  double get Scorenumber20Amount => scorenumber20_amount;
  set Scorenumber20Amount(double value) {
    scorenumber20_amount = value;
  }
}
