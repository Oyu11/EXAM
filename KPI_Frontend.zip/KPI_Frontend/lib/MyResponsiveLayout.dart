import 'package:flutter/cupertino.dart';

class MyResponsiveLayout extends StatelessWidget {

  final Widget mobileScaffold;
  final Widget tabletScaffold;
  final Widget desktopScaffold;

  const MyResponsiveLayout({Key? key,
    required this.mobileScaffold,
    required this.tabletScaffold,
    required this.desktopScaffold,

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {

    int ii = 0;

    return  LayoutBuilder(builder:   (context, constraint){

      if(constraint.maxWidth <=600)
        return mobileScaffold;
      else if(constraint.maxWidth <=1100)
        return tabletScaffold;
      else
        return desktopScaffold;

    } );
  }
}
