import 'dart:convert';
import 'dart:js_interop';
import 'package:http/http.dart' as Dio;
import 'package:kpi_empl/Model/kpiFieldsModel.dart';
import 'package:kpi_empl/Model/kpiModel.dart';
import 'package:kpi_empl/Response/ResponseCode.dart';
import 'package:kpi_empl/Model/UserSession.dart';
import 'package:kpi_empl/Response/ResponseGetKpi.dart';

import '../Const/Constantino.dart';
import '../Model/YearMonth.dart';
import '../Model/kpiRole.dart';
import '../Response/ResponseFields.dart';
import '../Response/ResponseLogin.dart';
import '../Response/ResponseRole.dart';

class KpiController {
  String basicAuth =
      'Basic ' + base64.encode(utf8.encode('userKPI:Pss0rd2023423'));

  Future<ResponseLogin> Login(String emplID, String pwd) async {
    ResponseCode responseCode = ResponseCode("", "", "", "");
    UserSessionData userSessionData =
        UserSessionData("", "", "", "", 0, 0, false, "", "", "", "", "");
    List<YearMonth> lstModelYearMonth = [];

    ResponseLogin responseLogin =
        ResponseLogin(responseCode, userSessionData, lstModelYearMonth);

    try {
      String strURL = 'http://' +
          IPAddress_ +
          ':' +
          Port_ +
          RootMapping +
          'Login?empldid=' +
          emplID +
          "&pwd=" +
          pwd;

      final response = await Dio.post(
        Uri.parse(strURL),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "authorization": basicAuth,
        },
      );

      if (response.statusCode == 200) {
        try {
          Map<String, dynamic> result =
              jsonDecode(utf8.decode(response.bodyBytes));

          responseLogin = ResponseLogin.fromJson(result);
        } catch (e) {
          print("Parse Error:");
        }
      } else {}
    } catch (Exc) {
      print("Error handled here... ");
    }

    return responseLogin;
  }

  Future<ResponseCode> SaveComment(UserSessionData userSessionData,
      String fieldId, String commentStr) async {
    ResponseCode rslt = ResponseCode(ResponseValue.Error.value, "", "", "");

    try {
      String strURL = 'http://' +
          IPAddress_ +
          ':' +
          Port_ +
          RootMapping +
          'SaveComment?sessionid=' +
          userSessionData.sessionid +
          '&fieldid=' +
          fieldId +
          '&comment=' +
          commentStr;

      final response = await Dio.get(
        Uri.parse(strURL),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "authorization": basicAuth,
          // "Access-Control-Allow-Origin":"*"
        },
        //  body:  jsonEncode(<String, String>{
        //    'username': name, 'sessionid': sessionID_
        //   })
      );

      if (response.statusCode == 200) {
        try {
          Map<String, dynamic> result =
              jsonDecode(utf8.decode(response.bodyBytes));

          rslt = ResponseCode.fromJson(result);
        } catch (e) {
          rslt = ResponseCode(ResponseValue.Error.value, e.toString(), "", "");
        }
      } else {}
    } catch (Exc) {
      print("Error handled here... ");
    }

    return rslt;
  }

  Future<ResponseCode> SaveScore(
      UserSessionData userSessionData, List<KpiRole> lstRole) async {
    ResponseCode rslt = ResponseCode(ResponseValue.Error.value, "", "", "");

    try {
      String strURL = 'http://' +
          IPAddress_ +
          ':' +
          Port_ +
          RootMapping +
          'SaveScore?sessionid=' +
          userSessionData.sessionid;

      String strBody = jsonEncode(lstRole.map((e) => e.toJson()).toList());

      final response = await Dio.post(Uri.parse(strURL),
          headers: {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "authorization": basicAuth,
            // "Access-Control-Allow-Origin":"*"
          },
          body: strBody);
      print(strBody);

      if (response.statusCode == 200) {
        try {
          Map<String, dynamic> result =
              jsonDecode(utf8.decode(response.bodyBytes));

          rslt = ResponseCode.fromJson(result);
        } catch (e) {
          rslt = ResponseCode(ResponseValue.Error.value, e.toString(), "", "");
        }
      } else {}
    } catch (Exc) {
      print("Error handled here... ");
    }

    return rslt;
  }

  Future<ResponseRole> GetScore(
      UserSessionData userSessionData, String role_name) async {
    List<KpiRole> lstRoleTemp = [];

    ResponseCode rCode = ResponseCode(ResponseValue.Success.value, "", "", "");
    ResponseRole rslt = ResponseRole(rCode, lstRoleTemp);

    try {
      String strURL = 'http://' +
          IPAddress_ +
          ':' +
          Port_ +
          RootMapping +
          'GetScore?sessionid=' +
          userSessionData.sessionid +
          '&role_name=' +
          role_name;

      final response = await Dio.get(
        Uri.parse(strURL),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "authorization": basicAuth,
          // "Access-Control-Allow-Origin":"*"
        },
      );

      if (response.statusCode == 200) {
        try {
          Map<String, dynamic> result =
              jsonDecode(utf8.decode(response.bodyBytes));

          rslt = ResponseRole.fromJson(result);
        } catch (e) {
          rCode = ResponseCode(ResponseValue.Error.value, e.toString(), "", "");

          rslt.responseCode = rCode;
        }
      } else {}
    } catch (Exc) {
      print("Error handled here... ");
    }

    return rslt;
  }

  Future<ResponseGetKpi> GetKpiDetails(UserSessionData userSessionData,
      String year, String month, String position) async {
    ResponseCode responseCode = ResponseCode("", "", "", "");

    List<KpiModel> lstKpiModel = [];
    List<KpiFieldsModel> lstKpiFieldsModel = [];
    ResponseGetKpi responseGetKpi =
        ResponseGetKpi(responseCode, lstKpiModel, lstKpiFieldsModel);

    try {
      String strURL = 'http://' +
          IPAddress_ +
          ':' +
          Port_ +
          RootMapping +
          'GetKpiData?year=' +
          year +
          '&month=' +
          month +
          '&position=' +
          position +
          '&sessionid=' +
          userSessionData.sessionid;

      final response = await Dio.post(
        Uri.parse(strURL),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "authorization": basicAuth,
        },
      );

      if (response.statusCode == 200) {
        try {
          Map<String, dynamic> result =
              jsonDecode(utf8.decode(response.bodyBytes));

          responseGetKpi = ResponseGetKpi.fromJson(result);
        } catch (e) {
          print("Parse Error:");
        }
      } else {
        print("Not good");
      }
    } catch (Exc) {
      print("Error handled here... ");
    }

    return responseGetKpi;
  }

  Future<ResponseCode> SaveKpi_Fields(
      UserSessionData userSessionData, KpiFieldsModel kpiFieldsModel) async {
    ResponseCode rCode =
        ResponseCode(ResponseValue.Error.value, "cleint side", "", "");

    String strBody = jsonEncode(kpiFieldsModel.toJson());

    String strURL = 'http://' +
        IPAddress_ +
        ':' +
        Port_ +
        RootMapping +
        'SaveKpiField?sessionid=' +
        userSessionData.sessionid;

    try {
      final response = await Dio.post(Uri.parse(strURL),
          headers: {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "authorization": basicAuth,
            // "Access-Control-Allow-Origin":"*"
          },
          body: strBody);

      if (response.statusCode == 200) {
        try {
          Map<String, dynamic> result =
              jsonDecode(utf8.decode(response.bodyBytes));

          rCode = ResponseCode.fromJson(result);
        } catch (e) {
          print("Parse Error:");
        }
      } else {}
    } catch (Exc) {
      print("Error handled here... ");
    }

    return rCode;
  }

  Future<ResponseKpiFields> GetKpi_Fields(
      UserSessionData userSessionData, String year, String month) async {
    ResponseCode responseCode = ResponseCode("", "", "", "");

    List<KpiFieldsModel> lstKpiFields = [];

    ResponseKpiFields responseKpiFields =
        ResponseKpiFields(responseCode, lstKpiFields);

    try {
      String strURL = 'http://' +
          IPAddress_ +
          ':' +
          Port_ +
          RootMapping +
          'GetKpi_Fields?sessionid=' +
          userSessionData.sessionid +
          '&year=' +
          year +
          '&month=' +
          month;

      final response = await Dio.get(
        Uri.parse(strURL),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "authorization": basicAuth,
          // "Access-Control-Allow-Origin":"*"
        },
      );

      if (response.statusCode == 200) {
        try {
          Map<String, dynamic> result =
              jsonDecode(utf8.decode(response.bodyBytes));

          responseKpiFields = ResponseKpiFields.fromJson(result);
        } catch (e) {
          print("Parse Error:");
        }
      } else {
        print("Mistake here:");
      }
    } catch (Exc) {
      print("Error handled here... ");
    }

    return responseKpiFields;
  }

  Future<ResponseCode> SaveKpiDetails(
      UserSessionData userSessionData, List<KpiModel> lstKpiModel) async {
    ResponseCode responseCode = ResponseCode("", "", "", "");

    String strURL = 'http://' +
        IPAddress_ +
        ':' +
        Port_ +
        RootMapping +
        'SaveKpiDetails?sessionid=' +
        userSessionData.sessionid;

    String strBody = jsonEncode(lstKpiModel.map((e) => e.toJson()).toList());

    final response = await Dio.post(Uri.parse(strURL),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "authorization": basicAuth,
          // "Access-Control-Allow-Origin":"*"
        },
        body: strBody);

    if (response.statusCode == 200) {
      try {
        Map<String, dynamic> result =
            jsonDecode(utf8.decode(response.bodyBytes));

        responseCode = ResponseCode.fromJson(result);
      } catch (e) {
        print("Parse Error:");
      }
    }

    return responseCode;
  }

  Future<ResponseCode> SaveKpiDetail(
      UserSessionData userSessionData, KpiModel lstKpiModel) async {
    ResponseCode responseCode = ResponseCode("", "", "", "");

    String strURL =
        'http://$IPAddress_:$Port_${RootMapping}SaveKpiDetail?sessionid=${userSessionData.sessionid}';

    String strBody = jsonEncode(lstKpiModel.toJson());

    final response = await Dio.post(Uri.parse(strURL),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "authorization": basicAuth,
          // "Access-Control-Allow-Origin":"*"
        },
        body: strBody);

    if (response.statusCode == 200) {
      try {
        Map<String, dynamic> result =
            jsonDecode(utf8.decode(response.bodyBytes));

        responseCode = ResponseCode.fromJson(result);
      } catch (e) {
        print("Parse Error:");
      }
    }

    return responseCode;
  }

  Future<ResponseCode> DeleteKpiDetails(UserSessionData userSessionData,
      KpiModel lstKpiModel, String year, String month) async {
    ResponseCode responseCode = ResponseCode("", "", "", "");
    String strURL =
        'http://$IPAddress_:$Port_${RootMapping}DeleteInformation?year=$year&month=$month&sessionid=${userSessionData.sessionid}';

    String strBody = jsonEncode(lstKpiModel.toJson());

    final response = await Dio.post(Uri.parse(strURL),
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "authorization": basicAuth,
          // "Access-Control-Allow-Origin":"*"
        },
        body: strBody);

    if (response.statusCode == 200) {
      try {
        Map<String, dynamic> result =
            jsonDecode(utf8.decode(response.bodyBytes));

        responseCode = ResponseCode.fromJson(result);
      } catch (e) {
        print("Parse Error:");
      }
    }

    return responseCode;
  }

  Future<ResponseCode> UndoKpiData(String year, String month,
      UserSessionData userSessionData, String empid, String position) async {
    ResponseCode responseCode = ResponseCode("", "", "", "");
    String strURL =
        'http://$IPAddress_:$Port_${RootMapping}GetUndo?sessionid=${userSessionData.sessionid}&year=$year&month=$month&emplid=$empid&emposition=$position';

    final response = await Dio.get(
      Uri.parse(strURL),
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "authorization": basicAuth,
        // "Access-Control-Allow-Origin":"*"
      },
    );

    if (response.statusCode == 200) {
      try {
        Map<String, dynamic> result =
            jsonDecode(utf8.decode(response.bodyBytes));

        responseCode = ResponseCode.fromJson(result);
      } catch (e) {
        print("Parse Error:");
      }
    }

    return responseCode;
  }
}
