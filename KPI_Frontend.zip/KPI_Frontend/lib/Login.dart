import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:kpi_empl/Controllr/kpiController.dart';
import 'package:kpi_empl/Model/UserSession.dart';
import 'package:kpi_empl/View/HomeRoute.dart';
import 'package:kpi_empl/View/EmployeeScreen.dart';

import 'Const/Constantino.dart';
import 'Model/kpiFieldsModel.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  bool isVisibilityOFF = false;
  final txtCntrl_Login_Name = TextEditingController();
  final txtCntrl_Login_Pwd = TextEditingController();
  List<String> tmp = [];

  final _formKey = GlobalKey<FormState>();
  var getData;
  bool isPressBtnOnce = false;

  @override
  void initState() {
    super.initState();
    txtCntrl_Login_Name.text = "1192";
    txtCntrl_Login_Pwd.text = "123Xacbank123!!!"; //1Xacbank!!123123
  }

  @override
  Widget build(BuildContext context) {
    Future<void> _onPressEnter() async {
      setState(() {
        isPressBtnOnce = true;
      });

      if (_formKey.currentState!.validate() &&
          txtCntrl_Login_Name.text.trim() != "" &&
          txtCntrl_Login_Pwd.text.trim() != "") {
        bool isTest = true;

        var returnValue = await KpiController().Login(
            txtCntrl_Login_Name.text.trim(), txtCntrl_Login_Pwd.text.trim());
        if (returnValue.lstYearMonth.length != 0) {
          getData = await KpiController().GetKpi_Fields(
              returnValue.userSessionData,
              returnValue.lstYearMonth.last.year.toString(),
              returnValue.lstYearMonth.last.month.toString()); //2024
          if (getData.responseCode.responseCode ==
              ResponseValue.Success.value) {
            List<KpiFieldsModel> lstKpiFileds = getData.lstKpiFieldsModel;
            if (lstKpiFileds.isNotEmpty) {
              lstKpiFileds.forEach((element) {
                tmp.add(element.positionname);
              });
            }
          }

          if (returnValue.responseCode.responseCode ==
              ResponseValue.Success.value) {
            var snackBar = SnackBar(
              width: 600,
              content: Center(
                  child: Text(
                returnValue.userSessionData.emplid.toUpperCase() +
                    ', Тавтай морилно уу ',
                style: TextStyle(color: Colors.white, fontSize: 14),
                textScaleFactor: ScaleSize.textScaleFactor(context),
              )),
              elevation: 10,
              behavior: SnackBarBehavior.floating,
              backgroundColor: Colors.green,
              duration: Duration(seconds: 1),
            );
            ScaffoldMessenger.of(context).showSnackBar(snackBar);

            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => HomeRoute(
                        roleList: tmp,
                        userSessionData: returnValue.userSessionData,
                        lstYearMonth: returnValue.lstYearMonth)));
          } else {
            var snackBar = const SnackBar(
              content: Center(
                  child: Text(
                'Нууц үг эсвэл нэвтрэх нэр буруу !!',
                style: TextStyle(color: Colors.red, fontSize: 23),
              )),
              elevation: 10,
              behavior: SnackBarBehavior.floating,
            );
            ScaffoldMessenger.of(context).showSnackBar(snackBar);
          }
        } else {
          var snackBar = const SnackBar(
            content: Center(
                child: Text(
              'Мэдээлэл байхгүй байна.!',
              style: TextStyle(color: Colors.orange, fontSize: 23),
            )),
            elevation: 10,
            behavior: SnackBarBehavior.floating,
          );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        }
      }

      setState(() {
        isPressBtnOnce = false;
      });
    }

    CheckUserName(String str) {
      if (isPressBtnOnce) {
        if (str.isNotEmpty) {
          return null;
        } else {
          return "Ажилтны кодоо оруулна уу";
        }
      } else
        return null;
    }

    CheckUserPwd(String str) {
      if (isPressBtnOnce) {
        if (str.isNotEmpty) {
          return null;
        } else {
          return "Компьютерт нэвтрэх нууц үгээ оруулна уу";
        }
      } else {
        return null;
      }
    }

    return Form(
      key: _formKey,
      child: Card(
        color: Colors.white,
        margin: EdgeInsets.all(20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        elevation: 10,
        child: Container(
          height: 500,
          margin: EdgeInsets.all(30),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 5,
                      height: 25,
                      color: Color(0xFF13376b),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Text(
                      "Тавтай морилно уу",
                      style: Theme.of(context).textTheme.labelSmall,
                      textScaleFactor: ScaleSize.textScaleFactor(context),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Text(
                  "KPI үнэлгээ болон явцын мэдээлэл",
                  style: Theme.of(context).textTheme.labelMedium,
                  textScaleFactor: ScaleSize.textScaleFactor(context),
                ),
                SizedBox(
                  height: 100,
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Text(
                    "Нэвтрэх нэр *",
                    style: Theme.of(context).textTheme.labelSmall,
                    textScaleFactor: ScaleSize.textScaleFactor(context),
                  ),
                ),
                TextFormField(
                  controller: txtCntrl_Login_Name,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    //   contentPadding: EdgeInsets.all(10.0),
                    isDense: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      //<-- SEE HERE
                      borderSide:
                          BorderSide(width: 1.5, color: Colors.blueGrey),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    hintText: 'Ажилтны код',
                    hintStyle: TextStyle(fontSize: 10),
                    //   labelText: 'Нэвтрэх нэр',
                    suffixIcon: Icon(
                      Icons.person,
                      size: 28,
                      color: Color(0xFF13376b),
                    ),

                    //   labelStyle: TextStyle(fontSize: 10),
                  ),
                  minLines: 1,
                  maxLines: 1,
                  autovalidateMode: AutovalidateMode.always,
                  validator: (value) => CheckUserName(value!),
                ),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Text("Нууц үг *",
                      style: Theme.of(context).textTheme.labelSmall,
                      textScaleFactor: ScaleSize.textScaleFactor(context)),
                ),
                TextFormField(
                  controller: txtCntrl_Login_Pwd,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    isDense: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      //<-- SEE HERE
                      borderSide:
                          BorderSide(width: 1.5, color: Colors.blueGrey),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    hintText: 'Та компьютерт нэвтрэх нууц үгээ оруулаарай',
                    hintStyle: TextStyle(fontSize: 10),
                    //     labelText: 'Нууц үг',
                    //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),
                    suffixIcon: IconButton(
                        onPressed: () {
                          setState(() {
                            isVisibilityOFF = !isVisibilityOFF;
                          });
                        },
                        icon: Icon(
                          (isVisibilityOFF)
                              ? Icons.visibility_off
                              : Icons.visibility,
                          size: 20,
                          color: Color(0xFF13376b),
                        )),

                    //   labelStyle: TextStyle(fontSize: 10),
                  ),
                  minLines: 1,
                  maxLines: 1,
                  obscuringCharacter: '*',
                  obscureText: (!isVisibilityOFF) ? true : false,
                  autovalidateMode: AutovalidateMode.always,
                  validator: (value) => CheckUserPwd(value!),
                  onFieldSubmitted: (dfd) {
                    _onPressEnter();
                  },
                ),
                SizedBox(
                  height: 10,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      height: 50,
                      child: ElevatedButton(
                        // style: Theme.of(context).elevatedButtonTheme.style,

                        onPressed: (!isPressBtnOnce)
                            ? () async {
                                _onPressEnter();
                              }
                            : null,
                        child: (!isPressBtnOnce)
                            ? Text('Нэвтрэх')
                            : Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: CircularProgressIndicator(),
                              ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
