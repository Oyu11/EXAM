import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class myMobileScaffold extends StatefulWidget {
  const myMobileScaffold({Key? key}) : super(key: key);

  @override
  State<myMobileScaffold> createState() => _myMobileScaffoldState();
}

class _myMobileScaffoldState extends State<myMobileScaffold> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepOrangeAccent,
    );
  }
}
