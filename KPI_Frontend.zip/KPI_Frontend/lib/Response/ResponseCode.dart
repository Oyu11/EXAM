class ResponseCode{



  String _responseCode;
  String _responseCodeDesc;

  String _actualCode;
  String _actualCodeDesc;

  @override
  String toString() {
    return 'ResponseCode{_responseCode: $_responseCode, _responseCodeDesc: $_responseCodeDesc, _actualCode: $_actualCode, _actualCodeDesc: $_actualCodeDesc}';
  }




  factory ResponseCode.fromJson(Map<String, dynamic> json) {


    return ResponseCode(
      json['responseCode'] == null ? "":  json['responseCode']as String,
      json['responseCodeDesc'] == null ? "":  json['responseCodeDesc']as String,
      json['actualCode'] == null ? "":  json['actualCode'] as String,
      json['actualCodeDesc'] == null ? "":  json['actualCodeDesc']as String,


    );
  }


  ResponseCode(this._responseCode, this._responseCodeDesc, this._actualCode,
      this._actualCodeDesc);

  String get responseCode => _responseCode;

  set responseCode(String value) {
    _responseCode = value;
  }

  String get responseCodeDesc => _responseCodeDesc;

  String get actualCodeDesc => _actualCodeDesc;

  set actualCodeDesc(String value) {
    _actualCodeDesc = value;
  }

  String get actualCode => _actualCode;

  set actualCode(String value) {
    _actualCode = value;
  }

  set responseCodeDesc(String value) {
    _responseCodeDesc = value;
  }



}