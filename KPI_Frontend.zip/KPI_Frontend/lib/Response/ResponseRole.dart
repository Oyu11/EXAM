import '../Const/Constantino.dart';
import '../Model/kpiRole.dart';
import 'ResponseCode.dart';

class ResponseRole{

  ResponseCode _responseCode;
  List<KpiRole> _lstRole;

  ResponseRole(this._responseCode, this._lstRole);


  ResponseCode get responseCode => _responseCode;

  set responseCode(ResponseCode value) {
    _responseCode = value;
  }

  factory ResponseRole.fromJson(Map<String, dynamic> json) {




    return ResponseRole(
      ResponseCode.fromJson(json["responsecode"]),
      List<KpiRole>.from(  json["lstRole"].map( (x) => KpiRole.fromJson(x) )   ),

    );

  }



  @override
  String toString() {
    return 'ResponseRole{_responseCode: $_responseCode, _lstRole: $_lstRole}';
  }

  List<KpiRole> get lstRole => _lstRole;

  set lstRole(List<KpiRole> value) {
    _lstRole = value;
  }
}