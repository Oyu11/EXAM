import 'package:kpi_empl/Response/ResponseCode.dart';
import 'package:kpi_empl/Model/UserSession.dart';

import '../Model/YearMonth.dart';

class ResponseLogin{

  ResponseCode _responseCode;
  UserSessionData _userSessionData;
  List<YearMonth> _lstYearMonth;


  ResponseCode get responseCode => _responseCode;

  set responseCode(ResponseCode value) {
    _responseCode = value;
  }

  ResponseLogin(this._responseCode, this._userSessionData, this._lstYearMonth);

  factory ResponseLogin.fromJson(Map<String, dynamic> json) {

    return ResponseLogin(
         ResponseCode.fromJson(json["responsecode"]),
        UserSessionData.fromJson(json["userSessionData"]),
        List<YearMonth>.from(  json["lstmodelyearmonth"].map( (x) => YearMonth.fromJson(x) )   ),

    );
  }

  UserSessionData get userSessionData => _userSessionData;

  set userSessionData(UserSessionData value) {
    _userSessionData = value;
  }

  List<YearMonth> get lstYearMonth => _lstYearMonth;

  set lstYearMonth(List<YearMonth> value) {
    _lstYearMonth = value;
  }
}