import 'package:kpi_empl/Model/kpiModel.dart';
import 'package:kpi_empl/Response/ResponseCode.dart';

import '../Model/kpiFieldsModel.dart';

class ResponseGetKpi {
  ResponseCode _responseCode;
  List<KpiModel> _lstKpiModel;
  List<KpiFieldsModel> _lstKpiFieldsModel;

  ResponseGetKpi(
      this._responseCode, this._lstKpiModel, this._lstKpiFieldsModel);

  factory ResponseGetKpi.fromJson(Map<String, dynamic> json) {
    return ResponseGetKpi(
      ResponseCode.fromJson(json["responsecode"]),
      List<KpiModel>.from(json["lstKpiModel"].map((x) => KpiModel.fromJson(x))),
      List<KpiFieldsModel>.from(
          json["lstKpiFields"].map((x) => KpiFieldsModel.fromJson(x))),
    );
  }

  List<KpiFieldsModel> get lstKpiFieldsModel => _lstKpiFieldsModel;

  set lstKpiFieldsModel(List<KpiFieldsModel> value) {
    _lstKpiFieldsModel = value;
  }

  List<KpiModel> get lstKpiModel => _lstKpiModel;

  set lstKpiModel(List<KpiModel> value) {
    _lstKpiModel = value;
  }

  ResponseCode get responseCode => _responseCode;

  set responseCode(ResponseCode value) {
    _responseCode = value;
  }
}
