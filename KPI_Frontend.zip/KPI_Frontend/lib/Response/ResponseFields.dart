
import 'package:kpi_empl/Model/kpiModel.dart';
import 'package:kpi_empl/Response/ResponseCode.dart';

import '../Model/kpiFieldsModel.dart';

class ResponseKpiFields{

  ResponseCode _responseCode;
  List<KpiFieldsModel> _lstKpiFieldsModel;

  ResponseKpiFields(
      this._responseCode, this._lstKpiFieldsModel );


  ResponseCode get responseCode => _responseCode;

  set responseCode(ResponseCode value) {
    _responseCode = value;
  }

  factory ResponseKpiFields.fromJson(Map<String, dynamic> json) {




    return ResponseKpiFields(
      ResponseCode.fromJson(json["responsecode"]),
      List<KpiFieldsModel>.from(  json["lstKpiFields"].map( (x) => KpiFieldsModel.fromJson(x) )   ),

    );

  }

  List<KpiFieldsModel> get lstKpiFieldsModel => _lstKpiFieldsModel;

  set lstKpiFieldsModel(List<KpiFieldsModel> value) {
    _lstKpiFieldsModel = value;
  }
}