import 'package:flutter/material.dart';

import 'Login.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KPI: Үнэлгээ',

      theme: ThemeData(
        elevatedButtonTheme: ElevatedButtonThemeData(

              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF13376b),
                foregroundColor: Colors.white,
                textStyle: TextStyle( fontSize: 14 ),
                shape:  RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                 // side: BorderSide(color: Colors.black, width: 2.5))

          ),
          ),

        textTheme: TextTheme(


          labelLarge: const TextStyle(
            fontSize: 14,

            //  fontStyle: FontStyle.italic,
          ),
          labelSmall: const TextStyle(
            fontSize: 10,

          ),
          labelMedium: const TextStyle(
            fontSize: 12,
            fontWeight:  FontWeight.bold
          ),



        ).apply(

        ),

      ),
      home: const MyHomePage(title: 'Ажилтан таны KPI үнэлгээ'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;



  @override
  Widget build(BuildContext context) {

    return  Scaffold(
      body: LayoutBuilder(builder: (BuildContext context, BoxConstraints constraints) {

        return Stack(

        children: [
          Image.asset(

            'assets/images/3C1DD6F7.PNG',
            fit: BoxFit.cover,
            height: double.infinity,
            width: double.infinity,
            alignment: Alignment.center,
//              width: 600.0,
            //            height: 240.0,
            //  fit: BoxFit.cover,
          ),
          Positioned.fill(
            child: Align(
              alignment: Alignment.centerRight,
              child:  Container(
                  margin: EdgeInsets.only(right: 40),
                  width: ( MediaQuery.of(context).size.width>1500)? MediaQuery.of(context).size.width*0.25: 400 ,
                  child: Login()
              ),
            ),
          ),


        ],
        );
      },


      ),

    );
  }
}
