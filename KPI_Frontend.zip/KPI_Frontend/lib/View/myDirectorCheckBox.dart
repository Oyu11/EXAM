import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../Const/Constantino.dart';

class myDirectorCheckBox extends StatefulWidget {
  String userRoleName;
  Function(bool isConfirmed) fnConfirmed;
  bool isConfirmedHub;
  bool isConfirmedDir;
  myDirectorCheckBox({
    Key? key,
    required this.isConfirmedHub,
    required this.fnConfirmed,
    required this.isConfirmedDir,
    required this.userRoleName,
  }) : super(key: key);

  @override
  State<myDirectorCheckBox> createState() => _myDirectorCheckBoxState();
}

class _myDirectorCheckBoxState extends State<myDirectorCheckBox> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 50,
      child: Checkbox(
          value: widget.isConfirmedDir,
          onChanged: (widget.userRoleName != Roles.Director.value)
              ? null
              : (widget.isConfirmedHub)
                  ? null
                  : (bool? value) {
                      setState(() {
                        widget.isConfirmedDir = value!;

                        widget.fnConfirmed(widget.isConfirmedDir);
                      });
                    }),
    );
  }
}
