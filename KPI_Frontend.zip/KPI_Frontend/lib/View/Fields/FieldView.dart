import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kpi_empl/Controllr/kpiController.dart';
import 'package:kpi_empl/Model/kpiFieldsModel.dart';
import 'package:kpi_empl/Model/kpiRole.dart';
import '../../Const/Constantino.dart';
import '../../Model/UserSession.dart';
import '../Roles/RoleView.dart';
import '../Roles/ScoreButton.dart';

class FieldView extends StatefulWidget {
  UserSessionData userSessionData;
  String selectedYear;
  String selectedMonth;
  List<String> roleList;
  FieldView({
    Key? key,
    required this.userSessionData,
    required this.roleList,
    required this.selectedYear,
    required this.selectedMonth,
  }) : super(key: key);
  @override
  State<FieldView> createState() => _FieldViewState();
}

class _FieldViewState extends State<FieldView> {
  int _selectedDataIndex = 0;
  bool isNew_KpiDate = false;

  List<String> lstRoleT = [];
  List<KpiFieldsModel> lstKpiFileds = [];
  List<ActionChip> lstChips = [];
  List<KpiRole> lstRoleTemp = [];
  late String _selectedYear;
  late String _selectValue;
  late String _selectedMonth;

  final textControllerPoistion = TextEditingController();
  final textControllerCol1 = TextEditingController();
  final textControllerCol2 = TextEditingController();
  final textControllerCol3 = TextEditingController();
  final textControllerCol4 = TextEditingController();
  final textControllerCol5 = TextEditingController();
  final textControllerCol6 = TextEditingController();
  final textControllerCol7 = TextEditingController();
  final textControllerCol8 = TextEditingController();
  final textControllerCol9 = TextEditingController();
  final textControllerCol10 = TextEditingController();
  final textControllerCol11 = TextEditingController();
  final textControllerCol12 = TextEditingController();
  final textControllerCol13 = TextEditingController();
  final textControllerCol14 = TextEditingController();
  final textControllerCol15 = TextEditingController();
  final textControllerCol16 = TextEditingController();
  final textControllerCol17 = TextEditingController();
  final textControllerCol18 = TextEditingController();
  final textControllerCol19 = TextEditingController();
  final textControllerCol20 = TextEditingController();

  double update_score1 = 0.0;
  double update_score2 = 0.0;
  double update_score3 = 0.0;
  double update_score4 = 0.0;
  double update_score5 = 0.0;
  double update_score6 = 0.0;
  double update_score7 = 0.0;
  double update_score8 = 0.0;
  double update_score9 = 0.0;
  double update_score10 = 0.0;
  late Future _load;

  @override
  void initState() {
    super.initState();
    lstRoleT = widget.roleList;
    if (lstRoleT.last.toUpperCase() == 'БҮГД') {
      lstRoleT.removeLast();
    }
    if (!lstRoleT.contains("Бусад")) {
      lstRoleT.add("Бусад");
    }

    _selectedYear = widget.selectedYear;
    _selectedMonth = widget.selectedMonth;
    _selectValue = lstRoleT.first;

    _load = LoadData(lstRoleT.first);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _load,
      builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
        switch (snapshot.connectionState) {
          case ConnectionState.none:
            return Text(
              "ERROR. Request to The App Support team.",
              style: TextStyle(color: Colors.red),
            );
          case ConnectionState.waiting:
            return CircularProgressIndicator();
          default:
            if (snapshot.hasError)
              return Text(
                "No Data found. Error:" + snapshot.error.toString(),
                style: TextStyle(color: Colors.red),
              );
            else {
              if (snapshot.hasData) {
                String str = snapshot.data as String;

                return getData();
                //return Text("Test Data");
              } else
                return Text(
                    "You have no DATA ............................................................................... 2");
            }
        }
      },
    );
  }

  Widget getData() {
    return Align(
      alignment: Alignment.center,
      child: Wrap(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: RoleView(
              lstKpiRole: lstRoleTemp,
              userSessionData: widget.userSessionData,
              role_name: _selectValue,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Container(
              margin: EdgeInsets.all(0),
              width: 600,
              child: Card(
                margin: EdgeInsets.all(10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5.0), //<-- SEE HERE
                ),
                elevation: 10,
                // color:   Color(0XFF59ba89),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'Үнэлгээний нэршил тохируулах/оноо тохируулах цэс',
                        style: TextStyle(
                            fontSize: 30,
                            color: Colors.blueGrey,
                            fontWeight: FontWeight.bold),
                      ),
                      Divider(thickness: 0.5, color: Colors.blueGrey),
                      SizedBox(
                        height: 30,
                      ),
                      Container(
                          margin: const EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              const Expanded(
                                flex: 1,
                                child: Padding(
                                  padding: EdgeInsets.only(right: 5),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        'Албан тушаал :',
                                        style: TextStyle(
                                            fontSize: 20,
                                            color: Colors.blueGrey),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 2,
                                child: DropdownButton<String>(
                                  isExpanded: true,
                                  value: _selectValue,
                                  items: lstRoleT.map((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Center(child: Text(value)),
                                    );
                                  }).toList(),
                                  onChanged: (String? val) {
                                    setState(() {
                                      _selectValue = val!;

                                      LoadData(_selectValue);
                                    });
                                  },
                                ),
                              ),
                            ],
                          )),
                      _selectValue == "Бусад"
                          ? Container(
                              margin: const EdgeInsets.only(left: 180),
                              child: Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Column(
                                      children: [
                                        TextFormField(
                                          controller: textControllerPoistion,
                                          textAlign: TextAlign.center,
                                          decoration: InputDecoration(
                                            isDense: true,
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                              //<-- SEE HERE
                                              borderSide: const BorderSide(
                                                  width: 1.5,
                                                  color: Colors.blueGrey),
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                            hintText: 'Албан тушаал',
                                            hintStyle: TextStyle(fontSize: 10),
                                          ),
                                          minLines: 1,
                                          maxLines: 1,
                                          onFieldSubmitted: (dfd) {},
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : SizedBox(
                              height: 1,
                            ),
                      const SizedBox(
                        height: 20,
                      ),
                      Container(
                          margin: const EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              const Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 01',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol1,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: const BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score1,
                                fnGetValue: (double getSelectedValue) {
                                  update_score1 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 02',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol2,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score2,
                                fnGetValue: (double getSelectedValue) {
                                  update_score2 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 03',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol3,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score3,
                                fnGetValue: (double getSelectedValue) {
                                  update_score3 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 04',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol4,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score4,
                                fnGetValue: (double getSelectedValue) {
                                  update_score4 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 05',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol5,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score5,
                                fnGetValue: (double getSelectedValue) {
                                  update_score5 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 06',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol6,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score6,
                                fnGetValue: (double getSelectedValue) {
                                  update_score6 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 07',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol7,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score7,
                                fnGetValue: (double getSelectedValue) {
                                  update_score7 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 08',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol8,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score8,
                                fnGetValue: (double getSelectedValue) {
                                  update_score8 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 09',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol9,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      onFieldSubmitted: (dfd) {},
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score9,
                                fnGetValue: (double getSelectedValue) {
                                  update_score9 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 15),
                          child: Row(
                            children: [
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          ' Үзүүлэлт 10',
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: Colors.blueGrey),
                                        )
                                      ],
                                    ),
                                  )),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  children: [
                                    TextFormField(
                                      controller: textControllerCol10,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                        isDense: true,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        focusedBorder: OutlineInputBorder(
                                          //<-- SEE HERE
                                          borderSide: BorderSide(
                                              width: 1.5,
                                              color: Colors.blueGrey),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        hintText: 'Тайлбар мэдээлэл',
                                        hintStyle: TextStyle(fontSize: 10),
                                        //     labelText: 'Нууц үг',
                                        //  prefixIcon: Icon(Icons.lock, size: 28,color: Color(0xFFff7e29),),

                                        //   labelStyle: TextStyle(fontSize: 10),
                                      ),
                                      minLines: 1,
                                      maxLines: 1,
                                      /*onFieldSubmitted: (dfd) {
                                        LoadData();
                                      },*/
                                    ),
                                  ],
                                ),
                              ),
                              ScoreButton(
                                valueOfScore: update_score10,
                                fnGetValue: (double getSelectedValue) {
                                  update_score10 = getSelectedValue;
                                },
                              ),
                            ],
                          )),
                      Container(
                          margin: EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              /*
                              Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        SizedBox(
                                          child: ElevatedButton(
                                            onPressed: () async {
                                              isNew_KpiDate = true;

                                              textControllerPoistion.text = "";
                                              textControllerCol1.text = "";
                                              textControllerCol2.text = "";
                                              textControllerCol3.text = "";
                                              textControllerCol4.text = "";
                                              textControllerCol5.text = "";
                                              textControllerCol6.text = "";
                                              textControllerCol7.text = "";
                                              textControllerCol8.text = "";
                                              textControllerCol9.text = "";
                                              textControllerCol10.text = "";
                                            },
                                            child: Text("New"),
                                          ),
                                          height: 50,
                                        )
                                      ],
                                    ),
                                  )),
                                  */
                              Expanded(
                                flex: 1,
                                child: Container(
                                  height: 50,
                                  child: ElevatedButton(
                                    onPressed: () async {
                                      SaveKPI_FieldData();
                                    },
                                    child: Text("Save"),
                                  ),
                                ),
                              )
                            ],
                          )),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<String> LoadData(String position) async {
    lstKpiFileds.clear();
    if (position == "Бусад") {
      isNew_KpiDate = true;
      update_score1 = 0.0;
      update_score2 = 0.0;
      update_score3 = 0.0;
      update_score4 = 0.0;
      update_score5 = 0.0;
      update_score6 = 0.0;
      update_score7 = 0.0;
      update_score8 = 0.0;
      update_score9 = 0.0;
      update_score10 = 0.0;
      textControllerPoistion.text = "";
      textControllerCol1.text = "";
      textControllerCol2.text = "";
      textControllerCol3.text = "";
      textControllerCol4.text = "";
      textControllerCol5.text = "";
      textControllerCol6.text = "";
      textControllerCol7.text = "";
      textControllerCol8.text = "";
      textControllerCol9.text = "";
      textControllerCol10.text = "";
      lstRoleTemp.clear();
    } else {
      var getData = await KpiController()
          .GetKpi_Fields(widget.userSessionData, _selectedYear, _selectedMonth);

      if (getData.responseCode.responseCode == ResponseValue.Success.value) {
        lstKpiFileds = getData.lstKpiFieldsModel;
        if (lstKpiFileds.isNotEmpty) {
          lstKpiFileds.forEach(
            (element) {
              if (position == element.positionname) {
                setState(() {
                  isNew_KpiDate = false;

                  update_score1 = element.scorenumber1.toDouble();
                  update_score2 = element.scorenumber2.toDouble();
                  update_score3 = element.scorenumber3.toDouble();
                  update_score4 = element.scorenumber4.toDouble();
                  update_score5 = element.scorenumber5.toDouble();
                  update_score6 = element.scorenumber6.toDouble();
                  update_score7 = element.scorenumber7.toDouble();
                  update_score8 = element.scorenumber8.toDouble();
                  update_score9 = element.scorenumber9.toDouble();
                  update_score10 = element.scorenumber10.toDouble();
                  _selectedDataIndex = element.id;
                  textControllerPoistion.text = element.positionname;
                  textControllerCol1.text = element.col1;
                  textControllerCol2.text = element.col2;
                  textControllerCol3.text = element.col3;
                  textControllerCol4.text = element.col4;
                  textControllerCol5.text = element.col5;
                  textControllerCol6.text = element.col6;
                  textControllerCol7.text = element.col7;
                  textControllerCol8.text = element.col8;
                  textControllerCol9.text = element.col9;
                  textControllerCol10.text = element.col10;
                });
              }
            },
          );
        }
      } else {
        _selectedDataIndex = 0;
        textControllerPoistion.text = "";
        textControllerCol1.text = "";
        textControllerCol2.text = "";
        textControllerCol3.text = "";
        textControllerCol4.text = "";
        textControllerCol5.text = "";
        textControllerCol6.text = "";
        textControllerCol7.text = "";
        textControllerCol8.text = "";
        textControllerCol9.text = "";
        textControllerCol10.text = "";
        update_score1 = 0.0;
        update_score2 = 0.0;
        update_score3 = 0.0;
        update_score4 = 0.0;
        update_score5 = 0.0;
        update_score6 = 0.0;
        update_score7 = 0.0;
        update_score8 = 0.0;
        update_score9 = 0.0;
        update_score10 = 0.0;

        var snackBar = const SnackBar(
          content: Center(
              child: Text(
            'Мэдээлэл олдсонгүй !!',
            style: TextStyle(color: Colors.orangeAccent, fontSize: 23),
          )),
          elevation: 10,
          behavior: SnackBarBehavior.floating,
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
      }
      var getData2 =
          await KpiController().GetScore(widget.userSessionData, position);
      setState(() {
        lstRoleTemp = getData2.lstRole;
      });
    }
    return "";
  }

  Future<void> SaveKPI_FieldData() async {
    KpiFieldsModel kpiFieldModelTemp = tmpKpiFieldsModel;

    if (lstKpiFileds.isEmpty) {
      kpiFieldModelTemp.positionname =
          textControllerPoistion.text.trim().toUpperCase();
      kpiFieldModelTemp.effectivemonth = int.parse(_selectedMonth);
      kpiFieldModelTemp.effectiveyear = int.parse(_selectedYear);

      kpiFieldModelTemp.col1 = textControllerCol1.text.trim();
      kpiFieldModelTemp.col2 = textControllerCol2.text.trim();
      kpiFieldModelTemp.col3 = textControllerCol3.text.trim();
      kpiFieldModelTemp.col4 = textControllerCol4.text.trim();
      kpiFieldModelTemp.col5 = textControllerCol5.text.trim();
      kpiFieldModelTemp.col6 = textControllerCol6.text.trim();
      kpiFieldModelTemp.col7 = textControllerCol7.text.trim();
      kpiFieldModelTemp.col8 = textControllerCol8.text.trim();
      kpiFieldModelTemp.col9 = textControllerCol9.text.trim();
      kpiFieldModelTemp.col10 = textControllerCol10.text.trim();
      kpiFieldModelTemp.scorenumber1 = update_score1.toInt();
      kpiFieldModelTemp.scorenumber2 = update_score2.toInt();
      kpiFieldModelTemp.scorenumber3 = update_score3.toInt();
      kpiFieldModelTemp.scorenumber4 = update_score4.toInt();
      kpiFieldModelTemp.scorenumber5 = update_score5.toInt();
      kpiFieldModelTemp.scorenumber6 = update_score6.toInt();
      kpiFieldModelTemp.scorenumber7 = update_score7.toInt();
      kpiFieldModelTemp.scorenumber8 = update_score8.toInt();
      kpiFieldModelTemp.scorenumber9 = update_score9.toInt();
      kpiFieldModelTemp.scorenumber10 = update_score10.toInt();

      kpiFieldModelTemp.modifieduser = widget.userSessionData.emplid;
    } else {
      if (!isNew_KpiDate) {
        kpiFieldModelTemp = lstKpiFileds
            .where((element) => element.id == _selectedDataIndex)
            .first;
      }
      kpiFieldModelTemp.positionname = textControllerPoistion.text.trim();
      kpiFieldModelTemp.effectivemonth = int.parse(_selectedMonth);
      kpiFieldModelTemp.effectiveyear = int.parse(_selectedYear);

      kpiFieldModelTemp.col1 = textControllerCol1.text.trim();
      kpiFieldModelTemp.col2 = textControllerCol2.text.trim();
      kpiFieldModelTemp.col3 = textControllerCol3.text.trim();
      kpiFieldModelTemp.col4 = textControllerCol4.text.trim();
      kpiFieldModelTemp.col5 = textControllerCol5.text.trim();
      kpiFieldModelTemp.col6 = textControllerCol6.text.trim();
      kpiFieldModelTemp.col7 = textControllerCol7.text.trim();
      kpiFieldModelTemp.col8 = textControllerCol8.text.trim();
      kpiFieldModelTemp.col9 = textControllerCol9.text.trim();
      kpiFieldModelTemp.col10 = textControllerCol10.text.trim();

      kpiFieldModelTemp.scorenumber1 = update_score1.toInt();
      kpiFieldModelTemp.scorenumber2 = update_score2.toInt();
      kpiFieldModelTemp.scorenumber3 = update_score3.toInt();
      kpiFieldModelTemp.scorenumber4 = update_score4.toInt();
      kpiFieldModelTemp.scorenumber5 = update_score5.toInt();
      kpiFieldModelTemp.scorenumber6 = update_score6.toInt();
      kpiFieldModelTemp.scorenumber7 = update_score7.toInt();
      kpiFieldModelTemp.scorenumber8 = update_score8.toInt();
      kpiFieldModelTemp.scorenumber9 = update_score9.toInt();
      kpiFieldModelTemp.scorenumber10 = update_score10.toInt();
    }

    if (kpiFieldModelTemp.positionname.trim() != "" && checkFactorColum()) {
      var rslt = await KpiController()
          .SaveKpi_Fields(widget.userSessionData, kpiFieldModelTemp);
      lstRoleTemp.forEach(
        (element) {
          if (element.roleName.toUpperCase() == 'БУСАД') {
            element.roleName = textControllerPoistion.text.trim().toUpperCase();
          }
        },
      );
      var rslt_role =
          await KpiController().SaveScore(widget.userSessionData, lstRoleTemp);

      if (rslt.responseCode == ResponseValue.Success.value &&
          rslt_role.responseCode == ResponseValue.Success.value) {
        var snackBar = SnackBar(
          content: Center(
              child: Text(
            'Мэдээллийг амжилттай хадгаллаа',
            style: TextStyle(color: Colors.white, fontSize: 15),
          )),
          elevation: 10,
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.green,
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);

        var getData = await KpiController().GetKpi_Fields(
            widget.userSessionData, widget.selectedYear, widget.selectedMonth);
        if (_selectValue == "Бусад") {
          if (getData.responseCode.responseCode ==
              ResponseValue.Success.value) {
            List<KpiFieldsModel> lstKpiFileds = getData.lstKpiFieldsModel;
            lstRoleT.clear();
            if (lstKpiFileds.isNotEmpty) {
              lstKpiFileds.forEach((element) {
                lstRoleT.add(element.positionname);
              });
              lstRoleT.add("Бусад");
              LoadData(_selectValue == "Бусад"
                  ? textControllerPoistion.text
                  : _selectValue);
            }
          }
        } else {
          print("Busdiig songoogui uchir dahin service duudhaas sergiilew");
        }
      } else {
        var snackBar = SnackBar(
          content: Center(
              child: Text(
            'Мэдэлэлийг хадгалахад алдаа гарлаа:' +
                rslt.responseCode.toString(),
            style: TextStyle(color: Colors.orangeAccent, fontSize: 23),
          )),
          elevation: 10,
          behavior: SnackBarBehavior.floating,
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
      }
    } else {
      var snackBar = SnackBar(
        content: Center(
            child: Text(
          'Албан тушаал болон Үзүүлэлт хэсэгт мэдээлэл оруулна уу !!',
          style: TextStyle(color: Colors.orangeAccent, fontSize: 23),
        )),
        elevation: 10,
        behavior: SnackBarBehavior.floating,
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    }
  }

  bool checkFactorColum() {
    String tmpStr = textControllerCol1.text.trim() +
        textControllerCol2.text.trim() +
        textControllerCol3.text.trim() +
        textControllerCol4.text.trim() +
        textControllerCol5.text.trim() +
        textControllerCol6.text.trim() +
        textControllerCol7.text.trim() +
        textControllerCol8.text.trim() +
        textControllerCol9.text.trim() +
        textControllerCol10.text.trim();

    return (tmpStr.trim().length > 0) ? true : false;
  }
}
