import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class myTextFields extends StatefulWidget {
  Function(String commstr) fnText;
  String valuetStr;

  myTextFields({Key? key,
    required this.fnText,
    required this.valuetStr
  }) : super(key: key);

  @override
  State<myTextFields> createState() => _myTextFieldsState();
}

class _myTextFieldsState extends State<myTextFields> {

  final 	textControllerComment  = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    textControllerComment.text = twodouble(widget.valuetStr);

  }


  @override
  Widget build(BuildContext context) {
    return Container(
      child:  TextFormField(




      onChanged:  (val){

          setState(() {

            widget.fnText(val);

          });


        },

        controller: textControllerComment,
        decoration:   InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.cyan, width: 2),
          ),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.red),
          ),
        ),

      ),
    );
  }

  String twodouble(String valuetStr) {

    String returnVal = "0";

    try{

      returnVal =       double.parse(valuetStr).round().toString();

    }catch(ex){

    }

    return returnVal;

  }
}
