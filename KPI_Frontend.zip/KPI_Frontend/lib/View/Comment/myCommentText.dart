import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../Const/Constantino.dart';

class myCommentText extends StatefulWidget {
  String commentStr;
  bool isHubDirectorConfirmed;
  bool isDirectorConfirmed;
  String RoleName;
  Function(String commstr) fnComment;
  Roles purposedRole;

  myCommentText(
      {Key? key,
      required this.commentStr,
      required this.isDirectorConfirmed,
      required this.isHubDirectorConfirmed,
      required this.RoleName,
      required this.fnComment,
      required this.purposedRole})
      : super(key: key);

  @override
  State<myCommentText> createState() => _myCommentTextState();
}

class _myCommentTextState extends State<myCommentText> {
  final textControllerComment = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    textControllerComment.text = widget.commentStr;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: InkWell(
        onDoubleTap: () {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                insetPadding: EdgeInsets.symmetric(vertical: 0),
                // contentPadding: EdgeInsets.zero,
                title: Text('Нэмэлт тайлбар мэдээлэл'),
                content: Text(textControllerComment.text),
                actions: <Widget>[
                  ElevatedButton(
                    child: const Text("Ok"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              );
            },
          );
        },
        child: TextFormField(
          onChanged: (val) {
            setState(() {
              widget.fnComment(val);
            });
          },
          controller: textControllerComment,
          enabled: isEnable(),
          decoration: InputDecoration(
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.cyan, width: 2),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.red),
            ),
          ),
        ),
      ),
    );
  }

  bool isEnable() {
    if (widget.purposedRole.value == Roles.HubDirector.value) {
      if (widget.RoleName == Roles.HubDirector.value) {
        return true;
      } else if (widget.RoleName != Roles.HubDirector.value) {
        return false;
      } else {
        return false;
      }
    } else if (widget.purposedRole.value == Roles.Director.value) {
      if (widget.isHubDirectorConfirmed) {
        return false;
      } else if (widget.RoleName != Roles.Director.value) {
        return false;
      } else {
        return true;
      }
    } else if (widget.purposedRole.value == Roles.AllBranchManager.value) {
      return true;
      /*
      if (!widget.isHubDirectorConfirmed){
        return true;
      } else if (widget.RoleName  != Roles.AllBranchManager.value ){
        return false;
      }else {
        return false;
      }

       */
    } else if (widget.purposedRole.value == Roles.Employee.value) {
      if (widget.isHubDirectorConfirmed || widget.isDirectorConfirmed) {
        return false;
      } else if (widget.RoleName != Roles.Employee.value) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }
}
