import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../Const/Constantino.dart';

class myDropDownButton extends StatefulWidget {
  String isKpiOrStatus;
  bool isConifrmed;
  Function(String str) fnGetSelectedValue;
  String selectedKpiRequired;

  String userRoleName;
  myDropDownButton(
      {Key? key,
      required this.isKpiOrStatus,
      required this.isConifrmed,
      required this.selectedKpiRequired,
      required this.fnGetSelectedValue,
      required this.userRoleName})
      : super(key: key);

  @override
  State<myDropDownButton> createState() => _myDropDownButtonState();
}

class _myDropDownButtonState extends State<myDropDownButton> {
  @override
  Widget build(BuildContext context) {
    return widget.isKpiOrStatus == "kpi"
        ? DropdownButton<String>(
            isExpanded: true,
            value: widget.selectedKpiRequired,
            items: lstKpiRequired.map(
              (String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              },
            ).toList(),
            onChanged: ((widget.userRoleName == Roles.Director.value &&
                        widget.isConifrmed == true) ||
                    (widget.userRoleName == Roles.AllBranchManager.value) ||
                    (widget.userRoleName == Roles.HubDirector.value &&
                        widget.isConifrmed == true))
                ? (value) {
                    setState(() {
                      widget.selectedKpiRequired = value!;
                      widget.fnGetSelectedValue(value!);
                    });
                  }
                : null,
          )
        : (widget.userRoleName == Roles.Director.value)
            ? DropdownButton<String>(
                isExpanded: true,
                value: widget.selectedKpiRequired,
                items: lstConfirmRequired.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: ((widget.userRoleName == Roles.Director.value &&
                            widget.isConifrmed == true) ||
                        (widget.userRoleName == Roles.AllBranchManager.value))
                    ? (value) {
                        setState(() {
                          widget.selectedKpiRequired = value!;
                          widget.fnGetSelectedValue(value!);
                        });
                      }
                    : null,
              )
            : DropdownButton<String>(
                value: widget.selectedKpiRequired,
                items: lstConfirmRequiredHub.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    widget.selectedKpiRequired = newValue!;
                    widget.fnGetSelectedValue(newValue!);
                  });
                },
              );
  }
}
