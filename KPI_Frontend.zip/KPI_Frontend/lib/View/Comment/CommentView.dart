import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:kpi_empl/Const/Constantino.dart';
import 'package:kpi_empl/Controllr/kpiController.dart';
import 'package:kpi_empl/Model/kpiModel.dart';

import '../../Model/UserSession.dart';

class CommentView extends StatefulWidget {
  bool isConfirmed;
  List<KpiModel> lstKpiModel;
  UserSessionData userSessionData;
  Function(bool b) fnRefresh;
  CommentView(
      {Key? key,
      required this.userSessionData,
      required this.isConfirmed,
      required this.lstKpiModel,
      required this.fnRefresh})
      : super(key: key);

  @override
  State<CommentView> createState() => _CommentViewState();
}

class _CommentViewState extends State<CommentView> {
  late String _selectedComment = 'Танилцсан';
  List<String> Comments = [
    'Танилцсан',
    'Өвчтэй/Чөлөөтэй',
    'Аавын 7 хоног',
    'Ээлжийн амралт',
    'Орлон ажилласан',
    'Call center',
    'Декрит',
    'Бусад'
  ];

  final txtCntrl_comment = TextEditingController();

  @override
  void dispose() {
    txtCntrl_comment.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    // Initialize the txtCntrl_comment with the value from lstKpiModel
    if (widget.lstKpiModel.isNotEmpty &&
        widget.lstKpiModel.first.commentbyemployee != null) {
      txtCntrl_comment.text = widget.lstKpiModel.first.commentbyemployee;
    }

    // Determine the selected comment based on the initialized txtCntrl_comment
    if (txtCntrl_comment.text.trim().isEmpty) {
      _selectedComment = 'Танилцсан';
    } else {
      _selectedComment = Comments.contains(txtCntrl_comment.text.trim())
          ? txtCntrl_comment.text
          : 'Бусад';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: 480,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButton<String>(
              isExpanded: true,
              value: _selectedComment,
              items: Comments.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (widget.isConfirmed)
                  ? null
                  : (value) {
                      setState(() {
                        _selectedComment = value!;
                        widget.lstKpiModel.first.commentbyemployee =
                            (_selectedComment.toUpperCase() == 'БУСАД')
                                ? txtCntrl_comment.text.trim()
                                : _selectedComment;
                      });
                    },
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 390,
                  height: 50,
                  child: (_selectedComment == 'Бусад')
                      ? TextField(
                          enabled: (widget.isConfirmed) ? false : true,
                          controller: txtCntrl_comment,
                          maxLength: 200,
                          decoration: InputDecoration(
                            filled: true, //<-- SEE HERE
                            fillColor: Colors.white, //<-- SEE HERE
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 10.0),
                            hintText:
                                'Хэрвээ танд нэмэлт тайлбар байвал оруулна уу ',
                            hintStyle: TextStyle(
                                fontSize: 11, color: Colors.blueGrey), //
                            labelText: 'Тайлбар',
                            labelStyle: TextStyle(color: Colors.blue),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        )
                      : Text(''),
                ),
                SizedBox(
                  width: 10,
                ),
                Container(
                  width: 80,
                  height: 30,
                  child: ElevatedButton(
                    onPressed: (widget.isConfirmed)
                        ? null
                        : () async {
                            if (!widget.isConfirmed) {
                              //if (txtCntrl_comment.text.trim().length > 0) {
                              widget.lstKpiModel.first.commentbyemployee =
                                  (_selectedComment.toUpperCase() == 'БУСАД')
                                      ? txtCntrl_comment.text.trim()
                                      : _selectedComment;
                              var returnValue = await KpiController()
                                  .SaveKpiDetails(widget.userSessionData,
                                      widget.lstKpiModel);
                              widget.fnRefresh(true);
                              if (returnValue.responseCode ==
                                  ResponseValue.Success.value) {
                                var snackBar = SnackBar(
                                  content: Center(
                                      child: Text(
                                    'Мэдээллийг амжилттай хадгалагдлаа.',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 14),
                                    textScaleFactor:
                                        ScaleSize.textScaleFactor(context),
                                  )),
                                  elevation: 10,
                                  behavior: SnackBarBehavior.floating,
                                  backgroundColor: Colors.green,
                                );
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(snackBar);
                              } else {
                                var snackBar = SnackBar(
                                  content: Center(
                                      child: Text(
                                    'Мэдээллийг хадгалахад алдаа гарлаа:' +
                                        returnValue.responseCodeDesc,
                                    style: TextStyle(
                                        color: Colors.red, fontSize: 23),
                                  )),
                                  elevation: 10,
                                  behavior: SnackBarBehavior.floating,
                                );

                                ScaffoldMessenger.of(context)
                                    .showSnackBar(snackBar);
                              }
                              /*
                              } else {
                                var snackBar = SnackBar(
                                  content: Center(
                                      child: Text(
                                    'Тайлбар мэдээллийг оруулна уу!',
                                    style: TextStyle(
                                        color: Colors.orange, fontSize: 23),
                                  )),
                                  elevation: 10,
                                  behavior: SnackBarBehavior.floating,
                                  width: 400,
                                );

                                ScaffoldMessenger.of(context)
                                    .showSnackBar(snackBar);
                              }*/
                            } else {
                              var snackBar = SnackBar(
                                content: Center(
                                    child: Text(
                                  'Мэдээллийг Захирал баталгаажуулсан байна, өөрчлөлт оруулах боломжгүй!',
                                  style: TextStyle(
                                      color: Colors.orange, fontSize: 18),
                                )),
                                elevation: 10,
                                behavior: SnackBarBehavior.floating,
                                width: 600,
                              );

                              ScaffoldMessenger.of(context)
                                  .showSnackBar(snackBar);
                            }
                          },
                    child: Text('Save'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
