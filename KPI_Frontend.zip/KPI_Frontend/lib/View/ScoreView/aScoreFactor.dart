import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class aScoreFactor extends StatelessWidget {
  String FieldName;
  double ScorePlan;
  double NumberPlan;
  double Score;
  double ScoreDA;
  aScoreFactor(
      {Key? key,
      required this.FieldName,
      required this.ScorePlan,
      required this.NumberPlan,
      required this.Score,
      required this.ScoreDA})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.2,
            height: 70,
            child: Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7), //<-- SEE HERE
              ),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    FieldName,
                    style: const TextStyle(fontSize: 16, color: Colors.black45),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            width: 80,
            height: 60,
            child: Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7), //<-- SEE HERE
              ),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    ScorePlan == 0.0 ? "-" : "$ScorePlan%",
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black45),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            width: 80,
            height: 60,
            child: Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7), //<-- SEE HERE
              ),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    NumberPlan == 0.0 ? "-" : "$NumberPlan",
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black45),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            width: 80,
            height: 60,
            child: Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7), //<-- SEE HERE
              ),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    Score == 0.0 ? "-" : "$Score%",
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black45),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            width: 80,
            height: 60,
            child: Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(7), //<-- SEE HERE
              ),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    ScoreDA == 0.0 ? "-" : "$ScoreDA",
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black45),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
