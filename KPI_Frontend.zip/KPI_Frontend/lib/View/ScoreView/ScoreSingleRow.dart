import 'package:animated_flip_counter/animated_flip_counter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'ScoreView.dart';

class ScoreSingleRow extends StatefulWidget {
  bool isConfirmed;
  Function(double dValue) fnEdit;
  double valueOfScore;
  List<int> lst_IntValues;

  ScoreSingleRow(
      {Key? key,
      required this.isConfirmed,
      required this.fnEdit,
      required this.valueOfScore,
      required this.lst_IntValues})
      : super(key: key);

  @override
  State<ScoreSingleRow> createState() => _ScoreSingleRowState();
}

class _ScoreSingleRowState extends State<ScoreSingleRow> {
  double _sizeu = 20;

  @override
  Widget build(BuildContext context) {
    GetValue(double dd) {
      setState(() {
        widget.valueOfScore = dd;
      });
    }

    Widget _buildButton(num value) {
      return Row(
        children: [
          GestureDetector(
            onTap: (widget.isConfirmed)
                ? null
                : () {
                    setState(() {
                      if (widget.valueOfScore > -(widget.lst_IntValues.last)) {
                        //widget.lst_IntValues.length - 1
                        widget.valueOfScore -= value;
                        widget.fnEdit(widget.valueOfScore);
                      }
                    });
                  },
            child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.only(top: 3, bottom: 3),
                  child: Icon(
                    Icons.arrow_back_ios_sharp,
                    color: Colors.blueGrey,
                    size: _sizeu,
                  ),
                )),
          ),
          GestureDetector(
            child: Padding(
              padding: const EdgeInsets.only(left: 5, right: 5),
              child: AnimatedFlipCounter(
                value: widget.valueOfScore,
                duration: Duration(seconds: 2),
                padding: EdgeInsets.symmetric(vertical: 8),
                curve: Curves.elasticOut,
                textStyle: TextStyle(fontSize: _sizeu, color: Colors.pink),
              ),
            ),
            onTap: (widget.isConfirmed)
                ? null
                : () async {
                    double returnValueFromScoreList = await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          insetPadding: EdgeInsets.symmetric(vertical: 0),
                          // contentPadding: EdgeInsets.zero,
                          title: Text('Оноо сонгон уу'),
                          content: Card(
                            elevation: 10,
                            child: Container(
                              margin: EdgeInsets.all(10),
                              child: ScoreList(
                                lst_intValue: widget.lst_IntValues,
                                fnGetValue: GetValue,
                                ScoreValue: widget.valueOfScore,
                              ),
                              height: 250,
                            ),
                          ),
                          actions: <Widget>[
                            ElevatedButton(
                              child: const Text("Continue"),
                              onPressed: () {
                                Navigator.of(context).pop(widget.valueOfScore);
                              },
                            ),
                            ElevatedButton(
                              child: const Text("Cancel"),
                              onPressed: () {
                                Navigator.of(context).pop(999);
                              },
                            )
                          ],
                        );
                      },
                    );

                    if (returnValueFromScoreList != 999) {
                      setState(() {
                        widget.fnEdit(returnValueFromScoreList);
                      });
                    }
                  },
          ),
          GestureDetector(
            onTap: (widget.isConfirmed)
                ? null
                : () {
                    setState(() {
                      if (widget.valueOfScore < widget.lst_IntValues.last) {
                        widget.valueOfScore += value;
                        widget.fnEdit(widget.valueOfScore);
                      }
                    });
                  },
            child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.only(top: 3, bottom: 3),
                  child: Icon(
                    Icons.arrow_forward_ios_sharp,
                    color: Colors.blueGrey,
                    size: _sizeu,
                  ),
                )),
          ),
        ],
      );
    }

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          SizedBox(
            width: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [1].map(_buildButton).toList(),
          ),
        ],
      ),
    );
  }
}
