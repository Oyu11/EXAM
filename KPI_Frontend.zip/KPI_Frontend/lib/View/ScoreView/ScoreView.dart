import 'package:animated_flip_counter/animated_flip_counter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ScoreList extends StatefulWidget {
  double ScoreValue;
  Function(double SelectedValue) fnGetValue;
  List<int> lst_intValue;
  ScoreList(
      {Key? key,
      required this.lst_intValue,
      required this.fnGetValue,
      required this.ScoreValue})
      : super(key: key);

  @override
  State<ScoreList> createState() => _ScoreState();
}

class _ScoreState extends State<ScoreList> {
  late int DigitValue_max = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    DigitValue_max = widget.lst_intValue.last;
    widget.lst_intValue.clear();

    for (int i = 0; i <= DigitValue_max; i = i + 5) {
      widget.lst_intValue.add(i);
    }
    if (!widget.lst_intValue.contains(DigitValue_max)) {
      widget.lst_intValue.add(DigitValue_max);
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget _buildButton(num value) {
      return Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 5, bottom: 5),
            child: FloatingActionButton(
              child: Text(
                '+$value',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {
                  widget.ScoreValue = value.toDouble();

                  widget.fnGetValue(widget.ScoreValue);
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 5, bottom: 5),
            child: FloatingActionButton(
              child: Text(
                '-$value',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {
                  widget.ScoreValue = -value.toDouble();

                  widget.fnGetValue(widget.ScoreValue);
                });
              },
            ),
          ),
        ],
      );
    }

    return Center(
      child: SizedBox(
        height: 250,
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              AnimatedFlipCounter(
                value: widget.ScoreValue,
                duration: Duration(seconds: 2),
                padding: EdgeInsets.symmetric(vertical: 8),
                curve: Curves.elasticOut,
                textStyle: TextStyle(fontSize: 80, color: Colors.pink),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: widget.lst_intValue.map(_buildButton).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
