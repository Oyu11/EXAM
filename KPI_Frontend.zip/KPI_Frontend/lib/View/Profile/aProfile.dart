import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../Const/Constantino.dart';

class aProfile extends StatelessWidget {
  const aProfile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
        margin: EdgeInsets.all(10),
        shape: RoundedRectangleBorder(

          borderRadius: BorderRadius.circular(
              10.0), //<-- SEE HERE
        ),
        elevation: 10,
        color: Color(0XFFe1f396),
        child: Container(
        //  width: 500,
          margin: EdgeInsets.all(3),
          child: IntrinsicHeight(
            child: Column(


              children: [
                Container(
                  margin: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment
                        .spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('Домэйн',
                        style: TextStyle(color: Colors.white),),
                      SizedBox(height: 3,),
                      Card(
                        shape: RoundedRectangleBorder(

                          borderRadius: BorderRadius.circular(
                              7), //<-- SEE HERE
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Text('1244'),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment
                        .spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('Салбар',
                        style: TextStyle(color: Colors.white),),
                      SizedBox(height: 3,),
                      Card(
                        shape: RoundedRectangleBorder(

                          borderRadius: BorderRadius.circular(
                              7), //<-- SEE HERE
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Text('101'),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment
                        .spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('Ажилтан',
                        style: TextStyle(color: Colors.white),),
                      SizedBox(height: 3,),
                      Card(
                        shape: RoundedRectangleBorder(

                          borderRadius: BorderRadius.circular(
                              7), //<-- SEE HERE
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Text('Ц.Жаргалсүрэн'),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 10, right: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment
                        .spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('Албан тушаал',
                        style: TextStyle(color: Colors.white),),
                      SizedBox(height: 3,),
                      Card(
                        shape: RoundedRectangleBorder(

                          borderRadius: BorderRadius.circular(
                              7), //<-- SEE HERE
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Text('Бүсийн захирал'),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 10,),

              ],
            ),
          ),
        )
    );
  }
}
