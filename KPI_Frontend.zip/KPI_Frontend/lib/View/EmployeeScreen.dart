import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import '../Const/Constantino.dart';
import '../Controllr/kpiController.dart';
import '../Model/UserSession.dart';
import '../Model/YearMonth.dart';
import '../Model/kpiFieldsModel.dart';
import '../Model/kpiModel.dart';
import 'Comment/CommentView.dart';
import 'ScoreView/aScoreFactor.dart';

class EmployeeScreen extends StatefulWidget {
  List<YearMonth> lstYearMonth;
  UserSessionData userSessionData;

  EmployeeScreen({
    Key? key,
    required this.lstYearMonth,
    required this.userSessionData,
  }) : super(key: key);

  @override
  State<EmployeeScreen> createState() => _EmployeeScreenState();
}

class _EmployeeScreenState extends State<EmployeeScreen> {
  late YearMonth _selectedMenu;

  late Future _load;

  List<aScoreFactor> lst_aScoreFactor = [];
  late KpiModel kpiModel = tmpKpiModel;
  late KpiFieldsModel kpiFieldsModel = tmpKpiFieldsModel;
  late String kpiComment = "";
  bool isConfirmed = false;
  List<KpiModel> lstKpiModel = [];
  List<String> emposition = [];
  String employeePosition = "";
  double kpiAvrgeScore = 0;
  String kpi = "Тооцохгүй";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    if (widget.lstYearMonth.isNotEmpty && widget.lstYearMonth.length > 0) {
      for (var element in widget.lstYearMonth) {
        _selectedMenu = element; //widget.lstYearMonth.first;
        emposition.add(element.position.toString());

        _load = LoadData(_selectedMenu);
      }
    } else {
      _selectedMenu = tmpYearMonth;
      _load = LoadData(_selectedMenu);
    }
    if (emposition.length == 0) emposition.add("noPosition");
    employeePosition = emposition.first;

    setColumnwithScore();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: _load,
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.none:
              return const Text(
                "Press button to start.",
                style: TextStyle(color: Colors.red),
              );
            case ConnectionState.waiting:
              return const CircularProgressIndicator();
            default:
              if (snapshot.hasError)
                return Text(
                  "No Data found. Error:" + snapshot.error.toString(),
                  style: const TextStyle(color: Colors.red),
                );
              else {
                if (snapshot.hasData) {
                  String str = snapshot.data as String;
                  return myData94();
                } else
                  return const Text(
                      "You have no DATA ............................................................................... 2");
              }
          }
        });
  }

  Widget myData94() {
    return Align(
      key: UniqueKey(),
      alignment: Alignment.topCenter,
      child: Column(
        // mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            alignment: WrapAlignment.center,
            spacing: 10,
            runSpacing: 10,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Card(
                    margin: const EdgeInsets.all(10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0), //<-- SEE HERE
                    ),
                    elevation: 10,
                    color: Color.fromARGB(255, 109, 181, 229),
                    child: Container(
                      width: 150,
                      margin: const EdgeInsets.all(3),
                      child: IntrinsicHeight(
                        child: Wrap(
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Container(
                              margin: const EdgeInsets.all(10),
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.circular(7), //<-- SEE HERE
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: DropdownButton<String>(
                                    value: employeePosition,
                                    onChanged: (String? newValue) {
                                      setState(() {
                                        employeePosition = newValue!;
                                        for (var element
                                            in widget.lstYearMonth) {
                                          if (newValue ==
                                              element.position.toString()) {
                                            _selectedMenu = element;
                                            _load = LoadData(_selectedMenu);
                                          }
                                        }
                                      });
                                    },
                                    items: emposition
                                        .map<DropdownMenuItem<String>>(
                                            (String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Card(
                    margin: const EdgeInsets.all(10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0), //<-- SEE HERE
                    ),
                    elevation: 10,
                    color: Color.fromARGB(255, 109, 181, 229),
                    child: Container(
                      width: 100,
                      margin: const EdgeInsets.all(3),
                      child: IntrinsicHeight(
                        child: Wrap(
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Container(
                              margin: const EdgeInsets.all(10),
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.circular(7), //<-- SEE HERE
                                ),
                                child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Text((kpiModel.isConfirmed == "1" ||
                                            kpiModel.isConfirmedhub == "1")
                                        ? kpiModel.iskpi.toUpperCase()
                                        : "")),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Card(
                    margin: const EdgeInsets.all(10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0), //<-- SEE HERE
                    ),
                    elevation: 10,
                    color: Color.fromARGB(255, 109, 181, 229),
                    child: Container(
                      width: 100,
                      margin: const EdgeInsets.all(3),
                      child: IntrinsicHeight(
                        child: Wrap(
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Container(
                              margin: const EdgeInsets.all(10),
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.circular(7), //<-- SEE HERE
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: Text((kpiModel.isConfirmed == "1" ||
                                          kpiModel.isConfirmedhub == "1")
                                      ? (kpiModel.isConfirmed == "1")
                                          ? kpiModel.directorid
                                          : kpiModel.hubdirectorid
                                      : ""),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  CommentView(
                    userSessionData: widget.userSessionData,
                    lstKpiModel: lstKpiModel,
                    isConfirmed: isConfirmed,
                    fnRefresh: RefreshData,
                  ),
                  (isConfirmed)
                      ? Container(
                          width: 500,
                          child: Card(
                              color: Color(0XFF59ba89),
                              margin: EdgeInsets.all(10),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Гүйцэтгэлийн мэдээлэл БҮРЭН БАТАЛГААЖСАН байна.',
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 20),
                                ),
                              )),
                        )
                      : Text(''),
                ],
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.6,
                height: 140,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Card(
                      margin: const EdgeInsets.all(5),
                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(10.0), //<-- SEE HERE
                      ),
                      elevation: 10,
                      color: Color.fromARGB(255, 3, 154, 255),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'Төлөвлөгөө',
                            style:
                                TextStyle(color: Colors.grey, fontSize: 21.0),
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.15,
                            margin: const EdgeInsets.all(3),
                            child: IntrinsicHeight(
                              child: Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                children: [
                                  Card(
                                    elevation: 5,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          10.0), //<-- SEE HERE
                                    ),
                                    child: Container(
                                      margin: const EdgeInsets.all(10),
                                      child: const Column(
                                        children: [
                                          Text("100%",
                                              style: const TextStyle(
                                                  fontSize: 20,
                                                  color: Colors.black45,
                                                  fontWeight: FontWeight.bold))
                                        ],
                                      ),
                                    ),
                                  ),
                                  Card(
                                    elevation: 5,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          10.0), //<-- SEE HERE
                                    ),
                                    child: Container(
                                      margin: const EdgeInsets.all(10),
                                      child: const Column(
                                        children: [
                                          Text("Зорилт",
                                              style: const TextStyle(
                                                  fontSize: 20,
                                                  color: Colors.black45,
                                                  fontWeight: FontWeight.bold))
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 40),
                    Card(
                      margin: const EdgeInsets.all(5),
                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(10.0), //<-- SEE HERE
                      ),
                      elevation: 10,
                      color: Color.fromARGB(255, 3, 154, 255),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'Гүйцэтгэл',
                            style:
                                TextStyle(color: Colors.grey, fontSize: 21.0),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.15,
                            margin: const EdgeInsets.all(3),
                            child: IntrinsicHeight(
                              child: Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                children: [
                                  Card(
                                    elevation: 5,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          10.0), //<-- SEE HERE
                                    ),
                                    child: Container(
                                      margin: const EdgeInsets.all(10),
                                      child: Column(
                                        children: [
                                          Text(
                                              "$kpi", //kpi {kpiAvrgeScore.round()}
                                              style: const TextStyle(
                                                  fontSize: 20,
                                                  color: Colors.black45,
                                                  fontWeight: FontWeight.bold))
                                        ],
                                      ),
                                    ),
                                  ),
                                  Card(
                                    elevation: 5,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          10.0), //<-- SEE HERE
                                    ),
                                    child: Container(
                                      margin: const EdgeInsets.all(10),
                                      child: const Column(
                                        children: [
                                          Text("Дүн",
                                              style: const TextStyle(
                                                  fontSize: 20,
                                                  color: Colors.black45,
                                                  fontWeight: FontWeight.bold))
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width * 0.6,
                child: Column(
                  children: [
                    ListView.builder(
                      shrinkWrap: true,
                      itemCount: lst_aScoreFactor.length,
                      itemBuilder: (BuildContext context, int index) {
                        return lst_aScoreFactor[index];
                      },
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const SizedBox(
                          width: 5,
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.15,
                          margin: const EdgeInsets.all(3),
                          child: Card(
                            elevation: 5,
                            shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(10.0), //<-- SEE HERE
                            ),
                            child: Container(
                              margin: const EdgeInsets.all(10),
                              child: SizedBox(
                                width: 200,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    (kpiModel.commentbyemployee.trim().length >
                                            3)
                                        ? Tooltip(
                                            message: "Ажилтан тайлбар:\n" +
                                                kpiModel.commentbyemployee,
                                            child: Icon(Icons.message_outlined,
                                                color: Colors.orange),
                                          )
                                        : Text(''),
                                    (kpiModel.commentbydirector.trim().length >
                                            3)
                                        ? Tooltip(
                                            message: "Захирал тайлбар:\n" +
                                                kpiModel.commentbydirector,
                                            child: Icon(Icons.message_outlined,
                                                color: Colors.purpleAccent),
                                          )
                                        : Text(''),
                                    (kpiModel.commentbydirectorhub
                                                .trim()
                                                .length >
                                            3)
                                        ? Tooltip(
                                            message:
                                                "Бүсийн захирал тайлбар:\n" +
                                                    kpiModel
                                                        .commentbydirectorhub,
                                            child: Icon(Icons.message_outlined,
                                                color: Colors.tealAccent),
                                          )
                                        : Text(''),
                                    (kpiModel.commentbyallbrnmanager
                                                .trim()
                                                .length >
                                            3)
                                        ? Tooltip(
                                            message: "СУА тайлбар:\n" +
                                                kpiModel.commentbyallbrnmanager,
                                            child: Icon(Icons.message_outlined,
                                                color: Colors.cyan),
                                          )
                                        : Text(''),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  RefreshData(bool b) {
    if (b) {
      setState(() {
        _load = LoadData(_selectedMenu);
      });
    }
  }

  Future<String> LoadData(YearMonth _yearmonth) async {
    var rslt = await KpiController().GetKpiDetails(
        widget.userSessionData,
        _yearmonth.year.toString(),
        _yearmonth.month.toString(),
        _yearmonth.position.toString());

    if (rslt.responseCode.responseCode == ResponseValue.Success.value) {
      kpiModel = rslt.lstKpiModel.first;
      kpiFieldsModel = rslt.lstKpiFieldsModel.first;

      lstKpiModel = rslt.lstKpiModel;

      try {
        kpiComment = kpiModel.commentbyemployee;
      } catch (Exception) {
        kpiComment = "";
      }

      isConfirmed =
          (kpiModel.isConfirmed == "1" || kpiModel.isConfirmedhub == "1")
              ? true
              : false;

      setColumnwithScore();

      return "YES";
    } else {
      kpiModel = tmpKpiModel;
      kpiFieldsModel = tmpKpiFieldsModel;

      lst_aScoreFactor.clear();

      return "NO";
    }
  }

  setColumnwithScore() {
    lst_aScoreFactor.clear();
    if (kpiFieldsModel.col1.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber1_amount,
        FieldName: kpiFieldsModel.col1,
        Score: kpiModel.col1,
        ScoreDA: kpiModel.col1_amount,
      ));
    }
    if (kpiFieldsModel.col2.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber2.toDouble(),
        NumberPlan: kpiModel.scorenumber2_amount,
        FieldName: kpiFieldsModel.col2,
        Score: kpiModel.col2,
        ScoreDA: kpiModel.col2_amount,
      ));
    }
    if (kpiFieldsModel.col3.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber3.toDouble(),
        FieldName: kpiFieldsModel.col3,
        Score: kpiModel.col3,
        ScoreDA: kpiModel.col3_amount,
        NumberPlan: kpiModel.scorenumber3_amount,
      ));
    }
    if (kpiFieldsModel.col4.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber4.toDouble(),
        NumberPlan: kpiModel.scorenumber4_amount,
        FieldName: kpiFieldsModel.col4,
        Score: kpiModel.col4,
        ScoreDA: kpiModel.col4_amount,
      ));
    }
    if (kpiFieldsModel.col5.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber5.toDouble(),
        NumberPlan: kpiModel.scorenumber5_amount,
        FieldName: kpiFieldsModel.col5,
        Score: kpiModel.col5,
        ScoreDA: kpiModel.col5_amount,
      ));
    }
    if (kpiFieldsModel.col6.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber6.toDouble(),
        NumberPlan: kpiModel.scorenumber6_amount,
        FieldName: kpiFieldsModel.col6,
        Score: kpiModel.col6,
        ScoreDA: kpiModel.col6_amount,
      ));
    }
    if (kpiFieldsModel.col7.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber7.toDouble(),
        NumberPlan: kpiModel.scorenumber7_amount,
        FieldName: kpiFieldsModel.col7,
        Score: kpiModel.col7,
        ScoreDA: kpiModel.col7_amount,
      ));
    }
    if (kpiFieldsModel.col8.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber8.toDouble(),
        NumberPlan: kpiModel.scorenumber8_amount,
        FieldName: kpiFieldsModel.col8,
        Score: kpiModel.col8,
        ScoreDA: kpiModel.col8_amount,
      ));
    }
    if (kpiFieldsModel.col9.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber9.toDouble(),
        NumberPlan: kpiModel.scorenumber9_amount,
        FieldName: kpiFieldsModel.col9,
        Score: kpiModel.col9,
        ScoreDA: kpiModel.col9_amount,
      ));
    }
    if (kpiFieldsModel.col10.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber10.toDouble(),
        NumberPlan: kpiModel.scorenumber10_amount,
        FieldName: kpiFieldsModel.col10,
        Score: kpiModel.col10,
        ScoreDA: kpiModel.col10_amount,
      ));
    }
    if (kpiFieldsModel.col11.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber11_amount,
        FieldName: kpiFieldsModel.col11,
        Score: kpiModel.col11,
        ScoreDA: kpiModel.col11_amount,
      ));
    }
    if (kpiFieldsModel.col12.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber12_amount,
        FieldName: kpiFieldsModel.col12,
        Score: kpiModel.col12,
        ScoreDA: kpiModel.col12_amount,
      ));
    }
    if (kpiFieldsModel.col13.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber13_amount,
        FieldName: kpiFieldsModel.col13,
        Score: kpiModel.col13,
        ScoreDA: kpiModel.col13_amount,
      ));
    }
    if (kpiFieldsModel.col14.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber14_amount,
        FieldName: kpiFieldsModel.col14,
        Score: kpiModel.col14,
        ScoreDA: kpiModel.col14_amount,
      ));
    }
    if (kpiFieldsModel.col15.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber15_amount,
        FieldName: kpiFieldsModel.col15,
        Score: kpiModel.col15,
        ScoreDA: kpiModel.col15_amount,
      ));
    }
    if (kpiFieldsModel.col16.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber16_amount,
        FieldName: kpiFieldsModel.col16,
        Score: kpiModel.col16,
        ScoreDA: kpiModel.col16_amount,
      ));
    }
    if (kpiFieldsModel.col17.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber17_amount,
        FieldName: kpiFieldsModel.col17,
        Score: kpiModel.col17,
        ScoreDA: kpiModel.col17_amount,
      ));
    }
    if (kpiFieldsModel.col18.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber18_amount,
        FieldName: kpiFieldsModel.col18,
        Score: kpiModel.col18,
        ScoreDA: kpiModel.col18_amount,
      ));
    }
    if (kpiFieldsModel.col19.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber19_amount,
        FieldName: kpiFieldsModel.col19,
        Score: kpiModel.col19,
        ScoreDA: kpiModel.col19_amount,
      ));
    }
    if (kpiFieldsModel.col20.isNotEmpty && kpiFieldsModel.col1 != "") {
      lst_aScoreFactor.add(aScoreFactor(
        ScorePlan: kpiFieldsModel.scorenumber1.toDouble(),
        NumberPlan: kpiModel.scorenumber20_amount,
        FieldName: kpiFieldsModel.col20,
        Score: kpiModel.col20,
        ScoreDA: kpiModel.col20_amount,
      ));
    }

    lst_aScoreFactor.add(aScoreFactor(
      ScorePlan: 0.0,
      NumberPlan: 0.0,
      FieldName: 'Захиралын оноо',
      Score: (kpiModel.iskpi.toUpperCase() == "ТООЦНО" &&
              (kpiModel.isConfirmed == "1" || kpiModel.isConfirmedhub == "1"))
          ? kpiModel.isConfirmed == "1"
              ? kpiModel.scoredir
              : kpiModel.scorehubdir
          : 0.0,
      ScoreDA: 0.0,
    ));

    double tmpScore = 0;

    lst_aScoreFactor.forEach((element) {
      tmpScore += element.Score;
    });

    kpiAvrgeScore = tmpScore;
    if (kpiAvrgeScore >= 100) {
      kpiAvrgeScore = 100;
    }
    kpi = "$kpiAvrgeScore%";
    /*
    if (kpiModel.iskpi.toUpperCase() == "ТООЦНО") {
      if (kpiModel.isConfirmed == "1" || kpiModel.isConfirmedhub == "1") {
        kpi = kpiAvrgeScore.toString() + "%";
      }
    } else if (kpiModel.isConfirmed == "1" || kpiModel.isConfirmedhub == "1") {
      kpi = kpiModel.iskpi;
    } else {
      kpi = "-";
    }
    */
  }
}
