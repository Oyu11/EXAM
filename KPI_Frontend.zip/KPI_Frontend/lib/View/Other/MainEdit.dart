import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../Const/Constantino.dart';

class EditableDataTable extends StatefulWidget {
  BuildContext context;
  String brncode;
  String empname;
  String empcode;
  String empstatus;
  String field1;
  String field2;
  String field3;
  String field4;
  String field5;
  String field6;
  String field7;
  String field8;
  String field9;
  String field10;
  String field11;
  String field12;
  String field13;
  String field14;
  String field15;
  String field16;
  String field17;
  String field18;
  String field19;
  String field20;
  double val1;
  double val2;
  double val3;
  double val4;
  double val5;
  double val6;
  double val7;
  double val8;
  double val9;
  double val10;
  double val11;
  double val12;
  double val13;
  double val14;
  double val15;
  double val16;
  double val17;
  double val18;
  double val19;
  double val20;
  String isKpit;
  double scoredir;
  String employee_message;
  String director_message;
  String hubdirector_message;
  String isconfirm;
  final Function(String field, dynamic newValue) onValueChanged;

  EditableDataTable({
    Key? key,
    required this.context,
    required this.brncode,
    required this.empname,
    required this.empcode,
    required this.empstatus,
    required this.field1,
    required this.field2,
    required this.field3,
    required this.field4,
    required this.field5,
    required this.field6,
    required this.field7,
    required this.field8,
    required this.field9,
    required this.field10,
    required this.field11,
    required this.field12,
    required this.field13,
    required this.field14,
    required this.field15,
    required this.field16,
    required this.field17,
    required this.field18,
    required this.field19,
    required this.field20,
    required this.val1,
    required this.val2,
    required this.val3,
    required this.val4,
    required this.val5,
    required this.val6,
    required this.val7,
    required this.val8,
    required this.val9,
    required this.val10,
    required this.val11,
    required this.val12,
    required this.val13,
    required this.val14,
    required this.val15,
    required this.val16,
    required this.val17,
    required this.val18,
    required this.val19,
    required this.val20,
    required this.isKpit,
    required this.scoredir,
    required this.employee_message,
    required this.director_message,
    required this.hubdirector_message,
    required this.isconfirm,
    required this.onValueChanged,
  }) : super(key: key);

  @override
  _EditableDataTableState createState() => _EditableDataTableState();
}

class _EditableDataTableState extends State<EditableDataTable> {
  final controllor_brn = TextEditingController();
  final controller_empname = TextEditingController();
  final controller_field1 = TextEditingController();
  final controller_field2 = TextEditingController();
  final controller_field3 = TextEditingController();
  final controller_field4 = TextEditingController();
  final controller_field5 = TextEditingController();
  final controller_field6 = TextEditingController();
  final controller_field7 = TextEditingController();
  final controller_field8 = TextEditingController();
  final controller_field9 = TextEditingController();
  final controller_field10 = TextEditingController();
  final controller_field11 = TextEditingController();
  final controller_field12 = TextEditingController();
  final controller_field13 = TextEditingController();
  final controller_field14 = TextEditingController();
  final controller_field15 = TextEditingController();
  final controller_field16 = TextEditingController();
  final controller_field17 = TextEditingController();
  final controller_field18 = TextEditingController();
  final controller_field19 = TextEditingController();
  final controller_field20 = TextEditingController();
  final controller_empstatus = TextEditingController();
  final controller_empid = TextEditingController();
  final controller_value1 = TextEditingController();
  final controller_value2 = TextEditingController();
  final controller_value3 = TextEditingController();
  final controller_value4 = TextEditingController();
  final controller_value5 = TextEditingController();
  final controller_value6 = TextEditingController();
  final controller_directorscore = TextEditingController();
  final controller_kpi = TextEditingController();
  final controller_isConfirmed = TextEditingController();
  String dropdownvalue = '';
  @override
  void initState() {
    super.initState();
    controllor_brn.text = widget.brncode;
    controller_empname.text = widget.empname;
    controller_field1.text = widget.val1.toString();
    controller_field2.text = widget.val2.toString();
    controller_field3.text = widget.val3.toString();
    controller_field4.text = widget.val4.toString();
    controller_field5.text = widget.val5.toString();
    controller_field6.text = widget.val6.toString();
    controller_field7.text = widget.val7.toString();
    controller_field8.text = widget.val8.toString();
    controller_field9.text = widget.val9.toString();
    controller_field10.text = widget.val10.toString();
    controller_field11.text = widget.val11.toString();
    controller_field12.text = widget.val12.toString();
    controller_field13.text = widget.val13.toString();
    controller_field14.text = widget.val14.toString();
    controller_empstatus.text = widget.empstatus;
    controller_empid.text = widget.empcode;
    controller_value1.text = widget.val1.toString();
    controller_directorscore.text = widget.scoredir.toString();
    controller_kpi.text = widget.isKpit;
    controller_isConfirmed.text = widget.isconfirm;
    print("widget.isKpit");
    print(widget.isKpit);
    dropdownvalue = widget.isKpit;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Мэдээлэл шинэчлэх'),
      content: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: controllor_brn,
                decoration: const InputDecoration(
                  labelText: 'Салбар',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly,
                ],
              ),
              const SizedBox(height: 20),
              TextField(
                controller: controller_empname,
                decoration: const InputDecoration(
                  labelText: 'Ажилтан нэр',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: controller_empid,
                decoration: const InputDecoration(
                  labelText: 'Ажилтан код',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly,
                ],
              ),
              const SizedBox(height: 20),
              TextField(
                controller: controller_empstatus,
                decoration: const InputDecoration(
                  labelText: 'Cтатус',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              const Text("KPI:"),
              DropdownButton(
                value: dropdownvalue,
                icon: const Icon(Icons.keyboard_arrow_down),
                items: lstKpiRequired.map((String items) {
                  return DropdownMenuItem(
                    value: items,
                    child: Text(items),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    dropdownvalue = newValue!;
                  });
                },
              ),
              const SizedBox(height: 20),
              widget.field1.isNotEmpty
                  ? TextField(
                      controller: controller_field1,
                      decoration: InputDecoration(
                        labelText: widget.field1,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field1.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field2.isNotEmpty
                  ? TextField(
                      controller: controller_field2,
                      decoration: InputDecoration(
                        labelText: widget.field2,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field2.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field3.isNotEmpty
                  ? TextField(
                      controller: controller_field3,
                      decoration: InputDecoration(
                        labelText: widget.field3,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field3.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field4.isNotEmpty
                  ? TextField(
                      controller: controller_field4,
                      decoration: InputDecoration(
                        labelText: widget.field4,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field4.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field5.isNotEmpty
                  ? TextField(
                      controller: controller_field5,
                      decoration: InputDecoration(
                        labelText: widget.field5,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field5.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field6.isNotEmpty
                  ? TextField(
                      controller: controller_field6,
                      decoration: InputDecoration(
                        labelText: widget.field6,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field6.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field7.isNotEmpty
                  ? TextField(
                      controller: controller_field7,
                      decoration: InputDecoration(
                        labelText: widget.field7,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field7.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field8.isNotEmpty
                  ? TextField(
                      controller: controller_field8,
                      decoration: InputDecoration(
                        labelText: widget.field8,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field8.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field9.isNotEmpty
                  ? TextField(
                      controller: controller_field9,
                      decoration: InputDecoration(
                        labelText: widget.field9,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field9.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field10.isNotEmpty
                  ? TextField(
                      controller: controller_field10,
                      decoration: InputDecoration(
                        labelText: widget.field10,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field10.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field11.isNotEmpty
                  ? TextField(
                      controller: controller_field11,
                      decoration: InputDecoration(
                        labelText: widget.field11,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ],
                    )
                  : SizedBox(height: 1),
              widget.field11.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
              widget.field12.isNotEmpty
                  ? TextField(
                      controller: controller_field12,
                      decoration: InputDecoration(
                        labelText: widget.field12,
                        border: const OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.numberWithOptions(
                          signed: true, decimal: false),
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
                      ], /*
                      inputFormatters: <TextInputFormatter>[
                        FilteringTextInputFormatter.digitsOnly,
                      ],*/
                    )
                  : SizedBox(height: 1),
              widget.field12.isNotEmpty
                  ? SizedBox(height: 20)
                  : SizedBox(height: 1),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop(false);
          },
          child: Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            setState(() {
              widget.onValueChanged('brncode', controllor_brn.text);
              widget.onValueChanged('empname', controller_empname.text);
              widget.onValueChanged('status', controller_empstatus.text);
              widget.onValueChanged('id', controller_empid.text);
              widget.onValueChanged('iskpi', dropdownvalue);
              widget.onValueChanged('isconfirm', controller_isConfirmed.text);
              widget.onValueChanged(
                  'field1', double.parse(controller_field1.text));
              widget.onValueChanged(
                  'field2', double.parse(controller_field2.text));
              widget.onValueChanged(
                  'field3', double.parse(controller_field3.text));
              widget.onValueChanged(
                  'field4', double.parse(controller_field4.text));
              widget.onValueChanged(
                  'field5', double.parse(controller_field5.text));
              widget.onValueChanged(
                  'field6', double.parse(controller_field6.text));
              widget.onValueChanged(
                  'field7', double.parse(controller_field7.text));
              widget.onValueChanged(
                  'field8', double.parse(controller_field8.text));
              widget.onValueChanged(
                  'field9', double.parse(controller_field9.text));
              widget.onValueChanged(
                  'field10', double.parse(controller_field10.text));
            });
            Navigator.of(context).pop(true);
          },
          child: Text('Save'),
        ),
      ],
    );
  }

  @override
  void dispose() {
    controllor_brn.dispose();
    controller_empname.dispose();
    controller_empstatus.dispose();
    super.dispose();
  }
}
