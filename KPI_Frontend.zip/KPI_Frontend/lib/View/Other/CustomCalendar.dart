import 'package:flutter/material.dart';

class CustomCalendar extends StatefulWidget {
  final int yearSelected;
  final int monthSelected;
  final Function(int year, int month, bool flg) onDateChanged;

  CustomCalendar({
    required this.onDateChanged,
    required this.yearSelected,
    required this.monthSelected,
  });

  @override
  _CustomCalendarState createState() => _CustomCalendarState();
}

class _CustomCalendarState extends State<CustomCalendar> {
  late int currentYear;
  late int currentMonthIndex;

  final List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];

  @override
  void initState() {
    super.initState();
    currentYear = widget.yearSelected;
    currentMonthIndex = widget.monthSelected;
  }

  void _incrementYear() {
    setState(() {
      currentYear++;
      widget.onDateChanged(currentYear, currentMonthIndex + 1, true);
    });
  }

  void _decrementYear() {
    setState(() {
      currentYear--;
      widget.onDateChanged(currentYear, currentMonthIndex + 1, true);
    });
  }

  void _selectMonth(int index) {
    setState(() {
      currentMonthIndex = index;
      widget.onDateChanged(currentYear, currentMonthIndex + 1, true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300,
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFF13376b),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 5,
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '$currentYear оны',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_drop_up,
                          size: 30, color: Colors.white),
                      onPressed: _incrementYear,
                    ),
                    IconButton(
                      icon: Icon(Icons.arrow_drop_down,
                          size: 30, color: Colors.white),
                      onPressed: _decrementYear,
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              children: [
                for (int i = 0; i <= months.length; i += 3) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      for (int j = i; j < i + 3 && j < months.length; j++)
                        GestureDetector(
                          onTap: () => _selectMonth(j),
                          child: Text(
                            months[j],
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: (j) == currentMonthIndex
                                  ? Colors.teal
                                  : Colors.white,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ]
              ],
            ),
          ),
        ],
      ),
    );
  }
}
