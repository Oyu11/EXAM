import 'package:animated_flip_counter/animated_flip_counter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../ScoreView/ScoreView.dart';

class ScoreButton extends StatefulWidget {
  Function(double returnValue) fnGetValue;
  double valueOfScore;
  ScoreButton({Key? key, required this.valueOfScore, required this.fnGetValue})
      : super(key: key);

  @override
  State<ScoreButton> createState() => _ScoreButtonState();
}

class _ScoreButtonState extends State<ScoreButton> {
  // double _value = 0;
  double _sizeu = 20;

  late List<int> lst_IntValues = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    for (int i = 0; i <= 100; i = i + 10) {
      lst_IntValues.add(i);
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget _buildButton(num value) {
      return Row(
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                if (widget.valueOfScore > lst_IntValues.first) {
                  widget.valueOfScore -= value;

                  widget.fnGetValue(widget.valueOfScore);
                }
              });
            },
            child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.only(top: 3, bottom: 3),
                  child: Icon(
                    Icons.arrow_back_ios_sharp,
                    color: Colors.blueGrey,
                    size: _sizeu,
                  ),
                )),
          ),
          GestureDetector(
            child: Padding(
              padding: const EdgeInsets.only(left: 5, right: 5),
              child: AnimatedFlipCounter(
                value: widget.valueOfScore,
                duration: Duration(seconds: 2),
                padding: EdgeInsets.symmetric(vertical: 8),
                curve: Curves.elasticOut,
                textStyle: TextStyle(fontSize: _sizeu, color: Colors.pink),
              ),
            ),
            onTap: () async {
              double dskfjdslkf = await showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    insetPadding: EdgeInsets.symmetric(vertical: 0),
                    // contentPadding: EdgeInsets.zero,
                    title: Text('Оноо сонгон уу'),
                    content: Card(
                      elevation: 10,
                      child: Container(
                        margin: EdgeInsets.all(10),
                        child: aScoreSelection(
                          lst_intValue: lst_IntValues,
                          fnGetValue: (double dd) {
                            widget.valueOfScore = dd;
                          },
                          ScoreValue: widget.valueOfScore,
                        ),
                        height: 250,
                      ),
                    ),
                    actions: <Widget>[
                      ElevatedButton(
                        child: const Text("Continue"),
                        onPressed: () {
                          Navigator.of(context).pop(widget.valueOfScore);
                        },
                      ),
                      ElevatedButton(
                        child: const Text("Cancel"),
                        onPressed: () {
                          Navigator.of(context).pop(999);
                        },
                      )
                    ],
                  );
                },
              );

              if (dskfjdslkf.toString() != "999") {
                setState(() {
                  widget.valueOfScore = dskfjdslkf;
                  widget.fnGetValue(widget.valueOfScore);
                });
              }
            },
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                if (widget.valueOfScore < lst_IntValues.last) {
                  widget.valueOfScore += value;

                  widget.fnGetValue(widget.valueOfScore);
                }
              });
            },
            child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.only(top: 3, bottom: 3),
                  child: Icon(
                    Icons.arrow_forward_ios_sharp,
                    color: Colors.blueGrey,
                    size: _sizeu,
                  ),
                )),
          ),
        ],
      );
    }

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          SizedBox(
            width: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [1].map(_buildButton).toList(),
          ),
        ],
      ),
    );
  }
}

class aScoreSelection extends StatefulWidget {
  double ScoreValue;
  Function(double SelectedValue) fnGetValue;
  List<int> lst_intValue;
  aScoreSelection(
      {Key? key,
      required this.lst_intValue,
      required this.fnGetValue,
      required this.ScoreValue})
      : super(key: key);

  @override
  State<aScoreSelection> createState() => _aScoreSelectionState();
}

class _aScoreSelectionState extends State<aScoreSelection> {
  @override
  Widget build(BuildContext context) {
    Widget _buildButton(num value) {
      return Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 5, bottom: 5),
            child: FloatingActionButton(
              child: Text(
                '$value',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                setState(() {
                  widget.ScoreValue = value.toDouble();
                  widget.fnGetValue(widget.ScoreValue);
                });
              },
            ),
          ),
        ],
      );
    }

    return Center(
      child: SizedBox(
        height: 250,
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              AnimatedFlipCounter(
                value: widget.ScoreValue,
                duration: Duration(seconds: 2),
                padding: EdgeInsets.symmetric(vertical: 8),
                curve: Curves.elasticOut,
                textStyle: TextStyle(fontSize: 80, color: Colors.pink),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: widget.lst_intValue.map(_buildButton).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
