import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:kpi_empl/Const/Constantino.dart';
import 'package:kpi_empl/Model/UserSession.dart';

import '../../Model/kpiRole.dart';
import 'ScoreButton.dart';

class RoleView extends StatefulWidget {
  UserSessionData userSessionData;
  List<KpiRole> lstKpiRole;
  String role_name;
  RoleView(
      {Key? key,
      required this.lstKpiRole,
      required this.userSessionData,
      required this.role_name})
      : super(key: key);

  @override
  State<RoleView> createState() => _RoleViewState();
}

class _RoleViewState extends State<RoleView> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print('RoleView: ${widget.role_name}');
    print(widget.lstKpiRole.length);
    if (widget.lstKpiRole.length == 0 ||
        widget.role_name.toUpperCase() == 'БУСАД') {
      widget.lstKpiRole
          .add(KpiRole(Roles.Director.value, 0, 0, false, widget.role_name));
      widget.lstKpiRole
          .add(KpiRole(Roles.HubDirector.value, 0, 0, false, widget.role_name));
      widget.lstKpiRole.add(
          KpiRole(Roles.AllBranchManager.value, 0, 0, false, widget.role_name));
    }

    return Card(
        margin: const EdgeInsets.all(10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5.0), //<-- SEE HERE
        ),
        elevation: 10,
        child: (widget.lstKpiRole.length > 0)
            ? Container(
                width: 600,
                margin: EdgeInsets.all(5),
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Үзүүлэлтийн оноо тохируулах цэс',
                      style: TextStyle(
                          fontSize: 30,
                          color: Colors.blueGrey,
                          fontWeight: FontWeight.bold),
                    ),
                    Divider(thickness: 0.5, color: Colors.blueGrey),
                    Row(
                      children: [
                        Checkbox(
                          side: const BorderSide(
                              color: Colors.blueGrey, width: 1.5),
                          value: widget.lstKpiRole
                              .where((element) =>
                                  element.roleid == Roles.Director.value)
                              .first
                              .isCheck,
                          onChanged: (bool? value) {
                            setState(() {
                              widget.lstKpiRole
                                  .where((element) =>
                                      element.roleid == Roles.Director.value)
                                  .first
                                  .isCheck = value!;
                            });
                          },
                        ),
                        const SizedBox(
                          width: 300,
                          child: Align(
                            alignment: AlignmentDirectional.centerEnd,
                            child: Padding(
                              padding: EdgeInsets.only(right: 5),
                              child: Text(
                                'Захиралын оноо:',
                                style: TextStyle(
                                    fontSize: 20, color: Colors.blueGrey),
                              ),
                            ),
                          ),
                        ),
                        ScoreButton(
                          valueOfScore: widget.lstKpiRole
                              .where((element) =>
                                  element.roleid == Roles.Director.value)
                              .first
                              .scoremax,
                          fnGetValue: (double getSelectedValue) {
                            widget.lstKpiRole
                                .where((element) =>
                                    element.roleid == Roles.Director.value)
                                .first
                                .scoremax = getSelectedValue;
                          },
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Checkbox(
                          side: const BorderSide(
                              color: Colors.blueGrey, width: 1.5),
                          value: widget.lstKpiRole
                              .where((element) =>
                                  element.roleid == Roles.HubDirector.value)
                              .first
                              .isCheck,
                          onChanged: (bool? value) {
                            setState(() {
                              widget.lstKpiRole
                                  .where((element) =>
                                      element.roleid == Roles.HubDirector.value)
                                  .first
                                  .isCheck = value!;
                            });
                          },
                        ),
                        const SizedBox(
                          width: 300,
                          child: Align(
                            alignment: AlignmentDirectional.centerEnd,
                            child: Padding(
                              padding: EdgeInsets.only(right: 5),
                              child: Text(
                                'Бүсийн захиралын оноо:',
                                style: TextStyle(
                                    fontSize: 20, color: Colors.blueGrey),
                              ),
                            ),
                          ),
                        ),
                        ScoreButton(
                          valueOfScore: widget.lstKpiRole
                              .where((element) =>
                                  element.roleid == Roles.HubDirector.value)
                              .first
                              .scoremax,
                          fnGetValue: (double getSelectedValue) {
                            widget.lstKpiRole
                                .where((element) =>
                                    element.roleid == Roles.HubDirector.value)
                                .first
                                .scoremax = getSelectedValue;
                          },
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Checkbox(
                          side: const BorderSide(
                              color: Colors.blueGrey, width: 1.5),
                          value: widget.lstKpiRole
                              .where((element) =>
                                  element.roleid ==
                                  Roles.AllBranchManager.value)
                              .first
                              .isCheck,
                          onChanged: (bool? value) {
                            setState(() {
                              widget.lstKpiRole
                                  .where((element) =>
                                      element.roleid ==
                                      Roles.AllBranchManager.value)
                                  .first
                                  .isCheck = value!;
                            });
                          },
                        ),
                        const SizedBox(
                          width: 300,
                          child: Align(
                            alignment: AlignmentDirectional.centerEnd,
                            child: Padding(
                              padding: EdgeInsets.only(right: 5),
                              child: Text(
                                'СУА оноо:',
                                style: TextStyle(
                                    fontSize: 20, color: Colors.blueGrey),
                              ),
                            ),
                          ),
                        ),
                        ScoreButton(
                          valueOfScore: widget.lstKpiRole
                              .where((element) =>
                                  element.roleid ==
                                  Roles.AllBranchManager.value)
                              .first
                              .scoremax,
                          fnGetValue: (double getSelectedValue) {
                            widget.lstKpiRole
                                .where((element) =>
                                    element.roleid ==
                                    Roles.AllBranchManager.value)
                                .first
                                .scoremax = getSelectedValue;
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              )
            : Text("No found data is not here")

        /*Container(
              width: 600,
              margin: EdgeInsets.all(5),
              child: Column(
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    'Үзүүлэлтийн оноо тохируулах цэс',
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.blueGrey,
                        fontWeight: FontWeight.bold),
                  ),
                  Divider(thickness: 0.5, color: Colors.blueGrey),
                  Row(
                    children: [
                      Checkbox(
                        side: const BorderSide(
                            color: Colors.blueGrey, width: 1.5),
                        value: check_value_director,
                        onChanged: (bool? value) {
                          setState(() {
                            check_value_director = value!;
                          });
                        },
                      ),
                      const SizedBox(
                        width: 300,
                        child: Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: Padding(
                            padding: EdgeInsets.only(right: 5),
                            child: Text(
                              'Захиралын оноо:',
                              style: TextStyle(
                                  fontSize: 20, color: Colors.blueGrey),
                            ),
                          ),
                        ),
                      ),
                      ScoreButton(
                        valueOfScore: max_number_director,
                        fnGetValue: (double getSelectedValue) {
                          max_number_director = getSelectedValue;
                        },
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Checkbox(
                        side: const BorderSide(
                            color: Colors.blueGrey, width: 1.5),
                        value: check_value_hubdirector,
                        onChanged: (bool? value) {
                          setState(() {
                            check_value_hubdirector = value!;
                          });
                        },
                      ),
                      const SizedBox(
                        width: 300,
                        child: Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: Padding(
                            padding: EdgeInsets.only(right: 5),
                            child: Text(
                              'Бүсийн захиралын оноо:',
                              style: TextStyle(
                                  fontSize: 20, color: Colors.blueGrey),
                            ),
                          ),
                        ),
                      ),
                      ScoreButton(
                        valueOfScore: max_number_hubdirector,
                        fnGetValue: (double getSelectedValue) {
                          max_number_hubdirector = getSelectedValue;
                        },
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Checkbox(
                        side: const BorderSide(
                            color: Colors.blueGrey, width: 1.5),
                        value: check_value_allbranch,
                        onChanged: (bool? value) {
                          setState(() {
                            check_value_allbranch = value!;
                          });
                        },
                      ),
                      const SizedBox(
                        width: 300,
                        child: Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: Padding(
                            padding: EdgeInsets.only(right: 5),
                            child: Text(
                              'СУА оноо:',
                              style: TextStyle(
                                  fontSize: 20, color: Colors.blueGrey),
                            ),
                          ),
                        ),
                      ),
                      ScoreButton(
                        valueOfScore: max_number_allbranch,
                        fnGetValue: (double getSelectedValue) {
                          max_number_allbranch = getSelectedValue;
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),*/
        );
  }
}
