import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kpi_empl/Const/Constantino.dart';
import 'package:kpi_empl/Controllr/kpiController.dart';
import 'package:kpi_empl/Model/YearMonth.dart';
import 'package:kpi_empl/Model/kpiRole.dart';
import 'package:kpi_empl/View/Comment/myCommentText.dart';
import '../Model/UserSession.dart';
import '../Model/kpiFieldsModel.dart';
import '../Model/kpiModel.dart';
import '../Model/kpiModelTemp.dart';
import 'Comment/myDropDownButton.dart';
import 'Comment/myTextField.dart';
import 'ScoreView/ScoreSingleRow.dart';
import 'ScoreView/aScoreFactor.dart';

class ManagerScreen extends StatefulWidget {
  List<YearMonth> lstYearMonth;
  UserSessionData userSessionData;
  List<String> lstRoleList;

  ManagerScreen(
      {Key? key,
      required this.lstYearMonth,
      required this.userSessionData,
      required this.lstRoleList})
      : super(key: key);

  @override
  State<ManagerScreen> createState() => _MnagerScreenState();
}

double totalScoreOverAll = 0;

class _MnagerScreenState extends State<ManagerScreen> {
  bool isConfirmedByHubDir = false;
  bool isChecked = false;
  bool isCheckedConfirm = false;

  double allScoreValue = 0;
  List<int> lst_intValue = [];
  List<KpiRole> dataMapScore = [];
  late YearMonth _selectedMenu;

  DataTableSource MydataSource(List<KpiModel> lstTemp,
          KpiFieldsModel kpiFieldsModel, UserSessionData userSessionData) =>
      MyDataSourxe(
          RoleName: widget.userSessionData.rolename, // fnEdit: fnEdit_,
          lstKpiModel: lstTemp,
          KpiFieldsModel: kpiFieldsModel,
          lst_intvalues: lst_intValue,
          userSessionData: userSessionData,
          valueList: dataMapScore);

  final textController_Ajiltan_ = TextEditingController();
  final textController_zahiral_ = TextEditingController();
  final textController_buszahiral_ = TextEditingController();

  List<aScoreFactor> lst_aScoreFactor = [];

  late Future _load;
  late KpiFieldsModel aKpiFieldModel = KpiFieldsModel(
      0,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      0,
      0,
      "",
      "",
      "",
      "",
      "",
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0);
  late List<KpiModel> lstKpiModel_orginal = [];
  late List<KpiModel> lstKpiModel_temp = [];
  late List<KpiModelTemp> lstKpiModelTemp = [];
  List<String> lst_role = [];

  @override
  void initState() {
    totalScoreOverAll = 0;
    lstKpiModelTemp.clear();
    lstKpiModel_orginal.clear();
    super.initState();
    lst_role = widget.lstRoleList;
    for (int i = 0; i < lst_role.length; i++) {
      if (lst_role[i] == "Бусад") {
        lst_role.removeAt(i);
      }
    }

    lst_role.add("Бүгд");

    lstKpiModel_orginal.add(tmpKpiModel);
    if (widget.lstYearMonth.isNotEmpty) {
      for (var element in widget.lstYearMonth) {
        _selectedMenu = element;
        _load = LoadData(_selectedMenu);
      }
    } else {
      _selectedMenu = tmpYearMonth;
      _load = LoadData(_selectedMenu);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _load,
      builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
        switch (snapshot.connectionState) {
          case ConnectionState.none:
            return const Text(
              "Press button to start.",
              style: TextStyle(color: Colors.red),
            );
          case ConnectionState.waiting:
            return CircularProgressIndicator();
          default:
            if (snapshot.hasError)
              return Text(
                "No Data found. Error:" + snapshot.error.toString(),
                style: TextStyle(color: Colors.red),
              );
            else {
              if (snapshot.hasData) {
                String str = snapshot.data as String;
                if (str.toUpperCase() == "YES")
                  return myData64();
                else
                  return Text(
                    'Таны мэдээлэл ороогүй байна, СУА - д  мэдэгдэнэ үү',
                    style: TextStyle(fontSize: 50, color: Colors.purpleAccent),
                  );
              } else
                return Text(
                    "You have no DATA ............................................................................... 2");
            }
        }
      },
    );
  }

  List<DataColumn> lstColumn = [];
  addClmn(String str, Color color) {
    (str == "Захиралын оноо")
        ? lstColumn.add(DataColumn(
            label: SizedBox(
                width: 120,
                child: Text(
                  str,
                  style: TextStyle(color: color, fontSize: 14),
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                )),
          ))
        : (str == "Захирал")
            ? lstColumn.add(DataColumn(
                label: SizedBox(
                    width: 60,
                    child: Text(
                      str,
                      style: TextStyle(color: color, fontSize: 14),
                      textAlign: TextAlign.center,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    )),
              ))
            : lstColumn.add(DataColumn(
                label: SizedBox(
                    width: 80,
                    child: Text(
                      str,
                      style: TextStyle(color: color, fontSize: 14),
                      textAlign: TextAlign.center,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    )),
              ));
  }

  List<DataColumn> DataColumns() {
    lstColumn.clear();

    // addClmn('Салбар', Colors.lightBlue);
    //addClmn('Салбарын захирлын домэйн', Colors.lightBlue);
    //addClmn('Бүс', Colors.lightBlue);
    //addClmn('Бүсийн захирлын домэйн', Colors.lightBlue);
//    addClmn("Ажилтны домэйн", Colors.lightBlue);
    if (widget.userSessionData.rolename == Roles.HubDirector.value) {
      addClmn('Салбар', Colors.lightBlue);
    }

    addClmn("Ажилтны нэр", Colors.lightBlue);
    addClmn("Ажилтны код", Colors.lightBlue);
    // addClmn("Ажилтны албан тушаал", Colors.lightBlue);
    // addClmn("Ажилтны төлөв", Colors.lightBlue);

    if (aKpiFieldModel.col1.isNotEmpty)
      addClmn(aKpiFieldModel.col1, Colors.orangeAccent);
    if (aKpiFieldModel.col2.isNotEmpty)
      addClmn(aKpiFieldModel.col2, Colors.orangeAccent);
    if (aKpiFieldModel.col3.isNotEmpty)
      addClmn(aKpiFieldModel.col3, Colors.orangeAccent);
    if (aKpiFieldModel.col4.isNotEmpty)
      addClmn(aKpiFieldModel.col4, Colors.orangeAccent);
    if (aKpiFieldModel.col5.isNotEmpty)
      addClmn(aKpiFieldModel.col5, Colors.orangeAccent);
    if (aKpiFieldModel.col6.isNotEmpty)
      addClmn(aKpiFieldModel.col6, Colors.orangeAccent);
    if (aKpiFieldModel.col7.isNotEmpty)
      addClmn(aKpiFieldModel.col7, Colors.orangeAccent);
    if (aKpiFieldModel.col8.isNotEmpty)
      addClmn(aKpiFieldModel.col8, Colors.orangeAccent);
    if (aKpiFieldModel.col9.isNotEmpty)
      addClmn(aKpiFieldModel.col9, Colors.orangeAccent);
    if (aKpiFieldModel.col10.isNotEmpty)
      addClmn(aKpiFieldModel.col10, Colors.orangeAccent);
    if (aKpiFieldModel.col11.isNotEmpty)
      addClmn(aKpiFieldModel.col11, Colors.orangeAccent);
    if (aKpiFieldModel.col12.isNotEmpty)
      addClmn(aKpiFieldModel.col12, Colors.orangeAccent);
    if (aKpiFieldModel.col13.isNotEmpty)
      addClmn(aKpiFieldModel.col13, Colors.orangeAccent);
    if (aKpiFieldModel.col14.isNotEmpty)
      addClmn(aKpiFieldModel.col14, Colors.orangeAccent);
    if (aKpiFieldModel.col15.isNotEmpty)
      addClmn(aKpiFieldModel.col15, Colors.orangeAccent);
    if (aKpiFieldModel.col16.isNotEmpty)
      addClmn(aKpiFieldModel.col16, Colors.orangeAccent);
    if (aKpiFieldModel.col17.isNotEmpty)
      addClmn(aKpiFieldModel.col17, Colors.orangeAccent);
    if (aKpiFieldModel.col18.isNotEmpty)
      addClmn(aKpiFieldModel.col18, Colors.orangeAccent);
    if (aKpiFieldModel.col19.isNotEmpty)
      addClmn(aKpiFieldModel.col19, Colors.orangeAccent);
    if (aKpiFieldModel.col20.isNotEmpty)
      addClmn(aKpiFieldModel.col20, Colors.orangeAccent);

    if (widget.userSessionData.rolename != Roles.AllBranchManager.value) {
      addClmn("Оноо", Colors.lightBlue);
    }

    addClmn("Ажилтан тайлбар", Colors.redAccent);

    if (widget.userSessionData.rolename != Roles.Employee.value)
      addClmn("Захирал тайлбар", Colors.redAccent);

    if (widget.userSessionData.rolename == Roles.HubDirector.value ||
        widget.userSessionData.rolename == Roles.AllBranchManager.value)
      addClmn("Бүсийн Захирал тайлбар", Colors.redAccent);

    if (widget.userSessionData.rolename == Roles.AllBranchManager.value)
      addClmn("СУА тайлбар", Colors.redAccent);

    addClmn("KPI", Colors.redAccent);

    addClmn("Захирал оноо", Colors.redAccent);
    addClmn(
        widget.userSessionData.rolename == Roles.HubDirector.value
            ? "Батлах төлөв"
            : "Төлөв",
        Colors.redAccent);

    addClmn("Гүйцэтгэл", Colors.lightBlue);
    addClmn('Баталсан захирал', Colors.lightBlue);
    return lstColumn;
  }

  setColumnwithScore(List<KpiModel> templist) {
    double tmpScore = 0;
    double all_tmpScore = 0;
    int length = 0;

    for (int i = 0; i < templist.length; i++) {
      if (templist[i].iskpi.toUpperCase() == "ТООЦНО") {
        tmpScore = 0;
        tmpScore += templist[i].col1;
        tmpScore += templist[i].col2;
        tmpScore += templist[i].col3;
        tmpScore += templist[i].col4;
        tmpScore += templist[i].col5;
        tmpScore += templist[i].col6;
        tmpScore += templist[i].col7;
        tmpScore += templist[i].col8;
        tmpScore += templist[i].col9;
        tmpScore += templist[i].col10;

        tmpScore += templist[i].col11;
        tmpScore += templist[i].col12;
        tmpScore += templist[i].col13;
        tmpScore += templist[i].col14;
        tmpScore += templist[i].col15;
        tmpScore += templist[i].col16;
        tmpScore += templist[i].col17;
        tmpScore += templist[i].col18;
        tmpScore += templist[i].col19;
        tmpScore += templist[i].col20;
        tmpScore += templist[i].isConfirmed == "1" ? templist[i].scoredir : 0;
        tmpScore +=
            templist[i].isConfirmedhub == "1" ? templist[i].scorehubdir : 0;
        if (tmpScore > 100) {
          tmpScore = 100;
        }

        all_tmpScore += tmpScore;
        length++;
      }
    }

    totalScoreOverAll = (all_tmpScore / length);
    if (totalScoreOverAll.isNaN) {
      totalScoreOverAll = 0;
    }
  }

  Future<String> LoadData(YearMonth yearmonth) async {
    dropdownValue_kpi = null;
    dropdownValue_confirmDir = null;
    dropdownValue_confirmHub = null;
    textController_Ajiltan_.text = "";
    textController_zahiral_.text = "";
    textController_buszahiral_.text = "";
    lstKpiModelTemp.clear();

    var rslt = await KpiController().GetKpiDetails(
        widget.userSessionData,
        yearmonth.year.toString(),
        yearmonth.month.toString(),
        yearmonth.position.toString());

    if (rslt.responseCode.responseCode == ResponseValue.Success.value) {
      /*
      if (Roles.HubDirector.value == widget.userSessionData.rolename) {
        rslt.lstKpiModel = rslt.lstKpiModel
            .where((element) => element.isConfirmed == "2")
            .toList();
      }*/

      if (rslt.lstKpiModel.length > 0) {
        lstKpiModel_orginal = rslt.lstKpiModel;

        for (var element in rslt.lstKpiModel) {
          lstKpiModelTemp.add(KpiModelTemp(
              element.id,
              element.emplid,
              element.emplname,
              element.emplbrncode,
              element.emplposition,
              element.emplstatus,
              element.directorid,
              element.hubcode,
              element.hubdirectorid,
              element.scoreempl,
              element.scoredir,
              element.scorehubdir,
              element.scoretotal,
              element.effectiveyear,
              element.effectivemonth,
              element.col1,
              element.col2,
              element.col3,
              element.col4,
              element.col5,
              element.col6,
              element.col7,
              element.col8,
              element.col9,
              element.col10,
              element.col11,
              element.col12,
              element.col13,
              element.col14,
              element.col15,
              element.col16,
              element.col17,
              element.col18,
              element.col19,
              element.col20,
              element.col1_amount,
              element.col2_amount,
              element.col3_amount,
              element.col4_amount,
              element.col5_amount,
              element.col6_amount,
              element.col7_amount,
              element.col8_amount,
              element.col9_amount,
              element.col10_amount,
              element.col11_amount,
              element.col12_amount,
              element.col13_amount,
              element.col14_amount,
              element.col15_amount,
              element.col16_amount,
              element.col17_amount,
              element.col18_amount,
              element.col19_amount,
              element.col20_amount,
              element.scorenumber1_amount,
              element.scorenumber2_amount,
              element.scorenumber3_amount,
              element.scorenumber4_amount,
              element.scorenumber5_amount,
              element.scorenumber6_amount,
              element.scorenumber7_amount,
              element.scorenumber8_amount,
              element.scorenumber9_amount,
              element.scorenumber10_amount,
              element.scorenumber11_amount,
              element.scorenumber12_amount,
              element.scorenumber13_amount,
              element.scorenumber14_amount,
              element.scorenumber15_amount,
              element.scorenumber16_amount,
              element.scorenumber17_amount,
              element.scorenumber18_amount,
              element.scorenumber19_amount,
              element.scorenumber20_amount,
              element.createdt,
              element.createuser,
              element.modifieddt,
              element.modifieduser,
              element.isConfirmed,
              element.isConfirmedhub,
              element.iskpi,
              element.commentbyemployee,
              element.commentbydirector,
              element.commentbydirectorhub,
              element.commentbyallbrnmanager));
        }

        aKpiFieldModel = rslt.lstKpiFieldsModel.last; //Baganiin medeelel nemeh!
        //Buruu argaar code bichsen
        try {
          for (var element in lstKpiModelTemp) {
            bool roleFound = false;

            for (var elementd in dataMapScore) {
              if (elementd.roleName == element.emplposition) {
                roleFound = true;
                break;
              }
            }

            if (!roleFound) {
              var getData2 = await KpiController()
                  .GetScore(widget.userSessionData, element.emplposition);
              dataMapScore.addAll(getData2.lstRole);
            }
          }
        } catch (e) {
          print("Error: " + e.toString());
        }

        SearchKpiData();
        return "YES";
      } else {
        if (lstKpiModelTemp.length > 0) {
          return "YES";
        } else {
          lstKpiModel_orginal.clear();
          lstKpiModel_temp.clear();
          aKpiFieldModel = tmpKpiFieldsModel;
          return "NO";
        }
      }
    } else {
      lstKpiModel_orginal.clear();
      lstKpiModel_temp.clear();
      aKpiFieldModel = tmpKpiFieldsModel;
      return "NO";
    }
  }

  Widget myData64() {
    return Align(
      key: UniqueKey(),
      alignment: Alignment.topCenter,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            runAlignment: WrapAlignment.spaceBetween,
            spacing: 50,
            children: [
              SizedBox(
                width: 300,
                child: DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.search),
                  ),
                  hint: Text('Албан тушаал сонгох'),
                  items: lst_role.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList(),
                  value: dropdown_role,
                  onChanged: (String? valu) {
                    setState(() {
                      dropdown_role = valu!;
                      SearchKpiData();
                    });
                  },
                ),
              ),
              SizedBox(
                width: 200,
                child: DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                  ),
                  hint: Text('KPI'),
                  items:
                      lst_str_kpi.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList(),
                  value: dropdownValue_kpi,
                  onChanged: (String? valu) {
                    setState(() {
                      dropdownValue_kpi = valu!;
                      SearchKpiData();
                    });
                  },
                ),
              ),
              SizedBox(
                width: 350,
                child: DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.search),
                  ),
                  hint: Text('Төлөв'),
                  items: (widget.userSessionData.rolename ==
                              Roles.HubDirector.value
                          ? lst_str_allConfirm
                          : lst_str_isConfirm)
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList(),
                  value: dropdownValue_confirm,
                  onChanged: (String? valu) {
                    setState(() {
                      dropdownValue_confirm = valu!;

                      SearchKpiData();
                    });
                  },
                ),
              ),
              const SizedBox(width: 300),
              SizedBox(
                width: 100,
                child: ElevatedButton(
                  onPressed: () async {
                    String warningMsg = "";
                    List<KpiModel> tempLstKpi = [];
                    //lstKpiModel

                    lstKpiModel_orginal.forEach((element) {
                      KpiModelTemp tmpKpi = lstKpiModelTemp
                          .where((element2) => element2.id == element.id)
                          .toList()
                          .first;

                      if (element.isConfirmed == "2") {
                        element.scoredir = 0;
                      }
                      if (element.isConfirmed == "1") {
                        element.scorehubdir = 0;
                      }
                      if (element.toString() !=
                          tmpKpi
                              .toString()
                              .replaceAll("KpiModelTemp", "KpiModel")) {
                        if (widget.userSessionData.rolename ==
                            Roles.Director.value) {
                          if ((element.isConfirmed == "1" &&
                                  element.iskpi.isEmpty) ||
                              (element.iskpi.isNotEmpty &&
                                  element.isConfirmed == "0")) {
                            element.isConfirmed = "0";
                            element.iskpi = "";
                            var snackBar = const SnackBar(
                              content: Center(
                                  child: Text(
                                'Эцэслэх тохиолдолд kpi мөн сонгоно. !!',
                                style: TextStyle(
                                    color: Colors.orangeAccent, fontSize: 23),
                              )),
                              elevation: 10,
                              behavior: SnackBarBehavior.floating,
                            );
                            ScaffoldMessenger.of(context)
                                .showSnackBar(snackBar);
                          }
                          tempLstKpi.add(element);
                        } else if (widget.userSessionData.rolename ==
                            Roles.HubDirector.value) {
                          if (element.iskpi.isEmpty ||
                              element.isConfirmedhub.isEmpty ||
                              element.isConfirmedhub == "0") {
                            element.isConfirmedhub = "0";
                            element.iskpi = "";
                            var snackBar = const SnackBar(
                              content: Center(
                                  child: Text(
                                'Эцэслэх тохиолдолд kpi мөн сонгоно. !!',
                                style: TextStyle(
                                    color: Colors.orangeAccent, fontSize: 23),
                              )),
                              elevation: 10,
                              behavior: SnackBarBehavior.floating,
                            );
                            ScaffoldMessenger.of(context)
                                .showSnackBar(snackBar);
                          }
                          tempLstKpi.add(element);
                        }
                      }
                    });

                    if (tempLstKpi.length == 0) {
                      var snackBar = SnackBar(
                        content: Center(
                            child: Text(
                          'Мэдээлэлд өөрчлөлт оруулаагүй байна !!',
                          style: TextStyle(
                              color: Colors.orangeAccent, fontSize: 23),
                        )),
                        elevation: 10,
                        behavior: SnackBarBehavior.floating,
                      );
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);
                    } else {
                      warningMsg =
                          "Та  мэдээлэлд өөрчлөлт оруулах гэж байна (" +
                              tempLstKpi.length.toString() +
                              ")";

                      var returnValue = await showDialog<String>(
                        context: context,
                        barrierDismissible: false, // user must tap button!
                        builder: (BuildContext context) {
                          return AlertDialog(
                            // <-- SEE HERE
                            title: const Text('Анхааруулга'),
                            content: SingleChildScrollView(
                              child: ListBody(
                                children: <Widget>[
                                  Text(warningMsg),
                                ],
                              ),
                            ),
                            actions: <Widget>[
                              TextButton(
                                child: const Text('Үгүй'),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              ),
                              TextButton(
                                child: const Text('Тийм'),
                                onPressed: () {
                                  Navigator.of(context).pop('Yes');
                                },
                              ),
                            ],
                          );
                        },
                      );

                      if (returnValue == 'Yes') {
                        var rslt = await KpiController()
                            .SaveKpiDetails(widget.userSessionData, tempLstKpi);

                        if (rslt.responseCode == ResponseValue.Success.value) {
                          var snackBar = const SnackBar(
                            content: Center(
                                child: Text(
                              'Мэдээллийг амжилттай хадгаллаа',
                              style:
                                  TextStyle(color: Colors.white, fontSize: 15),
                            )),
                            elevation: 10,
                            behavior: SnackBarBehavior.floating,
                            backgroundColor: Colors.green,
                          );
                          ScaffoldMessenger.of(context).showSnackBar(snackBar);

                          setState(() {
                            totalScoreOverAll = 0;

                            if (widget.lstYearMonth.isNotEmpty) {
                              for (var element in widget.lstYearMonth) {
                                _selectedMenu = element;
                                _load = LoadData(_selectedMenu);
                              }
                            } else {
                              _selectedMenu = tmpYearMonth;
                              _load = LoadData(_selectedMenu);
                            }
                          });
                        } else {
                          var snackBar = SnackBar(
                            content: Center(
                                child: Text(
                              'Мэдээллийг хадгалахад алдаа гарлаа:' +
                                  rslt.actualCode,
                              style: TextStyle(color: Colors.red, fontSize: 23),
                            )),
                            elevation: 10,
                            behavior: SnackBarBehavior.floating,
                          );
                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                        }
                      }
                    }
                  },
                  child: Text('Save'),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 700,
              children: [
                Card(
                    margin: EdgeInsets.all(10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0), //<-- SEE HERE
                    ),
                    elevation: 10,
                    color: Color(0XFFe1f396),
                    child: Container(
                      width: 100,
                      margin: EdgeInsets.all(3),
                      child: IntrinsicHeight(
                        child: Wrap(
                          crossAxisAlignment: WrapCrossAlignment.start,
                          children: [
                            Card(
                              elevation: 5,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(10.0), //<-- SEE HERE
                              ),
                              child: Container(
                                margin: EdgeInsets.all(5),
                                child: Column(
                                  children: [
                                    Text(
                                      'Гүйцэтгэл',
                                      style: TextStyle(color: Colors.grey),
                                    ),
                                    Text("${totalScoreOverAll.round()}%",
                                        style: TextStyle(
                                            fontSize: 20,
                                            color: Colors.black45,
                                            fontWeight: FontWeight.bold))
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )),
                Wrap(
                  alignment: WrapAlignment.end,
                  runAlignment: WrapAlignment.spaceBetween,
                  crossAxisAlignment: WrapCrossAlignment.end,
                  spacing: 50,
                  children: [
                    (widget.userSessionData.rolename != Roles.Employee.value &&
                            widget.userSessionData.rolename !=
                                Roles.AllBranchManager.value)
                        ? Container(
                            margin: EdgeInsets.only(left: 20),
                            width: 380,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 30,
                                  height: 30,
                                  child: Checkbox(
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                    value: isChecked,
                                    onChanged: (bool? update) {
                                      setState(() => isChecked = update!);
                                      //widget.userSessionData.scoremax
                                      //Const 50 hurtelh bugd uchraas ali rule ee dagahaa medehgui baina.
                                      for (int i = 0; i <= 50; i++) {
                                        lst_intValue.add(i);
                                      }
                                    },
                                  ),
                                ),
                                Text('Бүгдийг сонгох (Захиралын оноо)'),
                                (isChecked)
                                    ? ScoreSingleRow(
                                        fnEdit: fnEdit22,
                                        valueOfScore: allScoreValue,
                                        lst_IntValues: lst_intValue,
                                        isConfirmed: false,
                                      )
                                    : Text('')
                              ],
                            ),
                          )
                        : Container(),
                    SizedBox(
                      width: 200,
                      child: Row(
                        children: [
                          Expanded(
                            flex: 9,
                            child: TextFormField(
                              controller: textController_Ajiltan_,
                              onFieldSubmitted: (val) {
                                SearchKpiData();
                              },
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.search),
                                contentPadding:
                                    new EdgeInsets.fromLTRB(10, 10, 10, 10),
                                isDense: true,
                                border: const OutlineInputBorder(),
                                labelText: 'Хайлт',
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Tooltip(
                                message: 'Хайх утгаа оруулаад, Enter дарна уу!',
                                child: Icon(
                                  Icons.wb_incandescent,
                                  color: Colors.orange,
                                  size: 18,
                                )),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.all(30),
            child: ListView(
              shrinkWrap: true,
              // padding: const EdgeInsets.all(5),
              children: [
                PaginatedDataTable(
                  showFirstLastButtons: true,
                  headingRowHeight: 60,
                  arrowHeadColor: Colors.blueGrey,
                  showCheckboxColumn: false,
                  columnSpacing: 1.0,
                  //  header: Text('Header Text'),
                  rowsPerPage: lstKpiModel_orginal.length,
                  columns: DataColumns(),
                  source: MydataSource(lstKpiModel_orginal, aKpiFieldModel,
                      widget.userSessionData),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  fnEdit22(double dValue) {
    allScoreValue = dValue;

    for (int j = 0; j < lstKpiModel_orginal.length; j++) {
      if (lstKpiModel_orginal[j].isConfirmed != "1" &&
          lstKpiModel_orginal[j].isConfirmedhub != "1") {
        if (widget.userSessionData.rolename == Roles.Director.value) {
          if (lstKpiModel_orginal[j].isConfirmed ==
              "0") //Эцэслэх болон Бүсрүү явуулахаас өмнө оноогоо өгөх
            lstKpiModel_orginal[j].scoredir = allScoreValue;
        } else if (widget.userSessionData.rolename == Roles.HubDirector.value) {
          if (lstKpiModel_orginal[j].isConfirmedhub == "0")
            lstKpiModel_orginal[j].scorehubdir = allScoreValue;
        }
      }
    }
    setState(() {});
  }

  String GetDataFromdropDownSelectedItem(
      String? dropdownValue_kpi, FilterValue val) {
    /* ["KPI: Тооцно","KPI: Тооцохгүй","KPI: Тооцно-Тооцохгүй"]
    *  ["Захирал: Баталсан","Захирал: Батлаагүй","Захирал: Бүгд"] ; OLD NOT USE
    *  ["Бүс захирал: Баталсан","Бүс захирал: Батлаагүй","Бүс захирал: Бүгд"] ; OLD NOT USE
    *  ["Төлөв" : "Эцэслэх", "Бүсийн захиралд илгээх"]
    * */

    if (val == FilterValue.Filter_KPI) {
      if (dropdownValue_kpi == "KPI: Тооцно")
        return "Тооцно";
      else if (dropdownValue_kpi == "KPI: Тооцохгүй")
        return "Тооцохгүй";
      else
        return "";
    } else if (val == FilterValue.Filter_Confirm_byDir) {
      if (dropdownValue_kpi == "Эцэслэх")
        return "0";
      else if (dropdownValue_kpi == "Баталсан")
        return "1";
      else if (dropdownValue_kpi == "Бүсийн захиралд илгээх")
        return "2";
      else
        return "";
    } else if (val == FilterValue.Filter_Confirm_byHubDir) {
      if (dropdownValue_kpi == "Баталсан")
        return "1";
      else if (dropdownValue_kpi == "Хүлээгдэж буй")
        return "0";
      else
        return "";
    } else
      return "";
  }

  void SearchKpiData() {
    String tmpKpiSelectedValue = GetDataFromdropDownSelectedItem(
        dropdownValue_kpi, FilterValue.Filter_KPI);
    String tmpConfirmHubDirSelectedValue = GetDataFromdropDownSelectedItem(
        dropdownValue_confirm, FilterValue.Filter_Confirm_byHubDir);
    String tmpConfirmDirSelectedValue = GetDataFromdropDownSelectedItem(
        dropdownValue_confirm, FilterValue.Filter_Confirm_byDir);
    String emplText = textController_Ajiltan_.text.trim().toLowerCase();

    setState(() {
      List<KpiModelTemp> kpiModelTempSearch = lstKpiModelTemp.where((e) {
        bool kpiMatch =
            tmpKpiSelectedValue.isEmpty ? true : e.iskpi == tmpKpiSelectedValue;
        bool confirmDirMatch = tmpConfirmDirSelectedValue.isEmpty
            ? true
            : tmpConfirmDirSelectedValue == "1"
                ? (e.isConfirmed == "1" || e.isConfirmedhub == "1")
                : tmpConfirmDirSelectedValue == "2"
                    ? (e.isConfirmed == tmpConfirmDirSelectedValue &&
                        e.isConfirmedhub != "1")
                    : (e.isConfirmed == "0" && e.isConfirmedhub == "0");
        bool confirmHubDirMatch = tmpConfirmHubDirSelectedValue.isEmpty
            ? true
            : tmpConfirmHubDirSelectedValue == "1"
                ? (e.isConfirmed == "1" || e.isConfirmedhub == "1")
                : (e.isConfirmed != "1" &&
                    e.isConfirmedhub !=
                        "1"); //e.isConfirmedhub == tmpConfirmHubDirSelectedValue;
        bool emplMatch = emplText.isEmpty
            ? true
            : (e.emplname.toLowerCase().contains(emplText) ||
                e.emplstatus.toLowerCase().contains(emplText) ||
                e.emplbrncode.toLowerCase().contains(emplText) ||
                e.emplid.toLowerCase().contains(emplText) ||
                (e.directorid.toLowerCase().contains(emplText)) ||
                e.scorehubdir.toString().toLowerCase().contains(emplText));
        bool roleMatch =
            dropdown_role == null || dropdown_role!.toLowerCase() == "бүгд"
                ? true
                : e.emplposition
                    .toLowerCase()
                    .contains(dropdown_role!.toLowerCase());

        return kpiMatch &&
            confirmDirMatch &&
            confirmHubDirMatch &&
            emplMatch &&
            roleMatch;
      }).toList();

      if (kpiModelTempSearch.isEmpty) {
        kpiModelTempSearch.add(tmpKpiModelTemp);
      }

      lstKpiModel_orginal = ConvertData(kpiModelTempSearch);
      setColumnwithScore(lstKpiModel_orginal);
    });
  }

  KpiModel ConvertDataSingle(KpiModelTemp element) {
    KpiModel tmpResult = KpiModel(
        element.id,
        element.emplid,
        element.emplname,
        element.emplbrncode,
        element.emplposition,
        element.emplstatus,
        element.directorid,
        element.hubcode,
        element.hubdirectorid,
        element.scoreempl,
        element.scoredir,
        element.scorehubdir,
        element.scoretotal,
        element.effectiveyear,
        element.effectivemonth,
        element.col1,
        element.col2,
        element.col3,
        element.col4,
        element.col5,
        element.col6,
        element.col7,
        element.col8,
        element.col9,
        element.col10,
        element.col11,
        element.col12,
        element.col13,
        element.col14,
        element.col15,
        element.col16,
        element.col17,
        element.col18,
        element.col19,
        element.col20,
        element.col1_amount,
        element.col2_amount,
        element.col3_amount,
        element.col4_amount,
        element.col5_amount,
        element.col6_amount,
        element.col7_amount,
        element.col8_amount,
        element.col9_amount,
        element.col10_amount,
        element.col11_amount,
        element.col12_amount,
        element.col13_amount,
        element.col14_amount,
        element.col15_amount,
        element.col16_amount,
        element.col17_amount,
        element.col18_amount,
        element.col19_amount,
        element.col20_amount,
        element.scorenumber1_amount,
        element.scorenumber2_amount,
        element.scorenumber3_amount,
        element.scorenumber4_amount,
        element.scorenumber5_amount,
        element.scorenumber6_amount,
        element.scorenumber7_amount,
        element.scorenumber8_amount,
        element.scorenumber9_amount,
        element.scorenumber10_amount,
        element.scorenumber11_amount,
        element.scorenumber12_amount,
        element.scorenumber13_amount,
        element.scorenumber14_amount,
        element.scorenumber15_amount,
        element.scorenumber16_amount,
        element.scorenumber17_amount,
        element.scorenumber18_amount,
        element.scorenumber19_amount,
        element.scorenumber20_amount,
        element.createdt,
        element.createuser,
        element.modifieddt,
        element.modifieduser,
        element.isConfirmed,
        element.isConfirmedhub,
        element.iskpi,
        element.commentbyemployee,
        element.commentbydirector,
        element.commentbydirectorhub,
        element.commentbyallbrnmanager);

    return tmpResult;
  }

  List<KpiModel> ConvertData(List<KpiModelTemp> lstKpiModelTemp) {
    List<KpiModel> tmpResult = [];

    for (var element in lstKpiModelTemp) {
      tmpResult.add(KpiModel(
          element.id,
          element.emplid,
          element.emplname,
          element.emplbrncode,
          element.emplposition,
          element.emplstatus,
          element.directorid,
          element.hubcode,
          element.hubdirectorid,
          element.scoreempl,
          element.scoredir,
          element.scorehubdir,
          element.scoretotal,
          element.effectiveyear,
          element.effectivemonth,
          element.col1,
          element.col2,
          element.col3,
          element.col4,
          element.col5,
          element.col6,
          element.col7,
          element.col8,
          element.col9,
          element.col10,
          element.col11,
          element.col12,
          element.col13,
          element.col14,
          element.col15,
          element.col16,
          element.col17,
          element.col18,
          element.col19,
          element.col20,
          element.col1_amount,
          element.col2_amount,
          element.col3_amount,
          element.col4_amount,
          element.col5_amount,
          element.col6_amount,
          element.col7_amount,
          element.col8_amount,
          element.col9_amount,
          element.col10_amount,
          element.col11_amount,
          element.col12_amount,
          element.col13_amount,
          element.col14_amount,
          element.col15_amount,
          element.col16_amount,
          element.col17_amount,
          element.col18_amount,
          element.col19_amount,
          element.col20_amount,
          element.scorenumber1_amount,
          element.scorenumber2_amount,
          element.scorenumber3_amount,
          element.scorenumber4_amount,
          element.scorenumber5_amount,
          element.scorenumber6_amount,
          element.scorenumber7_amount,
          element.scorenumber8_amount,
          element.scorenumber9_amount,
          element.scorenumber10_amount,
          element.scorenumber11_amount,
          element.scorenumber12_amount,
          element.scorenumber13_amount,
          element.scorenumber14_amount,
          element.scorenumber15_amount,
          element.scorenumber16_amount,
          element.scorenumber17_amount,
          element.scorenumber18_amount,
          element.scorenumber19_amount,
          element.scorenumber20_amount,
          element.createdt,
          element.createuser,
          element.modifieddt,
          element.modifieduser,
          element.isConfirmed,
          element.isConfirmedhub,
          element.iskpi,
          element.commentbyemployee,
          element.commentbydirector,
          element.commentbydirectorhub,
          element.commentbyallbrnmanager));
    }

    return tmpResult;
  }
}

class MyDataSourxe extends DataTableSource {
  bool isTicked = false;
  List<int> lst_intvalues;

  final List<KpiModel> lstKpiModel;
  final KpiFieldsModel;
  String RoleName;
  double _width = 80;
  UserSessionData userSessionData;
  String total_single = "";
  List<KpiRole> valueList = [];

  MyDataSourxe(
      {required this.RoleName,
      required this.lstKpiModel,
      required this.KpiFieldsModel,
      required this.lst_intvalues,
      required this.userSessionData,
      required this.valueList});

  List<bool> lst_isSelected = [];

  DataCell addRow(String str, int index, double _with) {
    String tmp = "0";
    if (str.trim() == "") str = tmp;

    return DataCell(
      SizedBox(
        width: _with,
        child: Text(
          str,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  @override
  bool get isRowCountApproximate => false;
  @override
  int get rowCount => lstKpiModel.length;
  @override
  int get selectedRowCount => 0;

  @override
  DataRow getRow(int index) {
    return DataRow(cells: getDataRowList(index));
  }

  String getTotalScore(int index) {
    double totalScore = 0;

    totalScore += lstKpiModel[index].col1;
    totalScore += lstKpiModel[index].col2;
    totalScore += lstKpiModel[index].col3;
    totalScore += lstKpiModel[index].col4;
    totalScore += lstKpiModel[index].col5;
    totalScore += lstKpiModel[index].col6;
    totalScore += lstKpiModel[index].col7;
    totalScore += lstKpiModel[index].col8;
    totalScore += lstKpiModel[index].col9;
    totalScore += lstKpiModel[index].col10;

    totalScore += lstKpiModel[index].col11;
    totalScore += lstKpiModel[index].col12;
    totalScore += lstKpiModel[index].col13;
    totalScore += lstKpiModel[index].col14;
    totalScore += lstKpiModel[index].col15;
    totalScore += lstKpiModel[index].col16;
    totalScore += lstKpiModel[index].col17;
    totalScore += lstKpiModel[index].col18;
    totalScore += lstKpiModel[index].col19;
    totalScore += lstKpiModel[index].col20;

    totalScore +=
        lstKpiModel[index].isConfirmed == "2" ? 0 : lstKpiModel[index].scoredir;
    totalScore += lstKpiModel[index].scorehubdir;

    if (totalScore > 100) {
      totalScore = 100;
    }

    return totalScore.round().toString();
  }

  //Add this section 2024.08.21 value ajiltnii roll-oos hamaarch taaz onoo ni hyzgaarlagdana.
  List<int> getValue(String positionName) {
    List<int> lst_intValue = [];
    valueList.forEach((element) {
      if (element.roleName == positionName) {
        for (int i = 0; i <= element.scoremax; i++) {
          lst_intValue.add(i);
        }
      }
    });
    return lst_intValue;
  }

  bool getBoolCheck(String positionName, String isConfirmed, String role_name) {
    bool isCheck = false;
    valueList.forEach((element) {
      if (element.roleName == positionName) {
        isCheck = !element.isCheck;
      }
    });
    if (isCheck == false) {
      isCheck = getBoolValue(isConfirmed, role_name);
    }
    return isCheck;
  }

  String getTotalScoreWithoutDirector(int index) {
    double totalScore = 0;

    totalScore += lstKpiModel[index].col1;
    totalScore += lstKpiModel[index].col2;
    totalScore += lstKpiModel[index].col3;
    totalScore += lstKpiModel[index].col4;
    totalScore += lstKpiModel[index].col5;
    totalScore += lstKpiModel[index].col6;
    totalScore += lstKpiModel[index].col7;
    totalScore += lstKpiModel[index].col8;
    totalScore += lstKpiModel[index].col9;
    totalScore += lstKpiModel[index].col10;

    totalScore += lstKpiModel[index].col11;
    totalScore += lstKpiModel[index].col12;
    totalScore += lstKpiModel[index].col13;
    totalScore += lstKpiModel[index].col14;
    totalScore += lstKpiModel[index].col15;
    totalScore += lstKpiModel[index].col16;
    totalScore += lstKpiModel[index].col17;
    totalScore += lstKpiModel[index].col18;
    totalScore += lstKpiModel[index].col19;
    totalScore += lstKpiModel[index].col20;

    if (totalScore > 100) {
      totalScore = 100;
    }

    return totalScore.round().toString();
  }

  bool getBoolValue(String isConfirmedhub, String role_name) {
    //true edit hiih close
    //false edit hiih bolomjtoi

    if (role_name == Roles.Director.value) {
      if (isConfirmedhub == "2" || isConfirmedhub == "1") {
        return true;
      }
    } else if (role_name == Roles.HubDirector.value) {
      if (isConfirmedhub == "1") {
        return true;
      }
    }

    return false;
  }

  List<DataCell> getDataRowList(int index) {
    List<DataCell> lstTemp = [];
    total_single = getTotalScore(index);

    if (userSessionData.rolename == Roles.AllBranchManager.value) {
      lstTemp.add(
        DataCell(
          SizedBox(
            width: _width + 20,
            child: myCommentText(
              commentStr: lstKpiModel[index].emplname,
              isDirectorConfirmed: false,
              isHubDirectorConfirmed: false,
              RoleName: userSessionData.rolename,
              fnComment: (String commstr) {
                lstKpiModel[index].emplname = commstr;
              },
              purposedRole: Roles.AllBranchManager,
            ),
          ),
        ),
      );
      lstTemp.add(
        DataCell(
          SizedBox(
            width: _width + 20,
            child: myCommentText(
              commentStr: lstKpiModel[index].emplid,
              isDirectorConfirmed: false,
              isHubDirectorConfirmed: false,
              RoleName: userSessionData.rolename,
              fnComment: (String commstr) {
                lstKpiModel[index].emplid = commstr;
              },
              purposedRole: Roles.AllBranchManager,
            ),
          ),
        ),
      );
      if (KpiFieldsModel.col1.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col1 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col1.toString()))));
      if (KpiFieldsModel.col2.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col2 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col2.toString()))));
      if (KpiFieldsModel.col3.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col3 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col3.toString()))));
      if (KpiFieldsModel.col4.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col4 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col4.toString()))));

      if (KpiFieldsModel.col5.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col5 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col5.toString()))));
      if (KpiFieldsModel.col6.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col6 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col6.toString()))));
      if (KpiFieldsModel.col7.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col7 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col7.toString()))));
      if (KpiFieldsModel.col8.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col8 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col8.toString()))));
      if (KpiFieldsModel.col9.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col9 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col9.toString()))));
      if (KpiFieldsModel.col10.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col10 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col10.toString()))));
      if (KpiFieldsModel.col11.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col11 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col11.toString()))));
      if (KpiFieldsModel.col12.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col12 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col12.toString()))));
      if (KpiFieldsModel.col13.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col13 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col13.toString()))));
      if (KpiFieldsModel.col14.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col14 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col14.toString()))));
      if (KpiFieldsModel.col15.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col15 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col15.toString()))));
      if (KpiFieldsModel.col16.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col16 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col6.toString()))));
      if (KpiFieldsModel.col17.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col17 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col17.toString()))));
      if (KpiFieldsModel.col18.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col18 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col18.toString()))));
      if (KpiFieldsModel.col19.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col19 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col19.toString()))));
      if (KpiFieldsModel.col20.isNotEmpty)
        lstTemp.add(DataCell(SizedBox(
            width: _width,
            child: myTextFields(
                fnText: (String str) {
                  lstKpiModel[index].col20 = str2double(str);
                },
                valuetStr: lstKpiModel[index].col20.toString()))));
    } else {
      if (userSessionData.rolename == Roles.HubDirector.value) {
        lstTemp.add(
          DataCell(
            SizedBox(
              width: 80,
              child: Text(lstKpiModel[index].emplbrncode,
                  textAlign: TextAlign.center),
            ),
          ),
        );
      }

      lstTemp.add(
        DataCell(
          SizedBox(
            width: _width + 30,
            child: Tooltip(
              message: lstKpiModel[index].emplname,
              child: Chip(
                label: Text(
                  lstKpiModel[index].emplname.toUpperCase(),
                  style: TextStyle(color: Colors.white),
                ),
                backgroundColor:
                    Colors.primaries[Random().nextInt(Colors.primaries.length)],
              ),
            ),
          ),
        ),
      );
      lstTemp.add(DataCell(SizedBox(
          width: 80,
          child:
              Text(lstKpiModel[index].emplid, textAlign: TextAlign.center))));
      if (KpiFieldsModel.col1.isNotEmpty)
        lstTemp.add(addRow(lstKpiModel[index].col1.toString(), index, _width));

      if (KpiFieldsModel.col2.isNotEmpty)
        lstTemp.add(addRow(lstKpiModel[index].col2.toString(), index, _width));
      if (KpiFieldsModel.col3.isNotEmpty)
        lstTemp.add(addRow(lstKpiModel[index].col3.toString(), index, _width));
      if (KpiFieldsModel.col4.isNotEmpty)
        lstTemp.add(addRow(lstKpiModel[index].col4.toString(), index, _width));
      if (KpiFieldsModel.col5.isNotEmpty)
        lstTemp.add(addRow(lstKpiModel[index].col5.toString(), index, _width));
      if (KpiFieldsModel.col6.isNotEmpty)
        lstTemp.add(addRow(lstKpiModel[index].col6.toString(), index, _width));
      if (KpiFieldsModel.col7.isNotEmpty)
        lstTemp.add(addRow(lstKpiModel[index].col7.toString(), index, _width));
      if (KpiFieldsModel.col8.isNotEmpty)
        lstTemp.add(addRow(lstKpiModel[index].col8.toString(), index, _width));
      if (KpiFieldsModel.col9.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col9.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col10.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col10.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col11.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col11.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col12.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col12.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col13.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col13.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col14.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col14.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col15.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col15.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col16.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col16.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col17.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col17.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col18.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col18.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col19.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col19.toString(),
          index,
          _width,
        ));
      if (KpiFieldsModel.col20.isNotEmpty)
        lstTemp.add(addRow(
          lstKpiModel[index].col20.toString(),
          index,
          _width,
        ));
      lstTemp.add(
        DataCell(
          SizedBox(
            width: 80,
            child: Text(getTotalScoreWithoutDirector(index),
                textAlign: TextAlign.center),
          ),
        ),
      );
    }

    lstTemp.add(DataCell(
      SizedBox(
        width: 105,
        child: myCommentText(
          commentStr: lstKpiModel[index].commentbyemployee,
          isDirectorConfirmed: getBoolValue(
              lstKpiModel[index].isConfirmed, Roles.Director.value),
          isHubDirectorConfirmed: getBoolValue(
              lstKpiModel[index].isConfirmedhub, Roles.HubDirector.value),
          RoleName: userSessionData.rolename,
          fnComment: (String commstr) {
            lstKpiModel[index].commentbyemployee = commstr;
          },
          purposedRole: Roles.Employee,
        ),
      ),
    ));

    if (userSessionData.rolename != Roles.Employee.value) {
      lstTemp.add(DataCell(
        SizedBox(
          width: 105,
          child: (lstKpiModel[index].isConfirmedhub == "1" ||
                  lstKpiModel[index].isConfirmed == "1")
              ? Text(lstKpiModel[index].commentbydirector)
              : myCommentText(
                  commentStr: lstKpiModel[index].commentbydirector,
                  isDirectorConfirmed: getBoolValue(
                      lstKpiModel[index].isConfirmed, Roles.Director.value),
                  isHubDirectorConfirmed:
                      (lstKpiModel[index].isConfirmed == "2" ||
                              lstKpiModel[index].isConfirmed == "1")
                          ? true
                          : false,
                  RoleName: userSessionData.rolename,
                  fnComment: (String commstr) {
                    lstKpiModel[index].commentbydirector = commstr;
                  },
                  purposedRole: Roles.Director,
                ),
        ),
      ));
    }

    if (userSessionData.rolename == Roles.HubDirector.value ||
        userSessionData.rolename == Roles.AllBranchManager.value) {
      lstTemp.add(DataCell(
        SizedBox(
          width: 105,
          child: (lstKpiModel[index].isConfirmedhub == "1" ||
                  lstKpiModel[index].isConfirmed == "1")
              ? Text(lstKpiModel[index].commentbydirectorhub)
              : myCommentText(
                  commentStr: lstKpiModel[index].commentbydirectorhub,
                  isDirectorConfirmed: getBoolValue(
                      lstKpiModel[index].isConfirmed, Roles.Director.value),
                  isHubDirectorConfirmed: getBoolValue(
                      lstKpiModel[index].isConfirmedhub,
                      Roles.HubDirector.value),
                  RoleName: userSessionData.rolename,
                  fnComment: (String commstr) {
                    lstKpiModel[index].commentbydirectorhub = commstr;
                  },
                  purposedRole: Roles.HubDirector,
                ),
        ),
      ));
    }

    if (userSessionData.rolename == Roles.AllBranchManager.value) {
      lstTemp.add(DataCell(
        SizedBox(
          width: 105,
          child: myCommentText(
            commentStr: lstKpiModel[index].commentbyallbrnmanager,
            isDirectorConfirmed: getBoolValue(
                lstKpiModel[index].isConfirmed, Roles.Director.value),
            isHubDirectorConfirmed: getBoolValue(
                lstKpiModel[index].isConfirmedhub, Roles.HubDirector.value),
            RoleName: userSessionData.rolename,
            fnComment: (String commstr) {
              lstKpiModel[index].commentbyallbrnmanager = commstr;
            },
            purposedRole: Roles.AllBranchManager,
          ),
        ),
      ));
    }

    lstTemp.add(
      DataCell(
        SizedBox(
          width: 110,
          child: myDropDownButton(
            isKpiOrStatus: "kpi",
            userRoleName: userSessionData.rolename,
            isConifrmed: (userSessionData.rolename == Roles.Director.value)
                ? (lstKpiModel[index].isConfirmed == "2" ||
                        lstKpiModel[index].isConfirmed == "1")
                    ? false
                    : true
                : (userSessionData.rolename == Roles.HubDirector.value)
                    ? (lstKpiModel[index].isConfirmedhub == "1" ||
                            lstKpiModel[index].isConfirmed == "1")
                        ? false
                        : true
                    : false,
            selectedKpiRequired: (lstKpiModel[index].iskpi.trim() == "")
                ? ""
                : (lstKpiModel[index].iskpi.trim() == "0" ||
                        lstKpiModel[index].iskpi.trim() == "Тооцно")
                    ? "Тооцно"
                    : "Тооцохгүй",
            fnGetSelectedValue: (String getValue) {
              lstKpiModel[index].iskpi = getValue;
            },
          ),
        ),
      ),
    );

    lstTemp.add(
      DataCell(
        SizedBox(
          width: 110,
          child: (lstKpiModel[index].isConfirmed == "1" ||
                  lstKpiModel[index].isConfirmedhub == "1")
              ? Text(
                  lstKpiModel[index].isConfirmed ==
                          "1" //Бүсрүү явуулсан бол оноог харах
                      ? lstKpiModel[index].scoredir.toString()
                      : lstKpiModel[index].scorehubdir.toString(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                  ),
                )
              : ScoreSingleRow(
                  isConfirmed: getBoolCheck(
                      lstKpiModel[index].emplposition,
                      RoleName == Roles.HubDirector.value
                          ? lstKpiModel[index].isConfirmedhub
                          : lstKpiModel[index].isConfirmed,
                      RoleName), //!userSessionData.ischecked, getScore service usage here.
                  fnEdit: (double dValue) {
                    RoleName == Roles.HubDirector.value
                        ? lstKpiModel[index].scorehubdir = dValue
                        : lstKpiModel[index].scoredir = dValue;

                    total_single = getTotalScore(index);
                  },
                  valueOfScore: (RoleName == Roles.HubDirector.value)
                      ? lstKpiModel[index].scorehubdir
                      : lstKpiModel[index].scoredir,
                  lst_IntValues: getValue(lstKpiModel[index].emplposition),
                ),
        ),
      ),
    );
    //Төлөв

    lstTemp.add(
      DataCell(
        SizedBox(
          width: 110,
          child: (lstKpiModel[index].isConfirmedhub == "1" ||
                  lstKpiModel[index].isConfirmed == "1")
              ? Text("Баталсан")
              : myDropDownButton(
                  userRoleName: userSessionData.rolename,
                  isKpiOrStatus: "status",
                  isConifrmed:
                      (userSessionData.rolename == Roles.Employee.value)
                          ? (lstKpiModel[index].isConfirmed == "1" ||
                                  lstKpiModel[index].isConfirmedhub == "1")
                              ? true
                              : false
                          : (userSessionData.rolename == Roles.Director.value)
                              ? (lstKpiModel[index].isConfirmed == "2")
                                  ? false
                                  : true
                              : (userSessionData.rolename ==
                                      Roles.HubDirector.value)
                                  ? true
                                  : false,
                  selectedKpiRequired: (lstKpiModel[index].isConfirmed.trim() ==
                              "0" &&
                          lstKpiModel[index].isConfirmedhub.trim() == "0")
                      ? ""
                      : (lstKpiModel[index].isConfirmed.trim() == "2" &&
                              userSessionData.rolename == Roles.Director.value)
                          ? "Бүсийн захиралд илгээх"
                          : "",
                  fnGetSelectedValue: (String getValue) {
                    if (getValue.isNotEmpty) {
                      userSessionData.rolename == Roles.HubDirector.value
                          ? lstKpiModel[index].isConfirmedhub = "1"
                          : lstKpiModel[index].isConfirmed =
                              (getValue == "Эцэслэх") ? "1" : "2";
                    } else {
                      userSessionData.rolename == Roles.HubDirector.value
                          ? lstKpiModel[index].isConfirmedhub = ""
                          : lstKpiModel[index].isConfirmed = "";
                    }
                  },
                ),
        ),
      ),
    );

    //Бүсийн захирал оноо
    /*
    lstTemp.add(DataCell(SizedBox(
        width: 105,
        child: (RoleName == Roles.HubDirector.value ||
                RoleName == Roles.AllBranchManager.value)
            ? ScoreSingleRow(
                isConfirmed: (false),
                fnEdit: (double dValue) {
                  lstKpiModel[index].scorehubdir = dValue;
                },
                valueOfScore: lstKpiModel[index].scorehubdir,
                lst_IntValues: lst_intvalues,
              )
            : Text(
                lstKpiModel[index].scorehubdir.toString(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12,
                ),
              ))));
    */
    //Гүйцэтгэл
    lstTemp.add(DataCell(SizedBox(
        width: 80,
        child: Text(
          total_single + '%',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ))));
    /*
    lstTemp.add(DataCell(myDirectorCheckBox(
        isConfirmedHub:
            (lstKpiModel[index].isConfirmedhub == "1") ? true : false,
        fnConfirmed: (bool isConfirmed) {
          lstKpiModel[index].isConfirmed = (isConfirmed) ? "1" : "0";
        },
        isConfirmedDir: (lstKpiModel[index].isConfirmed == "1") ? true : false,
        userRoleName: userSessionData.rolename)));
    lstTemp.add(DataCell(myHubDirectorCheckBox(
        isConfirmedHub: getBoolValue(lstKpiModel[index].isConfirmedhub),
        isConfirmedDir: getBoolValue(lstKpiModel[index].isConfirmed),
        fnConfirmed: (bool isConfirmed) {
          lstKpiModel[index].isConfirmedhub = (isConfirmed) ? "1" : "0";
        },
        userRoleName: userSessionData.rolename)));
    */
    lstTemp.add(DataCell(SizedBox(
        width: 80,
        child: Text((lstKpiModel[index].isConfirmed.trim() == "0" &&
                lstKpiModel[index].isConfirmedhub.trim() == "0")
            ? ""
            : (lstKpiModel[index].isConfirmed.trim() == "1")
                ? lstKpiModel[index].directorid.trim()
                : lstKpiModel[index].isConfirmedhub == "1"
                    ? lstKpiModel[index].hubdirectorid.trim()
                    : ""))));
    return lstTemp;
  }

  double str2double(String str) {
    double val = 0;
    try {
      val = double.parse(str);
    } catch (ex) {}

    return val;
  }
}
