import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Const/Constantino.dart';

class myHubDirectorCheckBox extends StatefulWidget {

  String  userRoleName;
  Function(bool isConfirmed) fnConfirmed;
  bool isConfirmedHub;
  bool isConfirmedDir;
  myHubDirectorCheckBox({Key? key,
    required this.isConfirmedHub,
    required this.fnConfirmed, required this.isConfirmedDir, required this.userRoleName,   }) : super(key: key);


  @override
  State<myHubDirectorCheckBox> createState() => _myHubDirectorCheckBoxState();
}

class _myHubDirectorCheckBoxState extends State<myHubDirectorCheckBox> {





  @override
  void initState() {
    // TODO: implement initState
    super.initState();



  }

  @override
  Widget build(BuildContext context) {


    return SizedBox( width :  50, child:   Checkbox(

        value:  widget.isConfirmedHub ,


        onChanged: (widget.userRoleName != Roles.HubDirector.value) ? null:
        (!widget.isConfirmedDir)?null:
            (bool? value) {


          setState(() {


            widget.isConfirmedHub = value!;

            widget.fnConfirmed(widget.isConfirmedHub);




          });
        }



    )
      ,);
  }
}
