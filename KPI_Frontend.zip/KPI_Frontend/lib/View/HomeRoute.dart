import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:kpi_empl/Model/kpiModel.dart';
import 'package:kpi_empl/View/AllBranchManager.dart';
import 'package:kpi_empl/View/Other/CustomCalendar.dart';
import 'package:kpi_empl/View/Fields/FieldView.dart';
import '../Const/Constantino.dart';
import '../Controllr/kpiController.dart';
import '../Model/UserSession.dart';
import '../Model/YearMonth.dart';
import '../Model/kpiFieldsModel.dart';
import '../main.dart';
import 'EmployeeScreen.dart';
import 'ManagerScreen.dart';

//import 'Profile/aProfile.dart';

class HomeRoute extends StatefulWidget {
  List<String> roleList;
  UserSessionData userSessionData;
  List<YearMonth> lstYearMonth;
  HomeRoute(
      {Key? key,
      required this.roleList,
      required this.userSessionData,
      required this.lstYearMonth})
      : super(key: key);

  @override
  State<HomeRoute> createState() => _HomeRouteState();
}

class _HomeRouteState extends State<HomeRoute> {
  int _menuIndex = 0;
  late int selectedYear;
  late int selectedMonth;
  late bool isDrawerBeingShown;
  late Future _loadData;
  late String profileStr = "";
  late List<KpiModel> lstKpi = [];
  late List<Widget> lstMenu = [];
  late List<YearMonth> tempYearMonth = [];

  @override
  void initState() {
    super.initState();

    _onDateChanged(
        widget.lstYearMonth.last.year, widget.lstYearMonth.last.month, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawerEnableOpenDragGesture: true,
      drawer: Drawer(
        child: Column(
          children: [
            // Profile section
            Container(
              color: Color(0xFF13376b),
              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Hi, ${widget.userSessionData.emplname}',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(
                        Icons.account_circle,
                        color: Colors.white,
                        size: 40,
                      ),
                      SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.userSessionData.emplid,
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            widget.userSessionData.empljobtitle,
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            widget.userSessionData.empldepartment,
                            style: TextStyle(color: Colors.white),
                          ),
                          Text(
                            widget.userSessionData.rolename,
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),

            Divider(),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "Гүйцэтгэлд хамаарах огноо:",
                    style: TextStyle(color: Color(0xFF13376b), fontSize: 20),
                  ),
                  const SizedBox(height: 20),
                  CustomCalendar(
                    onDateChanged: _onDateChanged,
                    yearSelected: selectedYear,
                    monthSelected: selectedMonth,
                  ),
                  /*const SizedBox(height: 40),
                  Text(
                    'Selected Year: $selectedYear, Month: ${selectedMonth + 1}',
                    style: TextStyle(fontSize: 20),
                  ),*/
                ],
              ),
            ),

            /*ListTile(
              leading: Icon(Icons.auto_graph),
              title: const Text('KPI Details'),
              onTap: () {
                // Update the state of the app

                setState(() {
                  _menuIndex = (widget.userSessionData.rolename ==
                          Roles.AllBranchManager.value)
                      ? 2
                      : 1;
                });

                Navigator.pop(context);
              },
            ),*/

            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Divider(),
                  if (widget.userSessionData.rolename ==
                      Roles.AllBranchManager.value)
                    ListTile(
                      leading: Icon(Icons.auto_graph),
                      title: Text('KPI Details'),
                      onTap: () {
                        setState(() {
                          _menuIndex = 2;
                        });
                        Navigator.pop(context);
                      },
                    ),
                  if (widget.userSessionData.rolename ==
                      Roles.AllBranchManager.value)
                    ListTile(
                      leading: Icon(Icons.settings),
                      title: Text('Settings'),
                      onTap: () {
                        setState(() {
                          _menuIndex = 3;
                        });
                        Navigator.pop(context);
                      },
                    ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(
                Icons.exit_to_app_outlined,
                color: Colors.blue,
              ),
              title: Text('Logout'),
              onTap: () {
                Navigator.pushReplacement(
                    context, MaterialPageRoute(builder: (context) => MyApp()));
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        elevation: 10,
        backgroundColor: Color(0xFF13376b),
        title: Text(
          'Ажилтаны гүйцэтгэлийн оноо',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: FutureBuilder(
        future: _loadData,
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.none:
              return const Text(
                "Press button to start.",
                style: TextStyle(color: Colors.red),
              );
            case ConnectionState.waiting:
              return CircularProgressIndicator();
            default:
              if (snapshot.hasError)
                return Text(
                  "No Data found. Error:" + snapshot.error.toString(),
                  style: TextStyle(color: Colors.red),
                );
              else {
                return myData();
              }
          }
        },
      ),
    );
  }

  Widget myData() {
    return Align(
      alignment: Alignment.topCenter,
      child: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 20),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: lstMenu[_menuIndex],
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<YearMonth> addElementIfNotExists(
      List<YearMonth> list, YearMonth element) {
    print("list element object is here");
    print(list);
    print("add element is here");
    print(element);

    // Check if the element already exists in the list
    bool exists = list.any((tmpelement) =>
        tmpelement.year == element.year &&
        tmpelement.month == element.month &&
        tmpelement.position == element.position);

    if (!exists) {
      print("Adding element as it does not exist");
      list.add(element);
    } else {
      print("Element already exists, not adding");
    }

    return list;
  }

  void _onDateChanged(int year, int month, bool flg) {
    setState(() {
      tempYearMonth.clear();
      selectedYear = year;
      selectedMonth = month - 1;

      widget.lstYearMonth.last.year = year;
      widget.lstYearMonth.last.month = month;
      print("widget.lstYearMonth.length is here");
      print(widget.lstYearMonth.length);
      for (var element in widget.lstYearMonth) {
        print("tempYearMonth is here");
        print(tempYearMonth);
        if (element.year == year && element.month == month) {
          tempYearMonth = addElementIfNotExists(tempYearMonth, element);
        }
      }
      print("last tempYearMonth is here");
      print(tempYearMonth);
      widget.lstYearMonth.last.year = selectedYear;
      widget.lstYearMonth.last.month = selectedMonth;
      widget.lstYearMonth.last.month++;
      widget.roleList.clear();

      LoadData();
      _loadMenu();
    });
  }

  Future<bool> LoadData() async {
    bool isCompleted = true;
    await Future.delayed(Duration(seconds: 1));

    var getData = await KpiController().GetKpi_Fields(
        widget.userSessionData,
        widget.lstYearMonth.last.year.toString(),
        widget.lstYearMonth.last.month.toString());
    if (getData.responseCode.responseCode == ResponseValue.Success.value) {
      List<KpiFieldsModel> lstKpiFileds = getData.lstKpiFieldsModel;

      if (lstKpiFileds.isNotEmpty) {
        for (var element in lstKpiFileds) {
          if (!widget.roleList.contains(element.positionname)) {
            widget.roleList.add(element.positionname);
          }
        }
      }
    } else {
      if (!widget.roleList.contains("Бусад")) {
        widget.roleList.add("Бусад");
      }
    }

    return isCompleted;
  }

  void _loadMenu() {
    lstMenu.clear();
    _loadData = LoadData();

    if (widget.userSessionData.rolename == Roles.Employee.value) {
      _menuIndex = 0;
    } else if (widget.userSessionData.rolename == Roles.HubDirector.value ||
        widget.userSessionData.rolename == Roles.Director.value) {
      _menuIndex = 1;
    } else if (widget.userSessionData.rolename ==
        Roles.AllBranchManager.value) {
      _menuIndex = 3;
    } else {
      _menuIndex = 3;
    }

    lstMenu.add(EmployeeScreen(
      lstYearMonth: tempYearMonth,
      userSessionData: widget.userSessionData,
    ));
    print("Manager screen start here");
    print(tempYearMonth);
    lstMenu.add(ManagerScreen(
      userSessionData: widget.userSessionData,
      lstYearMonth: tempYearMonth,
      lstRoleList: widget.roleList,
    ));

    lstMenu.add(AllBranchManager(
      userSessionData: widget.userSessionData,
      lstYearMonth: tempYearMonth,
      lstRoleList: widget.roleList,
      context: context,
    ));

    lstMenu.add(FieldView(
      roleList: widget.roleList,
      userSessionData: widget.userSessionData,
      selectedYear: widget.lstYearMonth.last.year.toString(),
      selectedMonth: widget.lstYearMonth.last.month.toString(),
    ));
  }
}
