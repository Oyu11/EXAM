import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../Model/YearMonth.dart';
import '../Model/kpiFieldsModel.dart';
import '../Model/kpiModel.dart';
import '../Model/kpiModelTemp.dart';

List<String> lstKpiRequired = ["", "Тооцно", "Тооцохгүй"];
List<String> lstConfirmRequired = ["", "Эцэслэх", "Бүсийн захиралд илгээх"];
List<String> lstConfirmRequiredHub = ["", "Эцэслэх"];

KpiFieldsModel tmpKpiFieldsModel = KpiFieldsModel(
    0,
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    0,
    0,
    "",
    "",
    "",
    "",
    "",
    0, //scorenumber1
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0);

KpiModel tmpKpiModel = KpiModel(
    0,
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "",
    "",
    "",
    "",
    "0",
    "0",
    "0",
    "",
    "",
    "",
    "");
KpiModelTemp tmpKpiModelTemp = KpiModelTemp(
    0,
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    "",
    "",
    "",
    "",
    "0",
    "0",
    "0",
    "",
    "",
    "",
    "");
YearMonth tmpYearMonth = YearMonth(1900, 1, 1, "noPosition");
/*
String IPAddress_ = "localhost";
String Port_ = "8084/";
String RootMapping = "";
*/
/*
String IPAddress_ = "localhost";
String Port_ = "80/";
String RootMapping = "KPI/";
*/

String IPAddress_ = "172.25.0.112";
String Port_ = "8180/";
String RootMapping = "KPI/";

enum ResponseValue {
  Success("200"),
  Error("300"),
  No_Found("400");

  const ResponseValue(this.value);
  final String value;
}

List<String> lst_str_kpi = ["KPI: Тооцно", "KPI: Тооцохгүй", "KPI: Бүгд"];
String? dropdownValue_kpi;

String? dropdown_role;

List<String> lst_str_allConfirm = ["Баталсан", "Хүлээгдэж буй", "Бүгд"];

List<String> lst_str_isConfirmDir = [
  "Захирал: Баталсан",
  "Захирал: Батлаагүй",
  "Захирал: Бүгд"
];
String? dropdownValue_confirmDir;
String? dropdownValue_allConfirm;

List<String> lst_str_isConfirmHub = [
  "Бүс захирал: Баталсан",
  "Бүс захирал: Батлаагүй",
  "Бүс захирал: Бүгд"
];

List<String> lst_str_isConfirm = [
  "Баталсан",
  "Эцэслэх",
  "Бүсийн захиралд илгээх",
  "Бүгд"
];
List<String> lst_str_isConfirmHubLast = ["Эцэслэх", "Бүгд"];

String? dropdownValue_confirm;

String? dropdownValue_confirmHub;

enum FilterValue {
  Filter_KPI("kpi"),
  Filter_Confirm_byDir("director"),
  Filter_Confirm_byHubDir("hubdirector");

  const FilterValue(this.value);
  final String value;
}

enum Roles {
  Director("kpi_director"),
  Employee("kpi_employee"),
  HubDirector("kpi_hubdirector"),
  AllBranchManager("kpi_allbrnmanager");

  const Roles(this.value);
  final String value;
}

class SizeConfig {
  late MediaQueryData _mediaQueryData;
  late double screenWidth;
  late double screenHeight;
  late double blockSizeHorizontal;
  late double blockSizeVertical;

  void init(BuildContext context) {
    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height;
    blockSizeHorizontal = screenWidth / 100;
    blockSizeVertical = screenHeight / 100;
  }
}

class ScaleSize {
  static double textScaleFactor(BuildContext context,
      {double maxTextScaleFactor = 1.5}) {
    final width = MediaQuery.of(context).size.width;
    double val = (width / 1900) * maxTextScaleFactor;
    return max(1, min(val, maxTextScaleFactor));
  }
}
