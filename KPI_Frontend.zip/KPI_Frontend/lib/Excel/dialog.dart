//import 'package:another_flushbar/flushbar.dart';
import 'package:flutter/material.dart';

class DialogService {
  /*Future warningDialog(
      BuildContext context, String Message, IconData iconV, Color ColorV) {
    return Flushbar(
      message: Message, //"Санал асуулт амжилттай хаалаа.
      isDismissible: true,
      flushbarStyle: FlushbarStyle.FLOATING,
      icon: Icon(iconV, size: 20, color: ColorV),
      duration: const Duration(seconds: 3),
      margin: const EdgeInsets.only(left: 450, right: 45, bottom: 45),
      padding: const EdgeInsets.all(25),
    ).show(context);
  }*/

  Future warningDialog(
      BuildContext context, String message, IconData iconV, Color colorV) {
    return showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        Future.delayed(const Duration(seconds: 5), () {
          Navigator.of(dialogContext).pop();
        });

        return AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(iconV, size: 20, color: colorV),
              const SizedBox(height: 10),
              Text(message),
            ],
          ),
        );
      },
    );
  }

  Future showAlertDialog(BuildContext context, String Message) {
    return showDialog(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          insetPadding: EdgeInsets.zero,

          // <-- SEE HERE
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          title: const Text('Баталгаажуулалт',
              style: TextStyle(fontWeight: FontWeight.bold)),
          content: Container(
            width: MediaQuery.of(context).size.width * 0.20,
            child: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  Text(
                    (Message + " ?"),
                    style: TextStyle(fontSize: 14),
                  ),
                ],
              ),
            ),
          ),

          actions: <Widget>[
            Padding(
                padding: EdgeInsets.only(
                  left: MediaQuery.of(context).size.width * 0.20 * 0.05,
                  right: MediaQuery.of(context).size.width * 0.20 * 0.05,
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * 0.20 * 0.4,
                          height: 60,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFFf9f8fd),
                                blurRadius: 2,
                                offset: Offset(8, 10),
                              ),
                            ],
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).pop(DialResponse.No);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                              ),
                            ),
                            child: Text(
                              'Үгүй',
                              style: TextStyle(
                                  color: Color.fromARGB(241, 235, 94, 1)),
                            ),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.20 * 0.4,
                          height: 60,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment(-1.0, 1.0),
                                end: Alignment(1, -1),
                                colors: [
                                  Color.fromRGBO(237, 24, 70, 1),
                                  Color.fromRGBO(255, 204, 50, 1)
                                ]),
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).pop(DialResponse.Yes);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                              ),
                            ),
                            child: Text('Тийм'),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ))
          ],
        );
      },
    );
  }
}

enum DialResponse { Yes, No }
