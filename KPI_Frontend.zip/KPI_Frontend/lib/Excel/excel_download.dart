import 'dart:math';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' as xlx;
import 'package:kpi_empl/Excel/dialog.dart';
import 'package:kpi_empl/Model/UserSession.dart';
import '../Const/Constantino.dart';
import '../Controllr/kpiController.dart';
import '../Excel/save_file_web.dart' as helper;
import '../Model/YearMonth.dart';

class ExcelDownloadButton extends StatefulWidget {
  final UserSessionData userSessionData;
  final YearMonth yearmonth;
  final String report_type;

  ExcelDownloadButton({
    Key? key,
    required this.userSessionData,
    required this.yearmonth,
    required this.report_type,
  }) : super(key: key);

  @override
  State<ExcelDownloadButton> createState() => _ExcelDownloadButtonState();
}

class _ExcelDownloadButtonState extends State<ExcelDownloadButton> {
  bool _isLoading = false;

  Future<void> exportDataGridToExcel() async {
    setState(() {
      _isLoading = true;
    });
    List<String> field_name = [];

    try {
      int i = 0, start_index = 0;
      print("widget.userSessionData");
      print(widget.yearmonth.position);
      print(widget.report_type);

      var rslt = await KpiController().GetKpiDetails(
          widget.userSessionData,
          widget.yearmonth.year.toString(),
          widget.yearmonth.month.toString(),
          widget.report_type);

      String getTotalScore(int index) {
        double totalScore = 0;

        totalScore += rslt.lstKpiModel[index].col1;
        totalScore += rslt.lstKpiModel[index].col2;
        totalScore += rslt.lstKpiModel[index].col3;
        totalScore += rslt.lstKpiModel[index].col4;
        totalScore += rslt.lstKpiModel[index].col5;
        totalScore += rslt.lstKpiModel[index].col6;
        totalScore += rslt.lstKpiModel[index].col7;
        totalScore += rslt.lstKpiModel[index].col8;
        totalScore += rslt.lstKpiModel[index].col9;
        totalScore += rslt.lstKpiModel[index].col10;
        totalScore += rslt.lstKpiModel[index].col11;
        totalScore += rslt.lstKpiModel[index].col12;
        totalScore += rslt.lstKpiModel[index].col13;
        totalScore += rslt.lstKpiModel[index].col14;
        totalScore += rslt.lstKpiModel[index].col15;
        totalScore += rslt.lstKpiModel[index].col16;
        totalScore += rslt.lstKpiModel[index].col17;
        totalScore += rslt.lstKpiModel[index].col18;
        totalScore += rslt.lstKpiModel[index].col19;
        totalScore += rslt.lstKpiModel[index].col20;
        totalScore += rslt.lstKpiModel[index].isConfirmed == "1"
            ? rslt.lstKpiModel[index].scoredir
            : 0;
        totalScore += rslt.lstKpiModel[index].isConfirmedhub == "1"
            ? rslt.lstKpiModel[index].scorehubdir
            : 0;
        if (totalScore >= 100) {
          totalScore = 100;
        }

        return totalScore.round().toString();
      }

      if (rslt.responseCode.responseCode == ResponseValue.Success.value) {
        i = 0;

        final xlx.Workbook workbook = xlx.Workbook();
        final xlx.Worksheet sheet = workbook.worksheets[0];
        if (widget.report_type == "ALL") {
          sheet.getRangeByIndex(1, 1).setText('Дугаар');
          sheet.getRangeByIndex(1, 2).setText('Бүс код');
          sheet.getRangeByIndex(1, 3).setText('Салбар');
          sheet.getRangeByIndex(1, 4).setText('Ажилтан нэр');
          sheet.getRangeByIndex(1, 5).setText('Ажилтан код');
          sheet.getRangeByIndex(1, 6).setText('Албан тушаал');
          sheet.getRangeByIndex(1, 7).setText('Статус');
          sheet.getRangeByIndex(1, 8).setText('KPI');
          sheet.getRangeByIndex(1, 9).setText('Захирал оноо');
          sheet.getRangeByIndex(1, 10).setText('Гүйцэтгэл оноо');
          sheet.getRangeByIndex(1, 11).setText('Баталсан захирал');

          for (var element in rslt.lstKpiModel) {
            sheet.getRangeByIndex(i + 2, 1).setText((i + 1).toString());
            sheet.getRangeByIndex(i + 2, 2).setText(element.hubcode);
            sheet.getRangeByIndex(i + 2, 3).setText(element.emplbrncode);
            sheet.getRangeByIndex(i + 2, 4).setText(element.emplname);
            sheet.getRangeByIndex(i + 2, 5).setText(element.emplid);
            sheet.getRangeByIndex(i + 2, 6).setText(element.emplposition);
            sheet.getRangeByIndex(i + 2, 7).setText(element.emplstatus);
            sheet.getRangeByIndex(i + 2, 8).setText(element.iskpi);
            sheet.getRangeByIndex(i + 2, 9).setText(element.isConfirmed == "1"
                ? element.scoredir.toString()
                : element.scorehubdir.toString());
            sheet.getRangeByIndex(i + 2, 10).setText(getTotalScore(i));
            sheet.getRangeByIndex(i + 2, 11).setText(element.isConfirmed == "1"
                ? element.directorid
                : element.hubdirectorid);
            i++;
          }
        } else {
          try {
            rslt.lstKpiFieldsModel.forEach((element) {
              if (element.col1.isNotEmpty) {
                field_name.add(element.col1);
              }
              if (element.col2.isNotEmpty) {
                field_name.add(element.col2);
              }
              if (element.col3.isNotEmpty) {
                field_name.add(element.col3);
              }
              if (element.col4.isNotEmpty) {
                field_name.add(element.col4);
              }
              if (element.col5.isNotEmpty) {
                field_name.add(element.col5);
              }
              if (element.col6.isNotEmpty) {
                field_name.add(element.col6);
              }
              if (element.col7.isNotEmpty) {
                field_name.add(element.col7);
              }
              if (element.col8.isNotEmpty) {
                field_name.add(element.col8);
              }
              if (element.col9.isNotEmpty) {
                field_name.add(element.col9);
              }
              if (element.col10.isNotEmpty) {
                field_name.add(element.col10);
              }
            });
            print("print(field_name.length);");
            print(field_name.length);

            sheet.getRangeByIndex(1, 1).setText('Дугаар');
            sheet.getRangeByIndex(1, 2).setText('Бүс код');
            sheet.getRangeByIndex(1, 3).setText('Салбар');
            sheet.getRangeByIndex(1, 4).setText('Ажилтан нэр');
            sheet.getRangeByIndex(1, 5).setText('Ажилтан код');
            sheet.getRangeByIndex(1, 6).setText('Албан тушаал');
            sheet.getRangeByIndex(1, 7).setText('Статус');
            for (int k = 0; k < field_name.length; k++) {
              sheet.getRangeByIndex(1, k + 8).setText(field_name[k]);
            }
            int start_index = 7 + field_name.length;
            sheet.getRangeByIndex(1, start_index + 1).setText('KPI');
            start_index += 1;
            sheet.getRangeByIndex(1, start_index + 1).setText('Захирал оноо');
            start_index += 1;
            sheet.getRangeByIndex(1, start_index + 1).setText('Гүйцэтгэл оноо');
            start_index += 1;
            sheet
                .getRangeByIndex(1, start_index + 1)
                .setText('Баталсан захирал');

            for (var element in rslt.lstKpiModel) {
              int k = 0;
              sheet.getRangeByIndex(i + 2, 1).setText((i + 1).toString());
              sheet.getRangeByIndex(i + 2, 2).setText(element.hubcode);
              sheet.getRangeByIndex(i + 2, 3).setText(element.emplbrncode);
              sheet.getRangeByIndex(i + 2, 4).setText(element.emplname);
              sheet.getRangeByIndex(i + 2, 5).setText(element.emplid);
              sheet.getRangeByIndex(i + 2, 6).setText(element.emplposition);
              sheet.getRangeByIndex(i + 2, 7).setText(element.emplstatus);

              if (field_name.length >= 1) {
                sheet
                    .getRangeByIndex(i + 2, k + 8)
                    .setText(element.col1.toString());
              }
              if (field_name.length >= 2) {
                sheet
                    .getRangeByIndex(i + 2, k + 9)
                    .setText(element.col2.toString());
              }
              if (field_name.length >= 3) {
                sheet
                    .getRangeByIndex(i + 2, k + 10)
                    .setText(element.col3.toString());
              }
              if (field_name.length >= 4) {
                print("CSR deer endees orj irne");
                sheet
                    .getRangeByIndex(i + 2, k + 11)
                    .setText(element.col4.toString());
              }
              if (field_name.length >= 5) {
                sheet
                    .getRangeByIndex(i + 2, k + 12)
                    .setText(element.col5.toString());
              }
              if (field_name.length >= 6) {
                sheet
                    .getRangeByIndex(i + 2, k + 13)
                    .setText(element.col6.toString());
              }
              if (field_name.length >= 7) {
                sheet
                    .getRangeByIndex(i + 2, k + 14)
                    .setText(element.col7.toString());
              }
              if (field_name.length >= 8) {
                sheet
                    .getRangeByIndex(i + 2, k + 15)
                    .setText(element.col8.toString());
              }
              if (field_name.length >= 9) {
                sheet
                    .getRangeByIndex(i + 2, k + 16)
                    .setText(element.col9.toString());
              }
              if (field_name.length >= 10) {
                sheet
                    .getRangeByIndex(i + 2, k + 17)
                    .setText(element.col10.toString());
              }
              start_index = 7 + field_name.length;
              print("print(field_name.length);");
              print(field_name.length);
              print(start_index);
              sheet
                  .getRangeByIndex(i + 2, start_index + 1)
                  .setText(element.iskpi);
              start_index += 1;
              sheet.getRangeByIndex(i + 2, start_index + 1).setText(
                  element.isConfirmed == "1"
                      ? element.scoredir.toString()
                      : element.scorehubdir.toString());
              start_index += 1;
              sheet
                  .getRangeByIndex(i + 2, start_index + 1)
                  .setText(getTotalScore(i));
              start_index += 1;
              sheet.getRangeByIndex(i + 2, start_index + 1).setText(
                  element.isConfirmed == "1"
                      ? element.directorid
                      : element.hubdirectorid);
              i++;
            }
          } catch (e) {
            print("catch error from list");
            print(e.toString());
          }
        }

        final List<int> bytes = workbook.saveAsStream();
        await helper.saveAndLaunchFile(
            bytes, '${widget.report_type}Report.xlsx');
        await DialogService().warningDialog(
            context,
            'Excel файлыг амжилттай татлаа.',
            Icons.done_outline,
            Colors.green.shade300);
      } else if (rslt.responseCode.responseCode ==
          ResponseValue.No_Found.value) {
        await DialogService().warningDialog(context, "Тайлан хоосон байна.",
            Icons.add_alert_outlined, Colors.yellow.shade300);
      } else {
        await DialogService().warningDialog(
            context,
            "${rslt.responseCode.responseCode}Тайлан татахад алдаа гарлаа.",
            Icons.warning_outlined,
            Colors.red.shade300);
      }
    } catch (e) {
      print(e.toString());
      await DialogService().warningDialog(context, " Та дахин оролдоно уу.",
          Icons.warning_outlined, Colors.red.shade300);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      label: _isLoading
          ? SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            )
          : const Text('.xlx'),
      backgroundColor: Color.fromARGB(255, 76, 141, 23),
      icon: _isLoading
          ? null
          : const Icon(
              Icons.file_download,
              size: 15,
            ),
      onPressed: _isLoading ? null : exportDataGridToExcel,
    );
  }
}
