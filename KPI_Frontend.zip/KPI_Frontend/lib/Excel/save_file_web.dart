import 'dart:async';
import 'dart:convert';
import 'dart:html' as html;
import 'package:syncfusion_flutter_pdf/pdf.dart';

///To save the Excel file in the web platform.
Future<void> saveAndLaunchFile(List<int> bytes, String fileName) async {
  html.AnchorElement(
      href:
          'data:application/octet-stream;charset=utf-16le;base64,${base64.encode(bytes)}')
    ..setAttribute('download', fileName)
    ..click();
}

Future<void> saveAndDocument(String bytes, String fileName) async {
  PdfDocument doc = PdfDocument.fromBase64String(bytes);
  var savedFile = await doc.save();
  print('save file ----->');
  //print(savedFile);
  List<int> fileInts = List.from(savedFile);
  print('file int -------->');
  //print(fileInts);
  html.AnchorElement(
      href:
          "data:application/octet-stream;charset=utf-16le;base64,${base64.encode(fileInts)}")
    ..setAttribute("download", fileName)
    ..click();
}
