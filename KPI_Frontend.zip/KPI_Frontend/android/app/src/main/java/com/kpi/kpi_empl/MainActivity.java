package com.kpi.kpi_empl;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
